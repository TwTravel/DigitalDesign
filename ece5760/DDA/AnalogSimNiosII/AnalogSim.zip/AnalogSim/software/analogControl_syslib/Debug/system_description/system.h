/* system.h
 *
 * Machine generated for a CPU named "cpu_0" as defined in:
 * C:\DE2\AnalogSim\software\analogControl_syslib\..\..\hybrid_cntl.ptf
 *
 * Generated: 2006-12-04 09:29:35.781
 *
 */

#ifndef __SYSTEM_H_
#define __SYSTEM_H_

/*

DO NOT MODIFY THIS FILE

   Changing this file will have subtle consequences
   which will almost certainly lead to a nonfunctioning
   system. If you do modify this file, be aware that your
   changes will be overwritten and lost when this file
   is generated again.

DO NOT MODIFY THIS FILE

*/

/******************************************************************************
*                                                                             *
* License Agreement                                                           *
*                                                                             *
* Copyright (c) 2003 Altera Corporation, San Jose, California, USA.           *
* All rights reserved.                                                        *
*                                                                             *
* Permission is hereby granted, free of charge, to any person obtaining a     *
* copy of this software and associated documentation files (the "Software"),  *
* to deal in the Software without restriction, including without limitation   *
* the rights to use, copy, modify, merge, publish, distribute, sublicense,    *
* and/or sell copies of the Software, and to permit persons to whom the       *
* Software is furnished to do so, subject to the following conditions:        *
*                                                                             *
* The above copyright notice and this permission notice shall be included in  *
* all copies or substantial portions of the Software.                         *
*                                                                             *
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR  *
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,    *
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE *
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER      *
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING     *
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER         *
* DEALINGS IN THE SOFTWARE.                                                   *
*                                                                             *
* This agreement shall be governed in all respects by the laws of the State   *
* of California and by the laws of the United States of America.              *
*                                                                             *
******************************************************************************/

/*
 * system configuration
 *
 */

#define ALT_SYSTEM_NAME "hybrid_cntl"
#define ALT_CPU_NAME "cpu_0"
#define ALT_CPU_ARCHITECTURE "altera_nios2"
#define ALT_DEVICE_FAMILY "CYCLONEII"
#define ALT_STDIN "/dev/jtag_uart_0"
#define ALT_STDIN_TYPE "altera_avalon_jtag_uart"
#define ALT_STDIN_BASE 0x00000800
#define ALT_STDOUT "/dev/jtag_uart_0"
#define ALT_STDOUT_TYPE "altera_avalon_jtag_uart"
#define ALT_STDOUT_BASE 0x00000800
#define ALT_STDERR "/dev/jtag_uart_0"
#define ALT_STDERR_TYPE "altera_avalon_jtag_uart"
#define ALT_STDERR_BASE 0x00000800
#define ALT_CPU_FREQ 50000000
#define ALT_IRQ_BASE NULL

/*
 * processor configuration
 *
 */

#define NIOS2_CPU_IMPLEMENTATION "small"
#define NIOS2_BIG_ENDIAN 0

#define NIOS2_ICACHE_SIZE 4096
#define NIOS2_DCACHE_SIZE 0
#define NIOS2_ICACHE_LINE_SIZE 32
#define NIOS2_ICACHE_LINE_SIZE_LOG2 5
#define NIOS2_DCACHE_LINE_SIZE 0
#define NIOS2_DCACHE_LINE_SIZE_LOG2 0
#define NIOS2_FLUSHDA_SUPPORTED

#define NIOS2_EXCEPTION_ADDR 0x00800020
#define NIOS2_RESET_ADDR 0x00800000
#define NIOS2_BREAK_ADDR 0x00000020

#define NIOS2_HAS_DEBUG_STUB

#define NIOS2_CPU_ID_SIZE 1
#define NIOS2_CPU_ID_VALUE 0

/*
 * A define for each class of peripheral
 *
 */

#define __ALTERA_AVALON_JTAG_UART
#define __ALTERA_AVALON_TIMER
#define __ALTERA_AVALON_PIO
#define __ALTERA_AVALON_NEW_SDRAM_CONTROLLER

/*
 * jtag_uart_0 configuration
 *
 */

#define JTAG_UART_0_NAME "/dev/jtag_uart_0"
#define JTAG_UART_0_TYPE "altera_avalon_jtag_uart"
#define JTAG_UART_0_BASE 0x00000800
#define JTAG_UART_0_SPAN 8
#define JTAG_UART_0_IRQ 0
#define JTAG_UART_0_WRITE_DEPTH 64
#define JTAG_UART_0_READ_DEPTH 64
#define JTAG_UART_0_WRITE_THRESHOLD 8
#define JTAG_UART_0_READ_THRESHOLD 8
#define JTAG_UART_0_READ_CHAR_STREAM ""
#define JTAG_UART_0_SHOWASCII 1
#define JTAG_UART_0_READ_LE 0
#define JTAG_UART_0_WRITE_LE 0
#define JTAG_UART_0_ALTERA_SHOW_UNRELEASED_JTAG_UART_FEATURES 0

/*
 * timer_0 configuration
 *
 */

#define TIMER_0_NAME "/dev/timer_0"
#define TIMER_0_TYPE "altera_avalon_timer"
#define TIMER_0_BASE 0x00000820
#define TIMER_0_SPAN 32
#define TIMER_0_IRQ 1
#define TIMER_0_ALWAYS_RUN 0
#define TIMER_0_FIXED_PERIOD 0
#define TIMER_0_SNAPSHOT 1
#define TIMER_0_PERIOD 1
#define TIMER_0_PERIOD_UNITS "ms"
#define TIMER_0_RESET_OUTPUT 0
#define TIMER_0_TIMEOUT_PULSE_OUTPUT 0
#define TIMER_0_MULT 0.001
#define TIMER_0_FREQ 50000000

/*
 * DDS_incr configuration
 *
 */

#define DDS_INCR_NAME "/dev/DDS_incr"
#define DDS_INCR_TYPE "altera_avalon_pio"
#define DDS_INCR_BASE 0x00000810
#define DDS_INCR_SPAN 16
#define DDS_INCR_DO_TEST_BENCH_WIRING 0
#define DDS_INCR_DRIVEN_SIM_VALUE 0x0000
#define DDS_INCR_HAS_TRI 0
#define DDS_INCR_HAS_OUT 1
#define DDS_INCR_HAS_IN 0
#define DDS_INCR_CAPTURE 0
#define DDS_INCR_EDGE_TYPE "NONE"
#define DDS_INCR_IRQ_TYPE "NONE"
#define DDS_INCR_FREQ 50000000

/*
 * control configuration
 *
 */

#define CONTROL_NAME "/dev/control"
#define CONTROL_TYPE "altera_avalon_pio"
#define CONTROL_BASE 0x00000840
#define CONTROL_SPAN 16
#define CONTROL_DO_TEST_BENCH_WIRING 0
#define CONTROL_DRIVEN_SIM_VALUE 0x0000
#define CONTROL_HAS_TRI 0
#define CONTROL_HAS_OUT 1
#define CONTROL_HAS_IN 0
#define CONTROL_CAPTURE 0
#define CONTROL_EDGE_TYPE "NONE"
#define CONTROL_IRQ_TYPE "NONE"
#define CONTROL_FREQ 50000000

/*
 * input_gain configuration
 *
 */

#define INPUT_GAIN_NAME "/dev/input_gain"
#define INPUT_GAIN_TYPE "altera_avalon_pio"
#define INPUT_GAIN_BASE 0x00000850
#define INPUT_GAIN_SPAN 16
#define INPUT_GAIN_DO_TEST_BENCH_WIRING 0
#define INPUT_GAIN_DRIVEN_SIM_VALUE 0x0000
#define INPUT_GAIN_HAS_TRI 0
#define INPUT_GAIN_HAS_OUT 1
#define INPUT_GAIN_HAS_IN 0
#define INPUT_GAIN_CAPTURE 0
#define INPUT_GAIN_EDGE_TYPE "NONE"
#define INPUT_GAIN_IRQ_TYPE "NONE"
#define INPUT_GAIN_FREQ 50000000

/*
 * phase configuration
 *
 */

#define PHASE_NAME "/dev/phase"
#define PHASE_TYPE "altera_avalon_pio"
#define PHASE_BASE 0x00000860
#define PHASE_SPAN 16
#define PHASE_DO_TEST_BENCH_WIRING 0
#define PHASE_DRIVEN_SIM_VALUE 0x0000
#define PHASE_HAS_TRI 0
#define PHASE_HAS_OUT 0
#define PHASE_HAS_IN 1
#define PHASE_CAPTURE 0
#define PHASE_EDGE_TYPE "NONE"
#define PHASE_IRQ_TYPE "NONE"
#define PHASE_FREQ 50000000

/*
 * amplitude configuration
 *
 */

#define AMPLITUDE_NAME "/dev/amplitude"
#define AMPLITUDE_TYPE "altera_avalon_pio"
#define AMPLITUDE_BASE 0x00000870
#define AMPLITUDE_SPAN 16
#define AMPLITUDE_DO_TEST_BENCH_WIRING 0
#define AMPLITUDE_DRIVEN_SIM_VALUE 0x0000
#define AMPLITUDE_HAS_TRI 0
#define AMPLITUDE_HAS_OUT 0
#define AMPLITUDE_HAS_IN 1
#define AMPLITUDE_CAPTURE 0
#define AMPLITUDE_EDGE_TYPE "NONE"
#define AMPLITUDE_IRQ_TYPE "NONE"
#define AMPLITUDE_FREQ 50000000

/*
 * sdram_0 configuration
 *
 */

#define SDRAM_0_NAME "/dev/sdram_0"
#define SDRAM_0_TYPE "altera_avalon_new_sdram_controller"
#define SDRAM_0_BASE 0x00800000
#define SDRAM_0_SPAN 8388608
#define SDRAM_0_REGISTER_DATA_IN 1
#define SDRAM_0_SIM_MODEL_BASE 1
#define SDRAM_0_SDRAM_DATA_WIDTH 16
#define SDRAM_0_SDRAM_ADDR_WIDTH 12
#define SDRAM_0_SDRAM_ROW_WIDTH 12
#define SDRAM_0_SDRAM_COL_WIDTH 8
#define SDRAM_0_SDRAM_NUM_CHIPSELECTS 1
#define SDRAM_0_SDRAM_NUM_BANKS 4
#define SDRAM_0_REFRESH_PERIOD 15.625
#define SDRAM_0_POWERUP_DELAY 100
#define SDRAM_0_CAS_LATENCY 3
#define SDRAM_0_T_RFC 70
#define SDRAM_0_T_RP 20
#define SDRAM_0_T_MRD 3
#define SDRAM_0_T_RCD 20
#define SDRAM_0_T_AC 5.5
#define SDRAM_0_T_WR 14
#define SDRAM_0_INIT_REFRESH_COMMANDS 2
#define SDRAM_0_INIT_NOP_DELAY 0
#define SDRAM_0_SHARED_DATA 0
#define SDRAM_0_STARVATION_INDICATOR 0
#define SDRAM_0_TRISTATE_BRIDGE_SLAVE ""
#define SDRAM_0_IS_INITIALIZED 1
#define SDRAM_0_SDRAM_BANK_WIDTH 2
#define SDRAM_0_CONTENTS_INFO "SIMDIR/sdram_0.dat 1164978596"

/*
 * system library configuration
 *
 */

#define ALT_MAX_FD 32
#define ALT_SYS_CLK TIMER_0
#define ALT_TIMESTAMP_CLK none

/*
 * Devices associated with code sections.
 *
 */

#define ALT_TEXT_DEVICE       SDRAM_0
#define ALT_RODATA_DEVICE     SDRAM_0
#define ALT_RWDATA_DEVICE     SDRAM_0
#define ALT_EXCEPTIONS_DEVICE SDRAM_0
#define ALT_RESET_DEVICE      SDRAM_0

/*
 * The text section is initialised so no bootloader will be required.
 * Set a variable to tell crt0.S to provide code at the reset address and
 * to initialise rwdata if appropriate.
 */

#define ALT_NO_BOOTLOADER


#endif /* __SYSTEM_H_ */
