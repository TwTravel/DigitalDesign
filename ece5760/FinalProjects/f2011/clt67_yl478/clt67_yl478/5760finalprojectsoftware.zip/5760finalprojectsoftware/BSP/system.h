/*
 * system.h - SOPC Builder system and BSP software package information
 *
 * Machine generated for CPU 'cpu_0' in SOPC Builder design 'main'
 * SOPC Builder design path: C:/5760finalproject/main.sopcinfo
 *
 * Generated: Tue Dec 06 13:54:02 EST 2011
 */

/*
 * DO NOT MODIFY THIS FILE
 *
 * Changing this file will have subtle consequences
 * which will almost certainly lead to a nonfunctioning
 * system. If you do modify this file, be aware that your
 * changes will be overwritten and lost when this file
 * is generated again.
 *
 * DO NOT MODIFY THIS FILE
 */

/*
 * License Agreement
 *
 * Copyright (c) 2008
 * Altera Corporation, San Jose, California, USA.
 * All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 * This agreement shall be governed in all respects by the laws of the State
 * of California and by the laws of the United States of America.
 */

#ifndef __SYSTEM_H_
#define __SYSTEM_H_

/* Include definitions from linker script generator */
#include "linker.h"


/*
 * Altera_UP_SD_Card_Avalon_Interface_0 configuration
 *
 */

#define ALTERA_UP_SD_CARD_AVALON_INTERFACE_0_BASE 0x1003000
#define ALTERA_UP_SD_CARD_AVALON_INTERFACE_0_IRQ -1
#define ALTERA_UP_SD_CARD_AVALON_INTERFACE_0_IRQ_INTERRUPT_CONTROLLER_ID -1
#define ALTERA_UP_SD_CARD_AVALON_INTERFACE_0_NAME "/dev/Altera_UP_SD_Card_Avalon_Interface_0"
#define ALTERA_UP_SD_CARD_AVALON_INTERFACE_0_SPAN 1024
#define ALTERA_UP_SD_CARD_AVALON_INTERFACE_0_TYPE "Altera_UP_SD_Card_Avalon_Interface"
#define ALT_MODULE_CLASS_Altera_UP_SD_Card_Avalon_Interface_0 Altera_UP_SD_Card_Avalon_Interface


/*
 * CPU configuration
 *
 */

#define ALT_CPU_ARCHITECTURE "altera_nios2"
#define ALT_CPU_BIG_ENDIAN 0
#define ALT_CPU_BREAK_ADDR 0x1002820
#define ALT_CPU_CPU_FREQ 50000000u
#define ALT_CPU_CPU_ID_SIZE 1
#define ALT_CPU_CPU_ID_VALUE 0x0
#define ALT_CPU_CPU_IMPLEMENTATION "small"
#define ALT_CPU_DATA_ADDR_WIDTH 0x19
#define ALT_CPU_DCACHE_LINE_SIZE 0
#define ALT_CPU_DCACHE_LINE_SIZE_LOG2 0
#define ALT_CPU_DCACHE_SIZE 0
#define ALT_CPU_EXCEPTION_ADDR 0x800020
#define ALT_CPU_FLUSHDA_SUPPORTED
#define ALT_CPU_FREQ 50000000
#define ALT_CPU_HARDWARE_DIVIDE_PRESENT 0
#define ALT_CPU_HARDWARE_MULTIPLY_PRESENT 1
#define ALT_CPU_HARDWARE_MULX_PRESENT 0
#define ALT_CPU_HAS_DEBUG_CORE 1
#define ALT_CPU_HAS_DEBUG_STUB
#define ALT_CPU_HAS_JMPI_INSTRUCTION
#define ALT_CPU_ICACHE_LINE_SIZE 32
#define ALT_CPU_ICACHE_LINE_SIZE_LOG2 5
#define ALT_CPU_ICACHE_SIZE 4096
#define ALT_CPU_INST_ADDR_WIDTH 0x19
#define ALT_CPU_NAME "cpu_0"
#define ALT_CPU_RESET_ADDR 0x800000


/*
 * CPU configuration (with legacy prefix - don't use these anymore)
 *
 */

#define NIOS2_BIG_ENDIAN 0
#define NIOS2_BREAK_ADDR 0x1002820
#define NIOS2_CPU_FREQ 50000000u
#define NIOS2_CPU_ID_SIZE 1
#define NIOS2_CPU_ID_VALUE 0x0
#define NIOS2_CPU_IMPLEMENTATION "small"
#define NIOS2_DATA_ADDR_WIDTH 0x19
#define NIOS2_DCACHE_LINE_SIZE 0
#define NIOS2_DCACHE_LINE_SIZE_LOG2 0
#define NIOS2_DCACHE_SIZE 0
#define NIOS2_EXCEPTION_ADDR 0x800020
#define NIOS2_FLUSHDA_SUPPORTED
#define NIOS2_HARDWARE_DIVIDE_PRESENT 0
#define NIOS2_HARDWARE_MULTIPLY_PRESENT 1
#define NIOS2_HARDWARE_MULX_PRESENT 0
#define NIOS2_HAS_DEBUG_CORE 1
#define NIOS2_HAS_DEBUG_STUB
#define NIOS2_HAS_JMPI_INSTRUCTION
#define NIOS2_ICACHE_LINE_SIZE 32
#define NIOS2_ICACHE_LINE_SIZE_LOG2 5
#define NIOS2_ICACHE_SIZE 4096
#define NIOS2_INST_ADDR_WIDTH 0x19
#define NIOS2_RESET_ADDR 0x800000


/*
 * Define for each module class mastered by the CPU
 *
 */

#define __ALTERA_AVALON_JTAG_UART
#define __ALTERA_AVALON_NEW_SDRAM_CONTROLLER
#define __ALTERA_AVALON_PIO
#define __ALTERA_NIOS2
#define __ALTERA_UP_AVALON_VIDEO_CHARACTER_BUFFER_WITH_DMA
#define __ALTERA_UP_SD_CARD_AVALON_INTERFACE


/*
 * KEY configuration
 *
 */

#define ALT_MODULE_CLASS_KEY altera_avalon_pio
#define KEY_BASE 0x1003470
#define KEY_BIT_CLEARING_EDGE_REGISTER 0
#define KEY_BIT_MODIFYING_OUTPUT_REGISTER 0
#define KEY_CAPTURE 0
#define KEY_DATA_WIDTH 3
#define KEY_DO_TEST_BENCH_WIRING 0
#define KEY_DRIVEN_SIM_VALUE 0x0
#define KEY_EDGE_TYPE "NONE"
#define KEY_FREQ 50000000u
#define KEY_HAS_IN 1
#define KEY_HAS_OUT 0
#define KEY_HAS_TRI 0
#define KEY_IRQ -1
#define KEY_IRQ_INTERRUPT_CONTROLLER_ID -1
#define KEY_IRQ_TYPE "NONE"
#define KEY_NAME "/dev/KEY"
#define KEY_RESET_VALUE 0x0
#define KEY_SPAN 16
#define KEY_TYPE "altera_avalon_pio"


/*
 * System configuration
 *
 */

#define ALT_DEVICE_FAMILY "CYCLONEII"
#define ALT_ENHANCED_INTERRUPT_API_PRESENT
#define ALT_IRQ_BASE NULL
#define ALT_LOG_PORT "/dev/null"
#define ALT_LOG_PORT_BASE 0x0
#define ALT_LOG_PORT_DEV null
#define ALT_LOG_PORT_TYPE ""
#define ALT_NUM_EXTERNAL_INTERRUPT_CONTROLLERS 0
#define ALT_NUM_INTERNAL_INTERRUPT_CONTROLLERS 1
#define ALT_NUM_INTERRUPT_CONTROLLERS 1
#define ALT_STDERR "/dev/jtag_uart_0"
#define ALT_STDERR_BASE 0x10034c0
#define ALT_STDERR_DEV jtag_uart_0
#define ALT_STDERR_IS_JTAG_UART
#define ALT_STDERR_PRESENT
#define ALT_STDERR_TYPE "altera_avalon_jtag_uart"
#define ALT_STDIN "/dev/jtag_uart_0"
#define ALT_STDIN_BASE 0x10034c0
#define ALT_STDIN_DEV jtag_uart_0
#define ALT_STDIN_IS_JTAG_UART
#define ALT_STDIN_PRESENT
#define ALT_STDIN_TYPE "altera_avalon_jtag_uart"
#define ALT_STDOUT "/dev/jtag_uart_0"
#define ALT_STDOUT_BASE 0x10034c0
#define ALT_STDOUT_DEV jtag_uart_0
#define ALT_STDOUT_IS_JTAG_UART
#define ALT_STDOUT_PRESENT
#define ALT_STDOUT_TYPE "altera_avalon_jtag_uart"
#define ALT_SYSTEM_NAME "main"


/*
 * data_in_A_31to0 configuration
 *
 */

#define ALT_MODULE_CLASS_data_in_A_31to0 altera_avalon_pio
#define DATA_IN_A_31TO0_BASE 0x1003440
#define DATA_IN_A_31TO0_BIT_CLEARING_EDGE_REGISTER 0
#define DATA_IN_A_31TO0_BIT_MODIFYING_OUTPUT_REGISTER 0
#define DATA_IN_A_31TO0_CAPTURE 0
#define DATA_IN_A_31TO0_DATA_WIDTH 32
#define DATA_IN_A_31TO0_DO_TEST_BENCH_WIRING 0
#define DATA_IN_A_31TO0_DRIVEN_SIM_VALUE 0x0
#define DATA_IN_A_31TO0_EDGE_TYPE "NONE"
#define DATA_IN_A_31TO0_FREQ 50000000u
#define DATA_IN_A_31TO0_HAS_IN 1
#define DATA_IN_A_31TO0_HAS_OUT 0
#define DATA_IN_A_31TO0_HAS_TRI 0
#define DATA_IN_A_31TO0_IRQ -1
#define DATA_IN_A_31TO0_IRQ_INTERRUPT_CONTROLLER_ID -1
#define DATA_IN_A_31TO0_IRQ_TYPE "NONE"
#define DATA_IN_A_31TO0_NAME "/dev/data_in_A_31to0"
#define DATA_IN_A_31TO0_RESET_VALUE 0x0
#define DATA_IN_A_31TO0_SPAN 16
#define DATA_IN_A_31TO0_TYPE "altera_avalon_pio"


/*
 * data_in_A_63to32 configuration
 *
 */

#define ALT_MODULE_CLASS_data_in_A_63to32 altera_avalon_pio
#define DATA_IN_A_63TO32_BASE 0x10034a0
#define DATA_IN_A_63TO32_BIT_CLEARING_EDGE_REGISTER 0
#define DATA_IN_A_63TO32_BIT_MODIFYING_OUTPUT_REGISTER 0
#define DATA_IN_A_63TO32_CAPTURE 0
#define DATA_IN_A_63TO32_DATA_WIDTH 32
#define DATA_IN_A_63TO32_DO_TEST_BENCH_WIRING 0
#define DATA_IN_A_63TO32_DRIVEN_SIM_VALUE 0x0
#define DATA_IN_A_63TO32_EDGE_TYPE "NONE"
#define DATA_IN_A_63TO32_FREQ 50000000u
#define DATA_IN_A_63TO32_HAS_IN 1
#define DATA_IN_A_63TO32_HAS_OUT 0
#define DATA_IN_A_63TO32_HAS_TRI 0
#define DATA_IN_A_63TO32_IRQ -1
#define DATA_IN_A_63TO32_IRQ_INTERRUPT_CONTROLLER_ID -1
#define DATA_IN_A_63TO32_IRQ_TYPE "NONE"
#define DATA_IN_A_63TO32_NAME "/dev/data_in_A_63to32"
#define DATA_IN_A_63TO32_RESET_VALUE 0x0
#define DATA_IN_A_63TO32_SPAN 16
#define DATA_IN_A_63TO32_TYPE "altera_avalon_pio"


/*
 * data_in_B_31to0 configuration
 *
 */

#define ALT_MODULE_CLASS_data_in_B_31to0 altera_avalon_pio
#define DATA_IN_B_31TO0_BASE 0x1003400
#define DATA_IN_B_31TO0_BIT_CLEARING_EDGE_REGISTER 0
#define DATA_IN_B_31TO0_BIT_MODIFYING_OUTPUT_REGISTER 0
#define DATA_IN_B_31TO0_CAPTURE 0
#define DATA_IN_B_31TO0_DATA_WIDTH 32
#define DATA_IN_B_31TO0_DO_TEST_BENCH_WIRING 0
#define DATA_IN_B_31TO0_DRIVEN_SIM_VALUE 0x0
#define DATA_IN_B_31TO0_EDGE_TYPE "NONE"
#define DATA_IN_B_31TO0_FREQ 50000000u
#define DATA_IN_B_31TO0_HAS_IN 1
#define DATA_IN_B_31TO0_HAS_OUT 0
#define DATA_IN_B_31TO0_HAS_TRI 0
#define DATA_IN_B_31TO0_IRQ -1
#define DATA_IN_B_31TO0_IRQ_INTERRUPT_CONTROLLER_ID -1
#define DATA_IN_B_31TO0_IRQ_TYPE "NONE"
#define DATA_IN_B_31TO0_NAME "/dev/data_in_B_31to0"
#define DATA_IN_B_31TO0_RESET_VALUE 0x0
#define DATA_IN_B_31TO0_SPAN 16
#define DATA_IN_B_31TO0_TYPE "altera_avalon_pio"


/*
 * data_out_A_31to0 configuration
 *
 */

#define ALT_MODULE_CLASS_data_out_A_31to0 altera_avalon_pio
#define DATA_OUT_A_31TO0_BASE 0x1003410
#define DATA_OUT_A_31TO0_BIT_CLEARING_EDGE_REGISTER 0
#define DATA_OUT_A_31TO0_BIT_MODIFYING_OUTPUT_REGISTER 0
#define DATA_OUT_A_31TO0_CAPTURE 0
#define DATA_OUT_A_31TO0_DATA_WIDTH 32
#define DATA_OUT_A_31TO0_DO_TEST_BENCH_WIRING 0
#define DATA_OUT_A_31TO0_DRIVEN_SIM_VALUE 0x0
#define DATA_OUT_A_31TO0_EDGE_TYPE "NONE"
#define DATA_OUT_A_31TO0_FREQ 50000000u
#define DATA_OUT_A_31TO0_HAS_IN 0
#define DATA_OUT_A_31TO0_HAS_OUT 1
#define DATA_OUT_A_31TO0_HAS_TRI 0
#define DATA_OUT_A_31TO0_IRQ -1
#define DATA_OUT_A_31TO0_IRQ_INTERRUPT_CONTROLLER_ID -1
#define DATA_OUT_A_31TO0_IRQ_TYPE "NONE"
#define DATA_OUT_A_31TO0_NAME "/dev/data_out_A_31to0"
#define DATA_OUT_A_31TO0_RESET_VALUE 0x0
#define DATA_OUT_A_31TO0_SPAN 16
#define DATA_OUT_A_31TO0_TYPE "altera_avalon_pio"


/*
 * data_out_B_31to0 configuration
 *
 */

#define ALT_MODULE_CLASS_data_out_B_31to0 altera_avalon_pio
#define DATA_OUT_B_31TO0_BASE 0x1003420
#define DATA_OUT_B_31TO0_BIT_CLEARING_EDGE_REGISTER 0
#define DATA_OUT_B_31TO0_BIT_MODIFYING_OUTPUT_REGISTER 0
#define DATA_OUT_B_31TO0_CAPTURE 0
#define DATA_OUT_B_31TO0_DATA_WIDTH 32
#define DATA_OUT_B_31TO0_DO_TEST_BENCH_WIRING 0
#define DATA_OUT_B_31TO0_DRIVEN_SIM_VALUE 0x0
#define DATA_OUT_B_31TO0_EDGE_TYPE "NONE"
#define DATA_OUT_B_31TO0_FREQ 50000000u
#define DATA_OUT_B_31TO0_HAS_IN 0
#define DATA_OUT_B_31TO0_HAS_OUT 1
#define DATA_OUT_B_31TO0_HAS_TRI 0
#define DATA_OUT_B_31TO0_IRQ -1
#define DATA_OUT_B_31TO0_IRQ_INTERRUPT_CONTROLLER_ID -1
#define DATA_OUT_B_31TO0_IRQ_TYPE "NONE"
#define DATA_OUT_B_31TO0_NAME "/dev/data_out_B_31to0"
#define DATA_OUT_B_31TO0_RESET_VALUE 0x0
#define DATA_OUT_B_31TO0_SPAN 16
#define DATA_OUT_B_31TO0_TYPE "altera_avalon_pio"


/*
 * data_out_B_63to32 configuration
 *
 */

#define ALT_MODULE_CLASS_data_out_B_63to32 altera_avalon_pio
#define DATA_OUT_B_63TO32_BASE 0x10034b0
#define DATA_OUT_B_63TO32_BIT_CLEARING_EDGE_REGISTER 0
#define DATA_OUT_B_63TO32_BIT_MODIFYING_OUTPUT_REGISTER 0
#define DATA_OUT_B_63TO32_CAPTURE 0
#define DATA_OUT_B_63TO32_DATA_WIDTH 32
#define DATA_OUT_B_63TO32_DO_TEST_BENCH_WIRING 0
#define DATA_OUT_B_63TO32_DRIVEN_SIM_VALUE 0x0
#define DATA_OUT_B_63TO32_EDGE_TYPE "NONE"
#define DATA_OUT_B_63TO32_FREQ 50000000u
#define DATA_OUT_B_63TO32_HAS_IN 0
#define DATA_OUT_B_63TO32_HAS_OUT 1
#define DATA_OUT_B_63TO32_HAS_TRI 0
#define DATA_OUT_B_63TO32_IRQ -1
#define DATA_OUT_B_63TO32_IRQ_INTERRUPT_CONTROLLER_ID -1
#define DATA_OUT_B_63TO32_IRQ_TYPE "NONE"
#define DATA_OUT_B_63TO32_NAME "/dev/data_out_B_63to32"
#define DATA_OUT_B_63TO32_RESET_VALUE 0x0
#define DATA_OUT_B_63TO32_SPAN 16
#define DATA_OUT_B_63TO32_TYPE "altera_avalon_pio"


/*
 * data_out_C_31to0 configuration
 *
 */

#define ALT_MODULE_CLASS_data_out_C_31to0 altera_avalon_pio
#define DATA_OUT_C_31TO0_BASE 0x1003430
#define DATA_OUT_C_31TO0_BIT_CLEARING_EDGE_REGISTER 0
#define DATA_OUT_C_31TO0_BIT_MODIFYING_OUTPUT_REGISTER 0
#define DATA_OUT_C_31TO0_CAPTURE 0
#define DATA_OUT_C_31TO0_DATA_WIDTH 32
#define DATA_OUT_C_31TO0_DO_TEST_BENCH_WIRING 0
#define DATA_OUT_C_31TO0_DRIVEN_SIM_VALUE 0x0
#define DATA_OUT_C_31TO0_EDGE_TYPE "NONE"
#define DATA_OUT_C_31TO0_FREQ 50000000u
#define DATA_OUT_C_31TO0_HAS_IN 0
#define DATA_OUT_C_31TO0_HAS_OUT 1
#define DATA_OUT_C_31TO0_HAS_TRI 0
#define DATA_OUT_C_31TO0_IRQ -1
#define DATA_OUT_C_31TO0_IRQ_INTERRUPT_CONTROLLER_ID -1
#define DATA_OUT_C_31TO0_IRQ_TYPE "NONE"
#define DATA_OUT_C_31TO0_NAME "/dev/data_out_C_31to0"
#define DATA_OUT_C_31TO0_RESET_VALUE 0x0
#define DATA_OUT_C_31TO0_SPAN 16
#define DATA_OUT_C_31TO0_TYPE "altera_avalon_pio"


/*
 * data_out_C_63to32 configuration
 *
 */

#define ALT_MODULE_CLASS_data_out_C_63to32 altera_avalon_pio
#define DATA_OUT_C_63TO32_BASE 0x1003490
#define DATA_OUT_C_63TO32_BIT_CLEARING_EDGE_REGISTER 0
#define DATA_OUT_C_63TO32_BIT_MODIFYING_OUTPUT_REGISTER 0
#define DATA_OUT_C_63TO32_CAPTURE 0
#define DATA_OUT_C_63TO32_DATA_WIDTH 32
#define DATA_OUT_C_63TO32_DO_TEST_BENCH_WIRING 0
#define DATA_OUT_C_63TO32_DRIVEN_SIM_VALUE 0x0
#define DATA_OUT_C_63TO32_EDGE_TYPE "NONE"
#define DATA_OUT_C_63TO32_FREQ 50000000u
#define DATA_OUT_C_63TO32_HAS_IN 0
#define DATA_OUT_C_63TO32_HAS_OUT 1
#define DATA_OUT_C_63TO32_HAS_TRI 0
#define DATA_OUT_C_63TO32_IRQ -1
#define DATA_OUT_C_63TO32_IRQ_INTERRUPT_CONTROLLER_ID -1
#define DATA_OUT_C_63TO32_IRQ_TYPE "NONE"
#define DATA_OUT_C_63TO32_NAME "/dev/data_out_C_63to32"
#define DATA_OUT_C_63TO32_RESET_VALUE 0x0
#define DATA_OUT_C_63TO32_SPAN 16
#define DATA_OUT_C_63TO32_TYPE "altera_avalon_pio"


/*
 * hal configuration
 *
 */

#define ALT_MAX_FD 32
#define ALT_SYS_CLK none
#define ALT_TIMESTAMP_CLK none


/*
 * jtag_uart_0 configuration
 *
 */

#define ALT_MODULE_CLASS_jtag_uart_0 altera_avalon_jtag_uart
#define JTAG_UART_0_BASE 0x10034c0
#define JTAG_UART_0_IRQ 0
#define JTAG_UART_0_IRQ_INTERRUPT_CONTROLLER_ID 0
#define JTAG_UART_0_NAME "/dev/jtag_uart_0"
#define JTAG_UART_0_READ_DEPTH 64
#define JTAG_UART_0_READ_THRESHOLD 8
#define JTAG_UART_0_SPAN 8
#define JTAG_UART_0_TYPE "altera_avalon_jtag_uart"
#define JTAG_UART_0_WRITE_DEPTH 64
#define JTAG_UART_0_WRITE_THRESHOLD 8


/*
 * module_finish configuration
 *
 */

#define ALT_MODULE_CLASS_module_finish altera_avalon_pio
#define MODULE_FINISH_BASE 0x1003460
#define MODULE_FINISH_BIT_CLEARING_EDGE_REGISTER 0
#define MODULE_FINISH_BIT_MODIFYING_OUTPUT_REGISTER 0
#define MODULE_FINISH_CAPTURE 0
#define MODULE_FINISH_DATA_WIDTH 1
#define MODULE_FINISH_DO_TEST_BENCH_WIRING 0
#define MODULE_FINISH_DRIVEN_SIM_VALUE 0x0
#define MODULE_FINISH_EDGE_TYPE "NONE"
#define MODULE_FINISH_FREQ 50000000u
#define MODULE_FINISH_HAS_IN 1
#define MODULE_FINISH_HAS_OUT 0
#define MODULE_FINISH_HAS_TRI 0
#define MODULE_FINISH_IRQ -1
#define MODULE_FINISH_IRQ_INTERRUPT_CONTROLLER_ID -1
#define MODULE_FINISH_IRQ_TYPE "NONE"
#define MODULE_FINISH_NAME "/dev/module_finish"
#define MODULE_FINISH_RESET_VALUE 0x0
#define MODULE_FINISH_SPAN 16
#define MODULE_FINISH_TYPE "altera_avalon_pio"


/*
 * module_reset configuration
 *
 */

#define ALT_MODULE_CLASS_module_reset altera_avalon_pio
#define MODULE_RESET_BASE 0x1003450
#define MODULE_RESET_BIT_CLEARING_EDGE_REGISTER 0
#define MODULE_RESET_BIT_MODIFYING_OUTPUT_REGISTER 0
#define MODULE_RESET_CAPTURE 0
#define MODULE_RESET_DATA_WIDTH 1
#define MODULE_RESET_DO_TEST_BENCH_WIRING 0
#define MODULE_RESET_DRIVEN_SIM_VALUE 0x0
#define MODULE_RESET_EDGE_TYPE "NONE"
#define MODULE_RESET_FREQ 50000000u
#define MODULE_RESET_HAS_IN 0
#define MODULE_RESET_HAS_OUT 1
#define MODULE_RESET_HAS_TRI 0
#define MODULE_RESET_IRQ -1
#define MODULE_RESET_IRQ_INTERRUPT_CONTROLLER_ID -1
#define MODULE_RESET_IRQ_TYPE "NONE"
#define MODULE_RESET_NAME "/dev/module_reset"
#define MODULE_RESET_RESET_VALUE 0x0
#define MODULE_RESET_SPAN 16
#define MODULE_RESET_TYPE "altera_avalon_pio"


/*
 * module_select configuration
 *
 */

#define ALT_MODULE_CLASS_module_select altera_avalon_pio
#define MODULE_SELECT_BASE 0x1003480
#define MODULE_SELECT_BIT_CLEARING_EDGE_REGISTER 0
#define MODULE_SELECT_BIT_MODIFYING_OUTPUT_REGISTER 0
#define MODULE_SELECT_CAPTURE 0
#define MODULE_SELECT_DATA_WIDTH 4
#define MODULE_SELECT_DO_TEST_BENCH_WIRING 0
#define MODULE_SELECT_DRIVEN_SIM_VALUE 0x0
#define MODULE_SELECT_EDGE_TYPE "NONE"
#define MODULE_SELECT_FREQ 50000000u
#define MODULE_SELECT_HAS_IN 0
#define MODULE_SELECT_HAS_OUT 1
#define MODULE_SELECT_HAS_TRI 0
#define MODULE_SELECT_IRQ -1
#define MODULE_SELECT_IRQ_INTERRUPT_CONTROLLER_ID -1
#define MODULE_SELECT_IRQ_TYPE "NONE"
#define MODULE_SELECT_NAME "/dev/module_select"
#define MODULE_SELECT_RESET_VALUE 0x0
#define MODULE_SELECT_SPAN 16
#define MODULE_SELECT_TYPE "altera_avalon_pio"


/*
 * sdram_0 configuration
 *
 */

#define ALT_MODULE_CLASS_sdram_0 altera_avalon_new_sdram_controller
#define SDRAM_0_BASE 0x800000
#define SDRAM_0_CAS_LATENCY 3
#define SDRAM_0_CONTENTS_INFO ""
#define SDRAM_0_INIT_NOP_DELAY 0.0
#define SDRAM_0_INIT_REFRESH_COMMANDS 2
#define SDRAM_0_IRQ -1
#define SDRAM_0_IRQ_INTERRUPT_CONTROLLER_ID -1
#define SDRAM_0_IS_INITIALIZED 1
#define SDRAM_0_NAME "/dev/sdram_0"
#define SDRAM_0_POWERUP_DELAY 100.0
#define SDRAM_0_REFRESH_PERIOD 15.625
#define SDRAM_0_REGISTER_DATA_IN 1
#define SDRAM_0_SDRAM_ADDR_WIDTH 0x16
#define SDRAM_0_SDRAM_BANK_WIDTH 2
#define SDRAM_0_SDRAM_COL_WIDTH 8
#define SDRAM_0_SDRAM_DATA_WIDTH 16
#define SDRAM_0_SDRAM_NUM_BANKS 4
#define SDRAM_0_SDRAM_NUM_CHIPSELECTS 1
#define SDRAM_0_SDRAM_ROW_WIDTH 12
#define SDRAM_0_SHARED_DATA 0
#define SDRAM_0_SIM_MODEL_BASE 0
#define SDRAM_0_SPAN 8388608
#define SDRAM_0_STARVATION_INDICATOR 0
#define SDRAM_0_TRISTATE_BRIDGE_SLAVE ""
#define SDRAM_0_TYPE "altera_avalon_new_sdram_controller"
#define SDRAM_0_T_AC 5.5
#define SDRAM_0_T_MRD 3
#define SDRAM_0_T_RCD 20.0
#define SDRAM_0_T_RFC 70.0
#define SDRAM_0_T_RP 20.0
#define SDRAM_0_T_WR 14.0


/*
 * video_character_buffer_with_dma_0_avalon_char_buffer_slave configuration
 *
 */

#define ALT_MODULE_CLASS_video_character_buffer_with_dma_0_avalon_char_buffer_slave altera_up_avalon_video_character_buffer_with_dma
#define VIDEO_CHARACTER_BUFFER_WITH_DMA_0_AVALON_CHAR_BUFFER_SLAVE_BASE 0x1000000
#define VIDEO_CHARACTER_BUFFER_WITH_DMA_0_AVALON_CHAR_BUFFER_SLAVE_IRQ -1
#define VIDEO_CHARACTER_BUFFER_WITH_DMA_0_AVALON_CHAR_BUFFER_SLAVE_IRQ_INTERRUPT_CONTROLLER_ID -1
#define VIDEO_CHARACTER_BUFFER_WITH_DMA_0_AVALON_CHAR_BUFFER_SLAVE_NAME "/dev/video_character_buffer_with_dma_0_avalon_char_buffer_slave"
#define VIDEO_CHARACTER_BUFFER_WITH_DMA_0_AVALON_CHAR_BUFFER_SLAVE_SPAN 8192
#define VIDEO_CHARACTER_BUFFER_WITH_DMA_0_AVALON_CHAR_BUFFER_SLAVE_TYPE "altera_up_avalon_video_character_buffer_with_dma"


/*
 * video_character_buffer_with_dma_0_avalon_char_control_slave configuration
 *
 */

#define ALT_MODULE_CLASS_video_character_buffer_with_dma_0_avalon_char_control_slave altera_up_avalon_video_character_buffer_with_dma
#define VIDEO_CHARACTER_BUFFER_WITH_DMA_0_AVALON_CHAR_CONTROL_SLAVE_BASE 0x10034c8
#define VIDEO_CHARACTER_BUFFER_WITH_DMA_0_AVALON_CHAR_CONTROL_SLAVE_IRQ -1
#define VIDEO_CHARACTER_BUFFER_WITH_DMA_0_AVALON_CHAR_CONTROL_SLAVE_IRQ_INTERRUPT_CONTROLLER_ID -1
#define VIDEO_CHARACTER_BUFFER_WITH_DMA_0_AVALON_CHAR_CONTROL_SLAVE_NAME "/dev/video_character_buffer_with_dma_0_avalon_char_control_slave"
#define VIDEO_CHARACTER_BUFFER_WITH_DMA_0_AVALON_CHAR_CONTROL_SLAVE_SPAN 8
#define VIDEO_CHARACTER_BUFFER_WITH_DMA_0_AVALON_CHAR_CONTROL_SLAVE_TYPE "altera_up_avalon_video_character_buffer_with_dma"

#endif /* __SYSTEM_H_ */
