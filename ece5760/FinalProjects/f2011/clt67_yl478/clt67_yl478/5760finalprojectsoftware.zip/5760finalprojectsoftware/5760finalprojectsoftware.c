#include "system.h"
#include <stdio.h>
#include "altera_avalon_pio_regs.h"
#include "alt_types.h"

#include <stdlib.h>
#include <string.h>

#include "altera_up_sd_card_avalon_interface_modified.h"
#include "altera_up_avalon_video_character_buffer_with_dma.h"

#define VGA_Y_HEADER 0
#define VGA_Y_START 2
#define VGA_Y_END 58
#define VGA_X_START 2
#define VGA_X_END 77
#define BUFFER_LENGTH 10000

alt_up_sd_card_dev *device_reference;
alt_up_char_buffer_dev *char_buffer_reference;

char connected = 0;
short int file_handle;
char filename[13];
unsigned long long generated_primes[2]; //generated prime number to be used for encryption
unsigned long long encryption_key, decryption_key, encryption_exponent;
unsigned char vga_char_x;
unsigned char vga_char_y;
unsigned char input_buffer[10000];
unsigned char output_buffer[10000];
unsigned long primality_test_accuracy;

/****************************************************************************************
 * Subroutine to send a string of text to the VGA monitor 
 * from Altera University Program video examples
****************************************************************************************/
void VGA_text(int x, int y, char * text_ptr)
{
	int offset;
	/* Declare volatile pointer to char buffer (volatile means that IO load
	   and store instructions will be used to access these pointer locations, 
	   instead of regular memory loads and stores) */
  	volatile char * character_buffer = (char *) VIDEO_CHARACTER_BUFFER_WITH_DMA_0_AVALON_CHAR_BUFFER_SLAVE_BASE;	// VGA character buffer

	/* assume that the text string fits on one line */
	offset = (y << 7) + x;
	while ( *(text_ptr) )
	{
		*(character_buffer + offset) = *(text_ptr);	// write to the character buffer
		++text_ptr;
		++offset;
	}
}

//encrypt message base with encryption key modulo and exponent exponent, returns the encrypted message result
//or decrypt encrypted message base with encryption key modulo and decryption key exponent, returns the message result
//base, modulo and exponent are dispatched to a hardware decrypter, which returns result when finish is set high
unsigned long encrypt_decrypt(unsigned long base, unsigned long long modulo, unsigned long long exponent) {
	unsigned long long result_63to32, result_31to0, result;
	IOWR_ALTERA_AVALON_PIO_DATA(MODULE_SELECT_BASE,1);
	IOWR_ALTERA_AVALON_PIO_DATA(DATA_OUT_A_31TO0_BASE,base);
	IOWR_ALTERA_AVALON_PIO_DATA(DATA_OUT_C_31TO0_BASE,modulo & 0xffffffff);
	IOWR_ALTERA_AVALON_PIO_DATA(DATA_OUT_C_63TO32_BASE,modulo >> 32);
	IOWR_ALTERA_AVALON_PIO_DATA(DATA_OUT_B_31TO0_BASE,exponent & 0xffffffff);
	IOWR_ALTERA_AVALON_PIO_DATA(DATA_OUT_B_63TO32_BASE,exponent >> 32);
	IOWR_ALTERA_AVALON_PIO_DATA(MODULE_RESET_BASE,1);
	IOWR_ALTERA_AVALON_PIO_DATA(MODULE_RESET_BASE,0);
	while (IORD_ALTERA_AVALON_PIO_DATA(MODULE_FINISH_BASE) != 1); //stall until module is finished
	result_63to32 = IORD_ALTERA_AVALON_PIO_DATA(DATA_IN_A_63TO32_BASE);
	result_31to0 = IORD_ALTERA_AVALON_PIO_DATA(DATA_IN_A_31TO0_BASE);
	result = (result_63to32 << 32) | (result_31to0 & 0xffffffff);
	return result;
}

//generates primes using Miller Rabin primality test
void generate_primes(void) {
	unsigned long long n;
	char text_buffer[80];
	vga_char_y = 2;
	generated_primes[0] = 0;
	generated_primes[1] = 0;
	n = 3;
	IOWR_ALTERA_AVALON_PIO_DATA(MODULE_SELECT_BASE,3);
	IOWR_ALTERA_AVALON_PIO_DATA(DATA_OUT_B_31TO0_BASE,primality_test_accuracy);
	VGA_text(2, 0,"Generating Primes -- KEY1: Save Prime , KEY3: Exit");
	while (1) {
		IOWR_ALTERA_AVALON_PIO_DATA(DATA_OUT_A_31TO0_BASE,n);
		IOWR_ALTERA_AVALON_PIO_DATA(MODULE_RESET_BASE,1);
		IOWR_ALTERA_AVALON_PIO_DATA(MODULE_RESET_BASE,0);
		while (IORD_ALTERA_AVALON_PIO_DATA(MODULE_FINISH_BASE) != 1); //stall until module is finished
		if (IORD_ALTERA_AVALON_PIO_DATA(DATA_IN_A_31TO0_BASE) == 1) {
			//printf("%llu\n", n);
			sprintf(text_buffer, "%llu", n);
			VGA_text(2, vga_char_y++, text_buffer);
			if (IORD_ALTERA_AVALON_PIO_DATA(KEY_BASE) == 0x6) {
				generated_primes[1] = generated_primes[0];
				generated_primes[0] = n;
				printf("Primes to be used: %llu , %llu\n", generated_primes[0], generated_primes[1]);
				sprintf(text_buffer, "Primes to be used: %llu , %llu", generated_primes[0], generated_primes[1]);
				VGA_text(2, 1, text_buffer);
				while (IORD_ALTERA_AVALON_PIO_DATA(KEY_BASE) != 0x7) ; //wait until all keys are released
			}
			if (vga_char_y > 58) vga_char_y = 2;
		}
		n = n + 2;
		if (IORD_ALTERA_AVALON_PIO_DATA(KEY_BASE) == 0x3) { //3'b011 KEY3 pressed, exit from prime generation
			while (IORD_ALTERA_AVALON_PIO_DATA(KEY_BASE) != 0x7) ; //wait until all keys are released
			return;
		}
	}
}

//uses the extended euclidean algorithm to generate the encryption exponent and decryption key
void generate_e_and_d(void) {
	unsigned long long d_63to32, d_31to0;
	IOWR_ALTERA_AVALON_PIO_DATA(MODULE_SELECT_BASE,2);
	IOWR_ALTERA_AVALON_PIO_DATA(DATA_OUT_A_31TO0_BASE,generated_primes[0]);
	IOWR_ALTERA_AVALON_PIO_DATA(DATA_OUT_B_31TO0_BASE,generated_primes[1]);
	IOWR_ALTERA_AVALON_PIO_DATA(MODULE_RESET_BASE,1);
	IOWR_ALTERA_AVALON_PIO_DATA(MODULE_RESET_BASE,0);
	while (IORD_ALTERA_AVALON_PIO_DATA(MODULE_FINISH_BASE) != 1); //stall until module is finished
	encryption_exponent = IORD_ALTERA_AVALON_PIO_DATA(DATA_IN_B_31TO0_BASE);\
	d_63to32 = IORD_ALTERA_AVALON_PIO_DATA(DATA_IN_A_63TO32_BASE);
	d_31to0 = IORD_ALTERA_AVALON_PIO_DATA(DATA_IN_A_31TO0_BASE);
	decryption_key = (d_63to32 << 32) | (d_31to0 & 0xffffffff);
	return;
}

//encrypt the contents of the input buffer
void encrypt_buffer(void) {
	unsigned long msg_num;
	unsigned long encrypted_msg_num, decrypted_msg_num;
	unsigned long buffer_index, encrypted_msg_index;
	for (buffer_index = 0; buffer_index < BUFFER_LENGTH; buffer_index += 2) {
		encrypted_msg_index = buffer_index << 1;
		msg_num = (input_buffer[buffer_index] << 8*1 | input_buffer[buffer_index+1]) & 0xffff;
		encrypted_msg_num = encrypt_decrypt(msg_num, encryption_key, encryption_exponent); //encrypt the number
		decrypted_msg_num = encrypt_decrypt(encrypted_msg_num, encryption_key, decryption_key);
		output_buffer[encrypted_msg_index] = (unsigned char)(encrypted_msg_num >> 8*3 & 0xff);
		output_buffer[encrypted_msg_index+1] = (unsigned char)(encrypted_msg_num >> 8*2 & 0xff);
		output_buffer[encrypted_msg_index+2] = (unsigned char)(encrypted_msg_num >> 8*1 & 0xff);
		output_buffer[encrypted_msg_index+3] = (unsigned char)(encrypted_msg_num & 0xff);
	}
	output_buffer[buffer_index << 1] = '\0'; //terminate the string in output_buffer
}

//decrypt the contents of the input buffer
void decrypt_buffer(void) {
	unsigned long msg_num;
	unsigned long encrypted_msg_num, decrypted_msg_num;
	unsigned long input_buffer_index, output_buffer_index;
	for (input_buffer_index = 0; input_buffer_index < BUFFER_LENGTH; input_buffer_index += 4) {
		output_buffer_index = input_buffer_index >> 1;
		encrypted_msg_num = input_buffer[input_buffer_index] << 8*3 | input_buffer[input_buffer_index+1] << 8*2 | input_buffer[input_buffer_index+2] << 8*1 | input_buffer[input_buffer_index+3];
		decrypted_msg_num = encrypt_decrypt(encrypted_msg_num, encryption_key, decryption_key);
		output_buffer[output_buffer_index] = (unsigned char)(decrypted_msg_num >> 8*1 & 0xff);
		output_buffer[output_buffer_index+1] = (unsigned char)(decrypted_msg_num & 0xff);
	}
	//printf("%s\n", output_buffer);
}

//clear the buffer
void clear_buffer(char* buffer_ptr) {
	int i;
	for (i = 0; i < BUFFER_LENGTH; i++)
		buffer_ptr[i] = 0;
}

//prints the buffer to the VGA monitor
void print_buffer(char* buffer_ptr) {
	int i;
	vga_char_x = VGA_X_START;
	vga_char_y = VGA_Y_START;
	for (i = 0; i < BUFFER_LENGTH; i++) {
		if (vga_char_y > VGA_Y_END) break;
		if (buffer_ptr[i] == '\r') ; //ignore the return character
		else {
			if (buffer_ptr[i] == '\n') {
				vga_char_y++;
				vga_char_x = VGA_X_START;
			} else {
				alt_up_char_buffer_draw(char_buffer_reference, buffer_ptr[i], vga_char_x, vga_char_y);
			}
			if (vga_char_x < VGA_X_END)	{
				vga_char_x++;
			} else {
				vga_char_y++;
				vga_char_x = VGA_X_START;
			}
		}
	}
}

//loads file from SD card into input buffer
void load_file(void) {
	unsigned int i;
	short int sd_result;
	short int sd_read_buffer;
	unsigned short encryption_buffer_index;
	vga_char_x = 2;
	vga_char_y = 1;
	device_reference = alt_up_sd_card_open_dev(ALTERA_UP_SD_CARD_AVALON_INTERFACE_0_NAME);
	if (device_reference != NULL) {
		if ((connected == 0) && (alt_up_sd_card_is_Present())) {
			printf("Card connected.\n");
			if (alt_up_sd_card_is_FAT16()) {
				printf("FAT16 file system detected.\n");
				sd_result = alt_up_sd_card_find_first(".", filename);
				sd_result = alt_up_sd_card_find_next(filename);
				printf("file=%s\n",filename);
				file_handle = alt_up_sd_card_fopen(filename, 0); //open file, do not create file if it is not found
				encryption_buffer_index = 0;
				sd_read_buffer = alt_up_sd_card_read(file_handle);
				
				//while (sd_read_buffer > -1) {
				for (i = 0; i < BUFFER_LENGTH; i++) {
					input_buffer[encryption_buffer_index++] = sd_read_buffer;
					//sd_read_buffer = alt_up_sd_card_read(file_handle);
					sd_read_buffer = alt_up_sd_card_read_modified(file_handle);
				}
				alt_up_sd_card_fclose(file_handle); //close the file
			} else {
			printf("Unknown file system.\n");
			return; //operation failed
			}
		} else {
			printf("No SD card detected\n");
			return; //operation failed
		}
		return;
	}
	printf("No SD card module in SOPC\n");
	return;
}

//writes output buffer to file on SD card
void write_file(void) {
	short int sd_result;
	short int sd_read_buffer;
	unsigned short buffer_index;
	vga_char_x = 2;
	vga_char_y = 1;
	device_reference = alt_up_sd_card_open_dev(ALTERA_UP_SD_CARD_AVALON_INTERFACE_0_NAME);
	if (device_reference != NULL) {
		if ((connected == 0) && (alt_up_sd_card_is_Present())) {
			printf("Card connected.\n");
			if (alt_up_sd_card_is_FAT16()) {
				printf("FAT16 file system detected.\n");
				sd_result = alt_up_sd_card_find_first(".", filename);
				sd_result = alt_up_sd_card_find_next(filename);
				printf("file=%s\n",filename);
				file_handle = alt_up_sd_card_fopen(filename, 0); //open file, do not create file if it is not found
				for (buffer_index = 0; buffer_index < BUFFER_LENGTH; buffer_index++) {
					alt_up_sd_card_write(file_handle, output_buffer[buffer_index]);
				}
				alt_up_sd_card_fclose(file_handle); //close the file
			} else {
			printf("Unknown file system.\n");
			return; //operation failed
			}
		} else {
			printf("No SD card detected\n");
			return; //operation failed
		}
		return;
	}
	printf("No SD card module in SOPC\n");
	return;
}

//encrypts or decrypts the data in input_buffer
//outputs the resulting data to output_buffer
void encrypt_decrypt_buffer(void) {
	char button_pressed = 0x7;
	VGA_text(2, 0, "KEY1: Decrypt , KEY2: Encrypt , KEY3: Exit");
	while (button_pressed == 0x7) button_pressed = IORD_ALTERA_AVALON_PIO_DATA(KEY_BASE); //wait for input, buttons are active low
	while (IORD_ALTERA_AVALON_PIO_DATA(KEY_BASE) != 0x7) ; //wait until keys are released
	switch (button_pressed) {
		case 0x6: //3'b110 KEY1 pressed, decrypt
			decrypt_buffer();
			alt_up_char_buffer_clear(char_buffer_reference);
			print_buffer(output_buffer);
			VGA_text(2, 0, "Decrypted -- KEY3: Exit");
			write_file();
			while (IORD_ALTERA_AVALON_PIO_DATA(KEY_BASE) != 0x3) ; //wait for KEY3 to be pressed, exit from open file
			while (IORD_ALTERA_AVALON_PIO_DATA(KEY_BASE) != 0x7) ; //wait until all keys are released	
			break;
		case 0x5: //3'b101 KEY2 pressed, encrypt
			encrypt_buffer();
			alt_up_char_buffer_clear(char_buffer_reference);
			print_buffer(output_buffer);
			VGA_text(2, 0, "Encrypted -- KEY3: Exit");
			write_file();
			while (IORD_ALTERA_AVALON_PIO_DATA(KEY_BASE) != 0x3) ; //wait for KEY3 to be pressed, exit from open file
			while (IORD_ALTERA_AVALON_PIO_DATA(KEY_BASE) != 0x7) ; //wait until all keys are released
			break;
		case 0x3: //3'b011 KEY3 pressed, exit
			break;
		default: printf("More than one button pressed\n");
	}
	clear_buffer(input_buffer);
	clear_buffer(output_buffer);
	return;
}

//the main function, program loops endlessly in the while loop
int main(void) {
	char button_pressed;
	char text_buffer[80];
	char_buffer_reference = alt_up_char_buffer_open_dev(VIDEO_CHARACTER_BUFFER_WITH_DMA_0_AVALON_CHAR_BUFFER_SLAVE_NAME);
	alt_up_char_buffer_init(char_buffer_reference);
	char message_block[4];
	unsigned long long testmsg = 1819;
	unsigned long encrypted_msg_num;
	unsigned long decrypted_msg_num;
	primality_test_accuracy = 100;
	while (1) {
		alt_up_char_buffer_clear(char_buffer_reference);
		button_pressed = 0x7; //reset button_pressed to all keys released
		printf("KEY1: Generate Primes , KEY2: Open File , KEY3: Console Input\n");
		VGA_text(2, 0, "KEY1: Generate Primes , KEY2: Open File , KEY3: Console Input");
		sprintf(text_buffer, "Primes: %llu , %llu", generated_primes[0], generated_primes[1]);
		VGA_text(2, 1, text_buffer);
		sprintf(text_buffer, "Encryption Modulus: %llu", encryption_key);
		VGA_text(2, 2, text_buffer);
		sprintf(text_buffer, "Encryption Exponent: %llu", encryption_exponent);
		VGA_text(2, 3, text_buffer);
		sprintf(text_buffer, "Decryption Exponent: %llu", decryption_key);
		VGA_text(2, 4, text_buffer);
		if (encryption_key > 0xffffffff) {
			VGA_text(2, 5, "Warning! Encryption key is too big for encryption/decryption module to support");
			VGA_text(2, 6, "due to insufficient logic elements");
		}
		while (button_pressed == 0x7) button_pressed = IORD_ALTERA_AVALON_PIO_DATA(KEY_BASE); //wait for input, buttons are active low
		while (IORD_ALTERA_AVALON_PIO_DATA(KEY_BASE) != 0x7) ; //wait until keys are released
		alt_up_char_buffer_clear(char_buffer_reference);
		switch (button_pressed) {
			case 0x6: //3'b110 KEY1 pressed, generate primes
				generate_primes();
				encryption_key = generated_primes[0]*generated_primes[1];
				generate_e_and_d();
				printf(" Public encryption key = %llu\n encryption exponent = %llu\n Decryption key = %llu\n", encryption_key, encryption_exponent, decryption_key);
				break;
			case 0x5: //3'b101 KEY2 pressed, open file
				load_file();
				print_buffer(input_buffer);
				encrypt_decrypt_buffer();				
				break;
			case 0x3: //3'b011 KEY3 pressed, console input
				VGA_text(2, 5, "Console Input Mode");
				printf("Enter Encryption Modulus\n");
				scanf("%llu", &encryption_key);
				printf("Enter Encryption Exponent\n");
				scanf("%llu", &encryption_exponent);
				printf("Enter Decryption Key\n");
				scanf("%llu", &decryption_key);
				printf("Enter Accuracy of Primality Test\n");
				scanf("%lu", &primality_test_accuracy);
				generated_primes[0] = 0;
				generated_primes[1] = 0;
				break;
			default: printf("More than one button pressed\n");
		}
	}
}

//load file routine that loads until an end of string character in the file. It does not work properly when reading
//an encrpted file because encrypted data can take the form of end of string characters.
/*

void load_file(void) {
	short int sd_result;
	short int sd_read_buffer;
	unsigned short encryption_buffer_index;
	vga_char_x = 2;
	vga_char_y = 1;
	device_reference = alt_up_sd_card_open_dev(ALTERA_UP_SD_CARD_AVALON_INTERFACE_0_NAME);
	if (device_reference != NULL) {
		if ((connected == 0) && (alt_up_sd_card_is_Present())) {
			printf("Card connected.\n");
			if (alt_up_sd_card_is_FAT16()) {
				printf("FAT16 file system detected.\n");
				sd_result = alt_up_sd_card_find_first(".", filename);
				sd_result = alt_up_sd_card_find_next(filename);
				printf("file=%s\n",filename);
				file_handle = alt_up_sd_card_fopen(filename, 0); //open file, do not create file if it is not found
				encryption_buffer_index = 0;
				sd_read_buffer = alt_up_sd_card_read(file_handle);
				while (sd_read_buffer > -1) {
					input_buffer[encryption_buffer_index++] = sd_read_buffer;
					sd_read_buffer = alt_up_sd_card_read(file_handle);
				}
				alt_up_sd_card_fclose(file_handle); //close the file
			} else {
			printf("Unknown file system.\n");
			return; //operation failed
			}
		} else {
			printf("No SD card detected\n");
			return; //operation failed
		}
		return;
	}
	printf("No SD card module in SOPC\n");
	return;
}
*/