/*
 * system.h - SOPC Builder system and BSP software package information
 *
 * Machine generated for CPU 'cpu' in SOPC Builder design 'NIOS'
 * SOPC Builder design path: C:/FP_12.5_1_freeze_bars/NIOS.sopcinfo
 *
 * Generated: Tue Dec 06 20:39:37 EST 2011
 */

/*
 * DO NOT MODIFY THIS FILE
 *
 * Changing this file will have subtle consequences
 * which will almost certainly lead to a nonfunctioning
 * system. If you do modify this file, be aware that your
 * changes will be overwritten and lost when this file
 * is generated again.
 *
 * DO NOT MODIFY THIS FILE
 */

/*
 * License Agreement
 *
 * Copyright (c) 2008
 * Altera Corporation, San Jose, California, USA.
 * All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 * This agreement shall be governed in all respects by the laws of the State
 * of California and by the laws of the United States of America.
 */

#ifndef __SYSTEM_H_
#define __SYSTEM_H_

/* Include definitions from linker script generator */
#include "linker.h"


/*
 * CPU configuration
 *
 */

#define ALT_CPU_ARCHITECTURE "altera_nios2"
#define ALT_CPU_BIG_ENDIAN 0
#define ALT_CPU_BREAK_ADDR 0x820
#define ALT_CPU_CPU_FREQ 50000000u
#define ALT_CPU_CPU_ID_SIZE 1
#define ALT_CPU_CPU_ID_VALUE 0x0
#define ALT_CPU_CPU_IMPLEMENTATION "small"
#define ALT_CPU_DATA_ADDR_WIDTH 0x1a
#define ALT_CPU_DCACHE_LINE_SIZE 0
#define ALT_CPU_DCACHE_LINE_SIZE_LOG2 0
#define ALT_CPU_DCACHE_SIZE 0
#define ALT_CPU_EXCEPTION_ADDR 0x2000020
#define ALT_CPU_FLUSHDA_SUPPORTED
#define ALT_CPU_FREQ 50000000
#define ALT_CPU_HARDWARE_DIVIDE_PRESENT 0
#define ALT_CPU_HARDWARE_MULTIPLY_PRESENT 1
#define ALT_CPU_HARDWARE_MULX_PRESENT 0
#define ALT_CPU_HAS_DEBUG_CORE 1
#define ALT_CPU_HAS_DEBUG_STUB
#define ALT_CPU_HAS_JMPI_INSTRUCTION
#define ALT_CPU_ICACHE_LINE_SIZE 32
#define ALT_CPU_ICACHE_LINE_SIZE_LOG2 5
#define ALT_CPU_ICACHE_SIZE 4096
#define ALT_CPU_INST_ADDR_WIDTH 0x1a
#define ALT_CPU_NAME "cpu"
#define ALT_CPU_RESET_ADDR 0x2000000


/*
 * CPU configuration (with legacy prefix - don't use these anymore)
 *
 */

#define NIOS2_BIG_ENDIAN 0
#define NIOS2_BREAK_ADDR 0x820
#define NIOS2_CPU_FREQ 50000000u
#define NIOS2_CPU_ID_SIZE 1
#define NIOS2_CPU_ID_VALUE 0x0
#define NIOS2_CPU_IMPLEMENTATION "small"
#define NIOS2_DATA_ADDR_WIDTH 0x1a
#define NIOS2_DCACHE_LINE_SIZE 0
#define NIOS2_DCACHE_LINE_SIZE_LOG2 0
#define NIOS2_DCACHE_SIZE 0
#define NIOS2_EXCEPTION_ADDR 0x2000020
#define NIOS2_FLUSHDA_SUPPORTED
#define NIOS2_HARDWARE_DIVIDE_PRESENT 0
#define NIOS2_HARDWARE_MULTIPLY_PRESENT 1
#define NIOS2_HARDWARE_MULX_PRESENT 0
#define NIOS2_HAS_DEBUG_CORE 1
#define NIOS2_HAS_DEBUG_STUB
#define NIOS2_HAS_JMPI_INSTRUCTION
#define NIOS2_ICACHE_LINE_SIZE 32
#define NIOS2_ICACHE_LINE_SIZE_LOG2 5
#define NIOS2_ICACHE_SIZE 4096
#define NIOS2_INST_ADDR_WIDTH 0x1a
#define NIOS2_RESET_ADDR 0x2000000


/*
 * Define for each module class mastered by the CPU
 *
 */

#define __ALTERA_AVALON_JTAG_UART
#define __ALTERA_AVALON_LCD_16207
#define __ALTERA_AVALON_NEW_SDRAM_CONTROLLER
#define __ALTERA_AVALON_PIO
#define __ALTERA_AVALON_TIMER
#define __ALTERA_NIOS2


/*
 * System configuration
 *
 */

#define ALT_DEVICE_FAMILY "CYCLONEII"
#define ALT_ENHANCED_INTERRUPT_API_PRESENT
#define ALT_IRQ_BASE NULL
#define ALT_LOG_PORT "/dev/null"
#define ALT_LOG_PORT_BASE 0x0
#define ALT_LOG_PORT_DEV null
#define ALT_LOG_PORT_TYPE ""
#define ALT_NUM_EXTERNAL_INTERRUPT_CONTROLLERS 0
#define ALT_NUM_INTERNAL_INTERRUPT_CONTROLLERS 1
#define ALT_NUM_INTERRUPT_CONTROLLERS 1
#define ALT_STDERR "/dev/jtag_uart"
#define ALT_STDERR_BASE 0x30
#define ALT_STDERR_DEV jtag_uart
#define ALT_STDERR_IS_JTAG_UART
#define ALT_STDERR_PRESENT
#define ALT_STDERR_TYPE "altera_avalon_jtag_uart"
#define ALT_STDIN "/dev/jtag_uart"
#define ALT_STDIN_BASE 0x30
#define ALT_STDIN_DEV jtag_uart
#define ALT_STDIN_IS_JTAG_UART
#define ALT_STDIN_PRESENT
#define ALT_STDIN_TYPE "altera_avalon_jtag_uart"
#define ALT_STDOUT "/dev/jtag_uart"
#define ALT_STDOUT_BASE 0x30
#define ALT_STDOUT_DEV jtag_uart
#define ALT_STDOUT_IS_JTAG_UART
#define ALT_STDOUT_PRESENT
#define ALT_STDOUT_TYPE "altera_avalon_jtag_uart"
#define ALT_SYSTEM_NAME "NIOS"


/*
 * TIMER_0 configuration
 *
 */

#define ALT_MODULE_CLASS_TIMER_0 altera_avalon_timer
#define TIMER_0_ALWAYS_RUN 0
#define TIMER_0_BASE 0x40
#define TIMER_0_COUNTER_SIZE 32
#define TIMER_0_FIXED_PERIOD 0
#define TIMER_0_FREQ 50000000u
#define TIMER_0_IRQ 0
#define TIMER_0_IRQ_INTERRUPT_CONTROLLER_ID 0
#define TIMER_0_LOAD_VALUE 49999ull
#define TIMER_0_MULT 0.0010
#define TIMER_0_NAME "/dev/TIMER_0"
#define TIMER_0_PERIOD 1
#define TIMER_0_PERIOD_UNITS "ms"
#define TIMER_0_RESET_OUTPUT 0
#define TIMER_0_SNAPSHOT 1
#define TIMER_0_SPAN 32
#define TIMER_0_TICKS_PER_SEC 1000u
#define TIMER_0_TIMEOUT_PULSE_OUTPUT 0
#define TIMER_0_TYPE "altera_avalon_timer"


/*
 * cur_x configuration
 *
 */

#define ALT_MODULE_CLASS_cur_x altera_avalon_pio
#define CUR_X_BASE 0xa0
#define CUR_X_BIT_CLEARING_EDGE_REGISTER 0
#define CUR_X_BIT_MODIFYING_OUTPUT_REGISTER 0
#define CUR_X_CAPTURE 0
#define CUR_X_DATA_WIDTH 10
#define CUR_X_DO_TEST_BENCH_WIRING 0
#define CUR_X_DRIVEN_SIM_VALUE 0x0
#define CUR_X_EDGE_TYPE "NONE"
#define CUR_X_FREQ 50000000u
#define CUR_X_HAS_IN 0
#define CUR_X_HAS_OUT 1
#define CUR_X_HAS_TRI 0
#define CUR_X_IRQ -1
#define CUR_X_IRQ_INTERRUPT_CONTROLLER_ID -1
#define CUR_X_IRQ_TYPE "NONE"
#define CUR_X_NAME "/dev/cur_x"
#define CUR_X_RESET_VALUE 0x0
#define CUR_X_SPAN 16
#define CUR_X_TYPE "altera_avalon_pio"


/*
 * cur_y configuration
 *
 */

#define ALT_MODULE_CLASS_cur_y altera_avalon_pio
#define CUR_Y_BASE 0xb0
#define CUR_Y_BIT_CLEARING_EDGE_REGISTER 0
#define CUR_Y_BIT_MODIFYING_OUTPUT_REGISTER 0
#define CUR_Y_CAPTURE 0
#define CUR_Y_DATA_WIDTH 10
#define CUR_Y_DO_TEST_BENCH_WIRING 0
#define CUR_Y_DRIVEN_SIM_VALUE 0x0
#define CUR_Y_EDGE_TYPE "NONE"
#define CUR_Y_FREQ 50000000u
#define CUR_Y_HAS_IN 0
#define CUR_Y_HAS_OUT 1
#define CUR_Y_HAS_TRI 0
#define CUR_Y_IRQ -1
#define CUR_Y_IRQ_INTERRUPT_CONTROLLER_ID -1
#define CUR_Y_IRQ_TYPE "NONE"
#define CUR_Y_NAME "/dev/cur_y"
#define CUR_Y_RESET_VALUE 0x0
#define CUR_Y_SPAN 16
#define CUR_Y_TYPE "altera_avalon_pio"


/*
 * en0 configuration
 *
 */

#define ALT_MODULE_CLASS_en0 altera_avalon_pio
#define EN0_BASE 0xe0
#define EN0_BIT_CLEARING_EDGE_REGISTER 0
#define EN0_BIT_MODIFYING_OUTPUT_REGISTER 0
#define EN0_CAPTURE 0
#define EN0_DATA_WIDTH 1
#define EN0_DO_TEST_BENCH_WIRING 0
#define EN0_DRIVEN_SIM_VALUE 0x0
#define EN0_EDGE_TYPE "NONE"
#define EN0_FREQ 50000000u
#define EN0_HAS_IN 0
#define EN0_HAS_OUT 1
#define EN0_HAS_TRI 0
#define EN0_IRQ -1
#define EN0_IRQ_INTERRUPT_CONTROLLER_ID -1
#define EN0_IRQ_TYPE "NONE"
#define EN0_NAME "/dev/en0"
#define EN0_RESET_VALUE 0x0
#define EN0_SPAN 16
#define EN0_TYPE "altera_avalon_pio"


/*
 * en1 configuration
 *
 */

#define ALT_MODULE_CLASS_en1 altera_avalon_pio
#define EN1_BASE 0xf0
#define EN1_BIT_CLEARING_EDGE_REGISTER 0
#define EN1_BIT_MODIFYING_OUTPUT_REGISTER 0
#define EN1_CAPTURE 0
#define EN1_DATA_WIDTH 1
#define EN1_DO_TEST_BENCH_WIRING 0
#define EN1_DRIVEN_SIM_VALUE 0x0
#define EN1_EDGE_TYPE "NONE"
#define EN1_FREQ 50000000u
#define EN1_HAS_IN 0
#define EN1_HAS_OUT 1
#define EN1_HAS_TRI 0
#define EN1_IRQ -1
#define EN1_IRQ_INTERRUPT_CONTROLLER_ID -1
#define EN1_IRQ_TYPE "NONE"
#define EN1_NAME "/dev/en1"
#define EN1_RESET_VALUE 0x0
#define EN1_SPAN 16
#define EN1_TYPE "altera_avalon_pio"


/*
 * en2 configuration
 *
 */

#define ALT_MODULE_CLASS_en2 altera_avalon_pio
#define EN2_BASE 0x100
#define EN2_BIT_CLEARING_EDGE_REGISTER 0
#define EN2_BIT_MODIFYING_OUTPUT_REGISTER 0
#define EN2_CAPTURE 0
#define EN2_DATA_WIDTH 1
#define EN2_DO_TEST_BENCH_WIRING 0
#define EN2_DRIVEN_SIM_VALUE 0x0
#define EN2_EDGE_TYPE "NONE"
#define EN2_FREQ 50000000u
#define EN2_HAS_IN 0
#define EN2_HAS_OUT 1
#define EN2_HAS_TRI 0
#define EN2_IRQ -1
#define EN2_IRQ_INTERRUPT_CONTROLLER_ID -1
#define EN2_IRQ_TYPE "NONE"
#define EN2_NAME "/dev/en2"
#define EN2_RESET_VALUE 0x0
#define EN2_SPAN 16
#define EN2_TYPE "altera_avalon_pio"


/*
 * event_has_been_read configuration
 *
 */

#define ALT_MODULE_CLASS_event_has_been_read altera_avalon_pio
#define EVENT_HAS_BEEN_READ_BASE 0x10
#define EVENT_HAS_BEEN_READ_BIT_CLEARING_EDGE_REGISTER 0
#define EVENT_HAS_BEEN_READ_BIT_MODIFYING_OUTPUT_REGISTER 0
#define EVENT_HAS_BEEN_READ_CAPTURE 0
#define EVENT_HAS_BEEN_READ_DATA_WIDTH 1
#define EVENT_HAS_BEEN_READ_DO_TEST_BENCH_WIRING 0
#define EVENT_HAS_BEEN_READ_DRIVEN_SIM_VALUE 0x0
#define EVENT_HAS_BEEN_READ_EDGE_TYPE "NONE"
#define EVENT_HAS_BEEN_READ_FREQ 50000000u
#define EVENT_HAS_BEEN_READ_HAS_IN 0
#define EVENT_HAS_BEEN_READ_HAS_OUT 1
#define EVENT_HAS_BEEN_READ_HAS_TRI 0
#define EVENT_HAS_BEEN_READ_IRQ -1
#define EVENT_HAS_BEEN_READ_IRQ_INTERRUPT_CONTROLLER_ID -1
#define EVENT_HAS_BEEN_READ_IRQ_TYPE "NONE"
#define EVENT_HAS_BEEN_READ_NAME "/dev/event_has_been_read"
#define EVENT_HAS_BEEN_READ_RESET_VALUE 0x0
#define EVENT_HAS_BEEN_READ_SPAN 16
#define EVENT_HAS_BEEN_READ_TYPE "altera_avalon_pio"


/*
 * hal configuration
 *
 */

#define ALT_MAX_FD 32
#define ALT_SYS_CLK TIMER_0
#define ALT_TIMESTAMP_CLK none


/*
 * jtag_uart configuration
 *
 */

#define ALT_MODULE_CLASS_jtag_uart altera_avalon_jtag_uart
#define JTAG_UART_BASE 0x30
#define JTAG_UART_IRQ 1
#define JTAG_UART_IRQ_INTERRUPT_CONTROLLER_ID 0
#define JTAG_UART_NAME "/dev/jtag_uart"
#define JTAG_UART_READ_DEPTH 64
#define JTAG_UART_READ_THRESHOLD 8
#define JTAG_UART_SPAN 8
#define JTAG_UART_TYPE "altera_avalon_jtag_uart"
#define JTAG_UART_WRITE_DEPTH 64
#define JTAG_UART_WRITE_THRESHOLD 8


/*
 * lcd_0 configuration
 *
 */

#define ALT_MODULE_CLASS_lcd_0 altera_avalon_lcd_16207
#define LCD_0_BASE 0x60
#define LCD_0_IRQ -1
#define LCD_0_IRQ_INTERRUPT_CONTROLLER_ID -1
#define LCD_0_NAME "/dev/lcd_0"
#define LCD_0_SPAN 16
#define LCD_0_TYPE "altera_avalon_lcd_16207"


/*
 * new_event_ready configuration
 *
 */

#define ALT_MODULE_CLASS_new_event_ready altera_avalon_pio
#define NEW_EVENT_READY_BASE 0x20
#define NEW_EVENT_READY_BIT_CLEARING_EDGE_REGISTER 0
#define NEW_EVENT_READY_BIT_MODIFYING_OUTPUT_REGISTER 0
#define NEW_EVENT_READY_CAPTURE 0
#define NEW_EVENT_READY_DATA_WIDTH 1
#define NEW_EVENT_READY_DO_TEST_BENCH_WIRING 0
#define NEW_EVENT_READY_DRIVEN_SIM_VALUE 0x0
#define NEW_EVENT_READY_EDGE_TYPE "NONE"
#define NEW_EVENT_READY_FREQ 50000000u
#define NEW_EVENT_READY_HAS_IN 1
#define NEW_EVENT_READY_HAS_OUT 0
#define NEW_EVENT_READY_HAS_TRI 0
#define NEW_EVENT_READY_IRQ -1
#define NEW_EVENT_READY_IRQ_INTERRUPT_CONTROLLER_ID -1
#define NEW_EVENT_READY_IRQ_TYPE "NONE"
#define NEW_EVENT_READY_NAME "/dev/new_event_ready"
#define NEW_EVENT_READY_RESET_VALUE 0x0
#define NEW_EVENT_READY_SPAN 16
#define NEW_EVENT_READY_TYPE "altera_avalon_pio"


/*
 * obj configuration
 *
 */

#define ALT_MODULE_CLASS_obj altera_avalon_pio
#define OBJ_BASE 0xd0
#define OBJ_BIT_CLEARING_EDGE_REGISTER 0
#define OBJ_BIT_MODIFYING_OUTPUT_REGISTER 0
#define OBJ_CAPTURE 0
#define OBJ_DATA_WIDTH 4
#define OBJ_DO_TEST_BENCH_WIRING 0
#define OBJ_DRIVEN_SIM_VALUE 0x0
#define OBJ_EDGE_TYPE "NONE"
#define OBJ_FREQ 50000000u
#define OBJ_HAS_IN 0
#define OBJ_HAS_OUT 1
#define OBJ_HAS_TRI 0
#define OBJ_IRQ -1
#define OBJ_IRQ_INTERRUPT_CONTROLLER_ID -1
#define OBJ_IRQ_TYPE "NONE"
#define OBJ_NAME "/dev/obj"
#define OBJ_RESET_VALUE 0x0
#define OBJ_SPAN 16
#define OBJ_TYPE "altera_avalon_pio"


/*
 * period0 configuration
 *
 */

#define ALT_MODULE_CLASS_period0 altera_avalon_pio
#define PERIOD0_BASE 0x110
#define PERIOD0_BIT_CLEARING_EDGE_REGISTER 0
#define PERIOD0_BIT_MODIFYING_OUTPUT_REGISTER 0
#define PERIOD0_CAPTURE 0
#define PERIOD0_DATA_WIDTH 24
#define PERIOD0_DO_TEST_BENCH_WIRING 0
#define PERIOD0_DRIVEN_SIM_VALUE 0x0
#define PERIOD0_EDGE_TYPE "NONE"
#define PERIOD0_FREQ 50000000u
#define PERIOD0_HAS_IN 0
#define PERIOD0_HAS_OUT 1
#define PERIOD0_HAS_TRI 0
#define PERIOD0_IRQ -1
#define PERIOD0_IRQ_INTERRUPT_CONTROLLER_ID -1
#define PERIOD0_IRQ_TYPE "NONE"
#define PERIOD0_NAME "/dev/period0"
#define PERIOD0_RESET_VALUE 0x0
#define PERIOD0_SPAN 16
#define PERIOD0_TYPE "altera_avalon_pio"


/*
 * period1 configuration
 *
 */

#define ALT_MODULE_CLASS_period1 altera_avalon_pio
#define PERIOD1_BASE 0x120
#define PERIOD1_BIT_CLEARING_EDGE_REGISTER 0
#define PERIOD1_BIT_MODIFYING_OUTPUT_REGISTER 0
#define PERIOD1_CAPTURE 0
#define PERIOD1_DATA_WIDTH 24
#define PERIOD1_DO_TEST_BENCH_WIRING 0
#define PERIOD1_DRIVEN_SIM_VALUE 0x0
#define PERIOD1_EDGE_TYPE "NONE"
#define PERIOD1_FREQ 50000000u
#define PERIOD1_HAS_IN 0
#define PERIOD1_HAS_OUT 1
#define PERIOD1_HAS_TRI 0
#define PERIOD1_IRQ -1
#define PERIOD1_IRQ_INTERRUPT_CONTROLLER_ID -1
#define PERIOD1_IRQ_TYPE "NONE"
#define PERIOD1_NAME "/dev/period1"
#define PERIOD1_RESET_VALUE 0x0
#define PERIOD1_SPAN 16
#define PERIOD1_TYPE "altera_avalon_pio"


/*
 * period2 configuration
 *
 */

#define ALT_MODULE_CLASS_period2 altera_avalon_pio
#define PERIOD2_BASE 0x130
#define PERIOD2_BIT_CLEARING_EDGE_REGISTER 0
#define PERIOD2_BIT_MODIFYING_OUTPUT_REGISTER 0
#define PERIOD2_CAPTURE 0
#define PERIOD2_DATA_WIDTH 24
#define PERIOD2_DO_TEST_BENCH_WIRING 0
#define PERIOD2_DRIVEN_SIM_VALUE 0x0
#define PERIOD2_EDGE_TYPE "NONE"
#define PERIOD2_FREQ 50000000u
#define PERIOD2_HAS_IN 0
#define PERIOD2_HAS_OUT 1
#define PERIOD2_HAS_TRI 0
#define PERIOD2_IRQ -1
#define PERIOD2_IRQ_INTERRUPT_CONTROLLER_ID -1
#define PERIOD2_IRQ_TYPE "NONE"
#define PERIOD2_NAME "/dev/period2"
#define PERIOD2_RESET_VALUE 0x0
#define PERIOD2_SPAN 16
#define PERIOD2_TYPE "altera_avalon_pio"


/*
 * period_gol configuration
 *
 */

#define ALT_MODULE_CLASS_period_gol altera_avalon_pio
#define PERIOD_GOL_BASE 0x140
#define PERIOD_GOL_BIT_CLEARING_EDGE_REGISTER 0
#define PERIOD_GOL_BIT_MODIFYING_OUTPUT_REGISTER 0
#define PERIOD_GOL_CAPTURE 0
#define PERIOD_GOL_DATA_WIDTH 24
#define PERIOD_GOL_DO_TEST_BENCH_WIRING 0
#define PERIOD_GOL_DRIVEN_SIM_VALUE 0x0
#define PERIOD_GOL_EDGE_TYPE "NONE"
#define PERIOD_GOL_FREQ 50000000u
#define PERIOD_GOL_HAS_IN 0
#define PERIOD_GOL_HAS_OUT 1
#define PERIOD_GOL_HAS_TRI 0
#define PERIOD_GOL_IRQ -1
#define PERIOD_GOL_IRQ_INTERRUPT_CONTROLLER_ID -1
#define PERIOD_GOL_IRQ_TYPE "NONE"
#define PERIOD_GOL_NAME "/dev/period_gol"
#define PERIOD_GOL_RESET_VALUE 0x0
#define PERIOD_GOL_SPAN 16
#define PERIOD_GOL_TYPE "altera_avalon_pio"


/*
 * play configuration
 *
 */

#define ALT_MODULE_CLASS_play altera_avalon_pio
#define PLAY_BASE 0xc0
#define PLAY_BIT_CLEARING_EDGE_REGISTER 0
#define PLAY_BIT_MODIFYING_OUTPUT_REGISTER 0
#define PLAY_CAPTURE 0
#define PLAY_DATA_WIDTH 1
#define PLAY_DO_TEST_BENCH_WIRING 0
#define PLAY_DRIVEN_SIM_VALUE 0x0
#define PLAY_EDGE_TYPE "NONE"
#define PLAY_FREQ 50000000u
#define PLAY_HAS_IN 0
#define PLAY_HAS_OUT 1
#define PLAY_HAS_TRI 0
#define PLAY_IRQ -1
#define PLAY_IRQ_INTERRUPT_CONTROLLER_ID -1
#define PLAY_IRQ_TYPE "NONE"
#define PLAY_NAME "/dev/play"
#define PLAY_RESET_VALUE 0x0
#define PLAY_SPAN 16
#define PLAY_TYPE "altera_avalon_pio"


/*
 * ps2_event_type configuration
 *
 */

#define ALT_MODULE_CLASS_ps2_event_type altera_avalon_pio
#define PS2_EVENT_TYPE_BASE 0x0
#define PS2_EVENT_TYPE_BIT_CLEARING_EDGE_REGISTER 0
#define PS2_EVENT_TYPE_BIT_MODIFYING_OUTPUT_REGISTER 0
#define PS2_EVENT_TYPE_CAPTURE 0
#define PS2_EVENT_TYPE_DATA_WIDTH 8
#define PS2_EVENT_TYPE_DO_TEST_BENCH_WIRING 0
#define PS2_EVENT_TYPE_DRIVEN_SIM_VALUE 0x0
#define PS2_EVENT_TYPE_EDGE_TYPE "NONE"
#define PS2_EVENT_TYPE_FREQ 50000000u
#define PS2_EVENT_TYPE_HAS_IN 1
#define PS2_EVENT_TYPE_HAS_OUT 0
#define PS2_EVENT_TYPE_HAS_TRI 0
#define PS2_EVENT_TYPE_IRQ -1
#define PS2_EVENT_TYPE_IRQ_INTERRUPT_CONTROLLER_ID -1
#define PS2_EVENT_TYPE_IRQ_TYPE "NONE"
#define PS2_EVENT_TYPE_NAME "/dev/ps2_event_type"
#define PS2_EVENT_TYPE_RESET_VALUE 0x0
#define PS2_EVENT_TYPE_SPAN 16
#define PS2_EVENT_TYPE_TYPE "altera_avalon_pio"


/*
 * sdram configuration
 *
 */

#define ALT_MODULE_CLASS_sdram altera_avalon_new_sdram_controller
#define SDRAM_BASE 0x2000000
#define SDRAM_CAS_LATENCY 3
#define SDRAM_CONTENTS_INFO ""
#define SDRAM_INIT_NOP_DELAY 0.0
#define SDRAM_INIT_REFRESH_COMMANDS 2
#define SDRAM_IRQ -1
#define SDRAM_IRQ_INTERRUPT_CONTROLLER_ID -1
#define SDRAM_IS_INITIALIZED 1
#define SDRAM_NAME "/dev/sdram"
#define SDRAM_POWERUP_DELAY 100.0
#define SDRAM_REFRESH_PERIOD 15.625
#define SDRAM_REGISTER_DATA_IN 1
#define SDRAM_SDRAM_ADDR_WIDTH 0x16
#define SDRAM_SDRAM_BANK_WIDTH 2
#define SDRAM_SDRAM_COL_WIDTH 8
#define SDRAM_SDRAM_DATA_WIDTH 16
#define SDRAM_SDRAM_NUM_BANKS 4
#define SDRAM_SDRAM_NUM_CHIPSELECTS 1
#define SDRAM_SDRAM_ROW_WIDTH 12
#define SDRAM_SHARED_DATA 0
#define SDRAM_SIM_MODEL_BASE 1
#define SDRAM_SPAN 8388608
#define SDRAM_STARVATION_INDICATOR 0
#define SDRAM_TRISTATE_BRIDGE_SLAVE ""
#define SDRAM_TYPE "altera_avalon_new_sdram_controller"
#define SDRAM_T_AC 5.5
#define SDRAM_T_MRD 3
#define SDRAM_T_RCD 20.0
#define SDRAM_T_RFC 70.0
#define SDRAM_T_RP 20.0
#define SDRAM_T_WR 14.0


/*
 * set_sel0 configuration
 *
 */

#define ALT_MODULE_CLASS_set_sel0 altera_avalon_pio
#define SET_SEL0_BASE 0x190
#define SET_SEL0_BIT_CLEARING_EDGE_REGISTER 0
#define SET_SEL0_BIT_MODIFYING_OUTPUT_REGISTER 0
#define SET_SEL0_CAPTURE 0
#define SET_SEL0_DATA_WIDTH 1
#define SET_SEL0_DO_TEST_BENCH_WIRING 0
#define SET_SEL0_DRIVEN_SIM_VALUE 0x0
#define SET_SEL0_EDGE_TYPE "NONE"
#define SET_SEL0_FREQ 50000000u
#define SET_SEL0_HAS_IN 0
#define SET_SEL0_HAS_OUT 1
#define SET_SEL0_HAS_TRI 0
#define SET_SEL0_IRQ -1
#define SET_SEL0_IRQ_INTERRUPT_CONTROLLER_ID -1
#define SET_SEL0_IRQ_TYPE "NONE"
#define SET_SEL0_NAME "/dev/set_sel0"
#define SET_SEL0_RESET_VALUE 0x0
#define SET_SEL0_SPAN 16
#define SET_SEL0_TYPE "altera_avalon_pio"


/*
 * set_sel1 configuration
 *
 */

#define ALT_MODULE_CLASS_set_sel1 altera_avalon_pio
#define SET_SEL1_BASE 0x1a0
#define SET_SEL1_BIT_CLEARING_EDGE_REGISTER 0
#define SET_SEL1_BIT_MODIFYING_OUTPUT_REGISTER 0
#define SET_SEL1_CAPTURE 0
#define SET_SEL1_DATA_WIDTH 1
#define SET_SEL1_DO_TEST_BENCH_WIRING 0
#define SET_SEL1_DRIVEN_SIM_VALUE 0x0
#define SET_SEL1_EDGE_TYPE "NONE"
#define SET_SEL1_FREQ 50000000u
#define SET_SEL1_HAS_IN 0
#define SET_SEL1_HAS_OUT 1
#define SET_SEL1_HAS_TRI 0
#define SET_SEL1_IRQ -1
#define SET_SEL1_IRQ_INTERRUPT_CONTROLLER_ID -1
#define SET_SEL1_IRQ_TYPE "NONE"
#define SET_SEL1_NAME "/dev/set_sel1"
#define SET_SEL1_RESET_VALUE 0x0
#define SET_SEL1_SPAN 16
#define SET_SEL1_TYPE "altera_avalon_pio"


/*
 * set_sel2 configuration
 *
 */

#define ALT_MODULE_CLASS_set_sel2 altera_avalon_pio
#define SET_SEL2_BASE 0x1b0
#define SET_SEL2_BIT_CLEARING_EDGE_REGISTER 0
#define SET_SEL2_BIT_MODIFYING_OUTPUT_REGISTER 0
#define SET_SEL2_CAPTURE 0
#define SET_SEL2_DATA_WIDTH 1
#define SET_SEL2_DO_TEST_BENCH_WIRING 0
#define SET_SEL2_DRIVEN_SIM_VALUE 0x0
#define SET_SEL2_EDGE_TYPE "NONE"
#define SET_SEL2_FREQ 50000000u
#define SET_SEL2_HAS_IN 0
#define SET_SEL2_HAS_OUT 1
#define SET_SEL2_HAS_TRI 0
#define SET_SEL2_IRQ -1
#define SET_SEL2_IRQ_INTERRUPT_CONTROLLER_ID -1
#define SET_SEL2_IRQ_TYPE "NONE"
#define SET_SEL2_NAME "/dev/set_sel2"
#define SET_SEL2_RESET_VALUE 0x0
#define SET_SEL2_SPAN 16
#define SET_SEL2_TYPE "altera_avalon_pio"


/*
 * speed0 configuration
 *
 */

#define ALT_MODULE_CLASS_speed0 altera_avalon_pio
#define SPEED0_BASE 0x150
#define SPEED0_BIT_CLEARING_EDGE_REGISTER 0
#define SPEED0_BIT_MODIFYING_OUTPUT_REGISTER 0
#define SPEED0_CAPTURE 0
#define SPEED0_DATA_WIDTH 2
#define SPEED0_DO_TEST_BENCH_WIRING 0
#define SPEED0_DRIVEN_SIM_VALUE 0x0
#define SPEED0_EDGE_TYPE "NONE"
#define SPEED0_FREQ 50000000u
#define SPEED0_HAS_IN 0
#define SPEED0_HAS_OUT 1
#define SPEED0_HAS_TRI 0
#define SPEED0_IRQ -1
#define SPEED0_IRQ_INTERRUPT_CONTROLLER_ID -1
#define SPEED0_IRQ_TYPE "NONE"
#define SPEED0_NAME "/dev/speed0"
#define SPEED0_RESET_VALUE 0x0
#define SPEED0_SPAN 16
#define SPEED0_TYPE "altera_avalon_pio"


/*
 * speed1 configuration
 *
 */

#define ALT_MODULE_CLASS_speed1 altera_avalon_pio
#define SPEED1_BASE 0x160
#define SPEED1_BIT_CLEARING_EDGE_REGISTER 0
#define SPEED1_BIT_MODIFYING_OUTPUT_REGISTER 0
#define SPEED1_CAPTURE 0
#define SPEED1_DATA_WIDTH 2
#define SPEED1_DO_TEST_BENCH_WIRING 0
#define SPEED1_DRIVEN_SIM_VALUE 0x0
#define SPEED1_EDGE_TYPE "NONE"
#define SPEED1_FREQ 50000000u
#define SPEED1_HAS_IN 0
#define SPEED1_HAS_OUT 1
#define SPEED1_HAS_TRI 0
#define SPEED1_IRQ -1
#define SPEED1_IRQ_INTERRUPT_CONTROLLER_ID -1
#define SPEED1_IRQ_TYPE "NONE"
#define SPEED1_NAME "/dev/speed1"
#define SPEED1_RESET_VALUE 0x0
#define SPEED1_SPAN 16
#define SPEED1_TYPE "altera_avalon_pio"


/*
 * speed2 configuration
 *
 */

#define ALT_MODULE_CLASS_speed2 altera_avalon_pio
#define SPEED2_BASE 0x170
#define SPEED2_BIT_CLEARING_EDGE_REGISTER 0
#define SPEED2_BIT_MODIFYING_OUTPUT_REGISTER 0
#define SPEED2_CAPTURE 0
#define SPEED2_DATA_WIDTH 2
#define SPEED2_DO_TEST_BENCH_WIRING 0
#define SPEED2_DRIVEN_SIM_VALUE 0x0
#define SPEED2_EDGE_TYPE "NONE"
#define SPEED2_FREQ 50000000u
#define SPEED2_HAS_IN 0
#define SPEED2_HAS_OUT 1
#define SPEED2_HAS_TRI 0
#define SPEED2_IRQ -1
#define SPEED2_IRQ_INTERRUPT_CONTROLLER_ID -1
#define SPEED2_IRQ_TYPE "NONE"
#define SPEED2_NAME "/dev/speed2"
#define SPEED2_RESET_VALUE 0x0
#define SPEED2_SPAN 16
#define SPEED2_TYPE "altera_avalon_pio"


/*
 * sram_addr configuration
 *
 */

#define ALT_MODULE_CLASS_sram_addr altera_avalon_pio
#define SRAM_ADDR_BASE 0x80
#define SRAM_ADDR_BIT_CLEARING_EDGE_REGISTER 0
#define SRAM_ADDR_BIT_MODIFYING_OUTPUT_REGISTER 0
#define SRAM_ADDR_CAPTURE 0
#define SRAM_ADDR_DATA_WIDTH 18
#define SRAM_ADDR_DO_TEST_BENCH_WIRING 0
#define SRAM_ADDR_DRIVEN_SIM_VALUE 0x0
#define SRAM_ADDR_EDGE_TYPE "NONE"
#define SRAM_ADDR_FREQ 50000000u
#define SRAM_ADDR_HAS_IN 0
#define SRAM_ADDR_HAS_OUT 1
#define SRAM_ADDR_HAS_TRI 0
#define SRAM_ADDR_IRQ -1
#define SRAM_ADDR_IRQ_INTERRUPT_CONTROLLER_ID -1
#define SRAM_ADDR_IRQ_TYPE "NONE"
#define SRAM_ADDR_NAME "/dev/sram_addr"
#define SRAM_ADDR_RESET_VALUE 0x0
#define SRAM_ADDR_SPAN 16
#define SRAM_ADDR_TYPE "altera_avalon_pio"


/*
 * sram_dq configuration
 *
 */

#define ALT_MODULE_CLASS_sram_dq altera_avalon_pio
#define SRAM_DQ_BASE 0x90
#define SRAM_DQ_BIT_CLEARING_EDGE_REGISTER 0
#define SRAM_DQ_BIT_MODIFYING_OUTPUT_REGISTER 0
#define SRAM_DQ_CAPTURE 0
#define SRAM_DQ_DATA_WIDTH 16
#define SRAM_DQ_DO_TEST_BENCH_WIRING 0
#define SRAM_DQ_DRIVEN_SIM_VALUE 0x0
#define SRAM_DQ_EDGE_TYPE "NONE"
#define SRAM_DQ_FREQ 50000000u
#define SRAM_DQ_HAS_IN 0
#define SRAM_DQ_HAS_OUT 1
#define SRAM_DQ_HAS_TRI 0
#define SRAM_DQ_IRQ -1
#define SRAM_DQ_IRQ_INTERRUPT_CONTROLLER_ID -1
#define SRAM_DQ_IRQ_TYPE "NONE"
#define SRAM_DQ_NAME "/dev/sram_dq"
#define SRAM_DQ_RESET_VALUE 0x0
#define SRAM_DQ_SPAN 16
#define SRAM_DQ_TYPE "altera_avalon_pio"


/*
 * sram_we_n configuration
 *
 */

#define ALT_MODULE_CLASS_sram_we_n altera_avalon_pio
#define SRAM_WE_N_BASE 0x70
#define SRAM_WE_N_BIT_CLEARING_EDGE_REGISTER 0
#define SRAM_WE_N_BIT_MODIFYING_OUTPUT_REGISTER 0
#define SRAM_WE_N_CAPTURE 0
#define SRAM_WE_N_DATA_WIDTH 1
#define SRAM_WE_N_DO_TEST_BENCH_WIRING 0
#define SRAM_WE_N_DRIVEN_SIM_VALUE 0x0
#define SRAM_WE_N_EDGE_TYPE "NONE"
#define SRAM_WE_N_FREQ 50000000u
#define SRAM_WE_N_HAS_IN 0
#define SRAM_WE_N_HAS_OUT 1
#define SRAM_WE_N_HAS_TRI 0
#define SRAM_WE_N_IRQ -1
#define SRAM_WE_N_IRQ_INTERRUPT_CONTROLLER_ID -1
#define SRAM_WE_N_IRQ_TYPE "NONE"
#define SRAM_WE_N_NAME "/dev/sram_we_n"
#define SRAM_WE_N_RESET_VALUE 0x0
#define SRAM_WE_N_SPAN 16
#define SRAM_WE_N_TYPE "altera_avalon_pio"


/*
 * tone_mode configuration
 *
 */

#define ALT_MODULE_CLASS_tone_mode altera_avalon_pio
#define TONE_MODE_BASE 0x180
#define TONE_MODE_BIT_CLEARING_EDGE_REGISTER 0
#define TONE_MODE_BIT_MODIFYING_OUTPUT_REGISTER 0
#define TONE_MODE_CAPTURE 0
#define TONE_MODE_DATA_WIDTH 3
#define TONE_MODE_DO_TEST_BENCH_WIRING 0
#define TONE_MODE_DRIVEN_SIM_VALUE 0x0
#define TONE_MODE_EDGE_TYPE "NONE"
#define TONE_MODE_FREQ 50000000u
#define TONE_MODE_HAS_IN 0
#define TONE_MODE_HAS_OUT 1
#define TONE_MODE_HAS_TRI 0
#define TONE_MODE_IRQ -1
#define TONE_MODE_IRQ_INTERRUPT_CONTROLLER_ID -1
#define TONE_MODE_IRQ_TYPE "NONE"
#define TONE_MODE_NAME "/dev/tone_mode"
#define TONE_MODE_RESET_VALUE 0x0
#define TONE_MODE_SPAN 16
#define TONE_MODE_TYPE "altera_avalon_pio"

#endif /* __SYSTEM_H_ */
