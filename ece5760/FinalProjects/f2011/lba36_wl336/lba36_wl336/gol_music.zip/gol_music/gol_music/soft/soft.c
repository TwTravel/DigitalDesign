// --------------------------------------------------------------------
// Cornell University - ECE 5760
// Luke Ackerman (lba36) & Weiqing Li (wl336)
// Final Project
// --------------------------------------------------------------------

// system.h has peripheral base addresses, IRQ definitions, and cpu details
#include "system.h"
// Next include has definition of alt_irq_register
#include "sys/alt_irq.h"
//The next two includes are in syslib/DeviceDrivers[sopc_builder]
//They have the macros for setting values in peripherals
#include "altera_avalon_timer_regs.h"
#include "altera_avalon_pio_regs.h"
#include <stdio.h> 

//Cursor Control
#define cur_x_max 628
#define cur_y_max 470
#define cur_x_min 8
#define cur_y_min 12
#define cur_inc 4
#define period_gol_def 4194303
#define period_sb 1048575

///// LCD control: //////////////////////////////////////////////////////
#define ESC_TOP_LEFT    "[1;0H"
#define ESC_BOTTOM_LEFT "[2;0H"
#define LCD_CLR "[2J"
#define LCD_CLR_LINE "[K"
static unsigned char esc = 0x1b; // Integer ASCII value of the ESC character
FILE * lcd_fd; //File descriptor for the LCD
/*
//timer ISR which is called by the HAL exception dispatcher
static void timer_isr(void* context, alt_u32 id)
{
	//recast ISR context variable to pointer to int
	volatile char* count_ptr = (volatile char*) context;
	IOWR_ALTERA_AVALON_TIMER_STATUS(TIMER_0_BASE, 0); //reset TO flag
	*count_ptr = *count_ptr + 1 ; //counter
}
*/

int main(void)
{
	int ps2_event;
	int cur_x = 200;
	int cur_y = 201;
	int play = 1;
	int obj = 0;
	int en0=0, en1=0, en2=0;
	int period0=period_sb, period1=period_sb, period2=period_sb;
	int speed0=2,speed1=2,speed2=2;
	int period_gol=4194303;
	int tone_mode=0, set_sel0=0, set_sel1=0, set_sel2=0;
	volatile unsigned char count; //counter, tracks calculation time
	count = 0; //zero counter

	//open the lcd --- device name from system.h
	lcd_fd = fopen("/dev/lcd_0", "w");
	if(lcd_fd == NULL) printf("Unable to open lcd display\n");

	printf("Started\n"); //output to terminal
	
	//update LCD with corners of set
	fprintf(lcd_fd, "%c%sI'm Alive!\n", esc, ESC_TOP_LEFT);

	
	//set up timer
	//1/10 second period (90Mhz) = 0x895440counts
	IOWR_ALTERA_AVALON_TIMER_PERIODL(TIMER_0_BASE, 0x5440);
	IOWR_ALTERA_AVALON_TIMER_PERIODH(TIMER_0_BASE, 0x89);

	//set RUN, set CONTuous, set ITO
	//IOWR_ALTERA_AVALON_TIMER_CONTROL(TIMER_0_BASE, 7);
	//register the interrupt (and turn it on)
	//alt_irq_register(TIMER_0_IRQ, (void*)&count, timer_isr);
	
	
	IOWR_ALTERA_AVALON_PIO_DATA(EVENT_HAS_BEEN_READ_BASE,0);
	IOWR_ALTERA_AVALON_PIO_DATA(CUR_X_BASE,cur_x);
	IOWR_ALTERA_AVALON_PIO_DATA(CUR_Y_BASE,cur_y);
	IOWR_ALTERA_AVALON_PIO_DATA(PLAY_BASE,play);
	IOWR_ALTERA_AVALON_PIO_DATA(OBJ_BASE,obj);
	IOWR_ALTERA_AVALON_PIO_DATA(EN0_BASE,en0);
	IOWR_ALTERA_AVALON_PIO_DATA(EN1_BASE,en1);
	IOWR_ALTERA_AVALON_PIO_DATA(EN2_BASE,en2);
	IOWR_ALTERA_AVALON_PIO_DATA(PERIOD0_BASE,period0);
	IOWR_ALTERA_AVALON_PIO_DATA(PERIOD1_BASE,period1);
	IOWR_ALTERA_AVALON_PIO_DATA(PERIOD2_BASE,period2);
	IOWR_ALTERA_AVALON_PIO_DATA(PERIOD_GOL_BASE,period_gol);
	IOWR_ALTERA_AVALON_PIO_DATA(SPEED0_BASE,speed0);
	IOWR_ALTERA_AVALON_PIO_DATA(SPEED1_BASE,speed1);
	IOWR_ALTERA_AVALON_PIO_DATA(SPEED2_BASE,speed2);
	IOWR_ALTERA_AVALON_PIO_DATA(TONE_MODE_BASE,tone_mode);
	IOWR_ALTERA_AVALON_PIO_DATA(SET_SEL0_BASE,set_sel0);
	IOWR_ALTERA_AVALON_PIO_DATA(SET_SEL1_BASE,set_sel1);
	IOWR_ALTERA_AVALON_PIO_DATA(SET_SEL2_BASE,set_sel2);
	while(1)
	{
		
		if (IORD_ALTERA_AVALON_PIO_DATA(NEW_EVENT_READY_BASE)){
			ps2_event = IORD_ALTERA_AVALON_PIO_DATA(PS2_EVENT_TYPE_BASE);

			switch (ps2_event) {
				case 211:
					//printf("up-arrow\n");
					if (cur_y > cur_y_min) cur_y=cur_y-cur_inc;
					IOWR_ALTERA_AVALON_PIO_DATA(CUR_Y_BASE,cur_y);				
					break;
				case 160: //w
					//printf("up-arrow\n");
					if (cur_y > (cur_y_min+cur_inc*4)) cur_y=cur_y-cur_inc*4;
					IOWR_ALTERA_AVALON_PIO_DATA(CUR_Y_BASE,cur_y);				
					break; 
				case 212:
					//printf("left-arrow\n");
					if (cur_x > cur_x_min) cur_x=cur_x-cur_inc;
					IOWR_ALTERA_AVALON_PIO_DATA(CUR_X_BASE,cur_x);
					break;
				case 173: //a
					//printf("left-arrow\n");
					if (cur_x > (cur_x_min+cur_inc*4)) cur_x=cur_x-cur_inc*4;
					IOWR_ALTERA_AVALON_PIO_DATA(CUR_X_BASE,cur_x);
					break;
				case 213:
					//printf("down-arrow\n");
					if (cur_y < cur_y_max) cur_y=cur_y+cur_inc;
					IOWR_ALTERA_AVALON_PIO_DATA(CUR_Y_BASE,cur_y);
					break;
				case 186: //z
					//printf("down-arrow\n");
					if (cur_y < (cur_y_max-cur_inc*4)) cur_y=cur_y+cur_inc*4;
					IOWR_ALTERA_AVALON_PIO_DATA(CUR_Y_BASE,cur_y);
					break;
				case 214:
					//printf("right-arrow\n");
					if (cur_x < cur_x_max) cur_x=cur_x+cur_inc;
					IOWR_ALTERA_AVALON_PIO_DATA(CUR_X_BASE,cur_x);
					break;
				case 174: //s
					//printf("right-arrow\n");
					if (cur_x < (cur_x_max-cur_inc*4)) cur_x=cur_x+cur_inc*4;
					IOWR_ALTERA_AVALON_PIO_DATA(CUR_X_BASE,cur_x);
					break;
				case 184:
					//printf("enter\n");
					break;
				case 200:
					if (play) play=0;
					else play=1;
					IOWR_ALTERA_AVALON_PIO_DATA(PLAY_BASE,play);
					//printf("space\n");
					break;
				case 177: //glider
					if (!play) {
						//printf("g\n");
						obj=2;
						IOWR_ALTERA_AVALON_PIO_DATA(OBJ_BASE,obj);
					}
					break;
				case 175: //dot
					if (!play) {
						//printf("d\n");
						obj=1;
						IOWR_ALTERA_AVALON_PIO_DATA(OBJ_BASE,obj);
					}
					break;
				case 167: //small oscillator
					if (!play) {
						//printf("o\n");
						obj=3;
						IOWR_ALTERA_AVALON_PIO_DATA(OBJ_BASE,obj);
					}
					break;
				case 157: //clear all
					if (!play) {
						//printf("backspace\n");
						obj=6;
						IOWR_ALTERA_AVALON_PIO_DATA(OBJ_BASE,obj);
					}
					break;
				case 162: //random 
					if (!play) {
						//printf("r\n");
						obj=7;
						IOWR_ALTERA_AVALON_PIO_DATA(OBJ_BASE,obj);
					}
					break;
				case 161: //exploder
					if (!play) {
						//printf("e\n");
						obj=5;
						IOWR_ALTERA_AVALON_PIO_DATA(OBJ_BASE,obj);
					}
					break;
				case 181: //large oscillator
					if (!play) {
						//printf("l\n");
						obj=4;
						IOWR_ALTERA_AVALON_PIO_DATA(OBJ_BASE,obj);
					}
					break;
				case 168: //gun
					if (!play) {
						//printf("p\n");
						obj=8;
						IOWR_ALTERA_AVALON_PIO_DATA(OBJ_BASE,obj);
					}
					break;
				case 130: //scan bar 0
					//printf("F1\n");
					if (en0==0) {en0=1; period0=period_sb; speed0=2;}
					else if (period0>=period_sb*4) en0=0;
					else {period0*=2; speed0-=1;}
					IOWR_ALTERA_AVALON_PIO_DATA(PERIOD0_BASE,period0);
					IOWR_ALTERA_AVALON_PIO_DATA(EN0_BASE,en0);
					IOWR_ALTERA_AVALON_PIO_DATA(SPEED0_BASE,speed0);
					break;
				case 131: //scan bar 1
					//printf("F2\n");
					if (en1==0) {en1=1; period1=period_sb; speed1=2;}
					else if (period1>=period_sb*4) en1=0;
					else {period1*=2; speed1-=1;}
					IOWR_ALTERA_AVALON_PIO_DATA(PERIOD1_BASE,period1);
					IOWR_ALTERA_AVALON_PIO_DATA(EN1_BASE,en1);
					IOWR_ALTERA_AVALON_PIO_DATA(SPEED1_BASE,speed1);
					break;
				case 132: //scan bar 2
					//printf("F3\n");
					if (en2==0) {en2=1; period2=period_sb; speed2=2;}
					else if (period2>=period_sb*4) en2=0;
					else {period2*=2; speed2-=1;}
					IOWR_ALTERA_AVALON_PIO_DATA(PERIOD2_BASE,period2);
					IOWR_ALTERA_AVALON_PIO_DATA(EN2_BASE,en2);
					IOWR_ALTERA_AVALON_PIO_DATA(SPEED2_BASE,speed2);
					break;
				case 207: //increase evolution speed
					if (play) {
						//printf("PG_UP\n");
						period_gol/=2;
						IOWR_ALTERA_AVALON_PIO_DATA(PERIOD_GOL_BASE,period_gol);
					}
					break;
				case 210: //decrease evolution speed
					if (play) {
						//printf("PG_DN\n");
						period_gol*=2;
						IOWR_ALTERA_AVALON_PIO_DATA(PERIOD_GOL_BASE,period_gol);
					}
					break;
				case 229: //tone mapping 0
					//printf("0 (numpad)\n");
					tone_mode = 0;
					IOWR_ALTERA_AVALON_PIO_DATA(TONE_MODE_BASE,tone_mode);
					break;
				case 226: //tone mapping 1
					//printf("1 (numpad)\n");
					tone_mode = 1;
					IOWR_ALTERA_AVALON_PIO_DATA(TONE_MODE_BASE,tone_mode);
					break;
				case 227: //tone mapping 2
					//printf("2 (numpad)\n");
					tone_mode = 2;
					IOWR_ALTERA_AVALON_PIO_DATA(TONE_MODE_BASE,tone_mode);
					break;
				case 228: //tone mapping 3
					//printf("3 (numpad)\n");
					tone_mode = 3;
					IOWR_ALTERA_AVALON_PIO_DATA(TONE_MODE_BASE,tone_mode);
					break;
				case 223: //tone mapping 4
					//printf("4 (numpad)\n");
					tone_mode = 4;
					IOWR_ALTERA_AVALON_PIO_DATA(TONE_MODE_BASE,tone_mode);
					break;
				case 145: //toggle octave for bar0
					set_sel0 = set_sel0 ^ 1;
					IOWR_ALTERA_AVALON_PIO_DATA(SET_SEL0_BASE,set_sel0);
					break;
				case 146: //toggle octave for bar1
					set_sel1 = set_sel1 ^ 1;
					IOWR_ALTERA_AVALON_PIO_DATA(SET_SEL1_BASE,set_sel1);
					break;
				case 147: //toggle octave for bar2
					set_sel2 = set_sel2 ^ 1;
					IOWR_ALTERA_AVALON_PIO_DATA(SET_SEL2_BASE,set_sel2);
					break;
				case 144: //ece5760
					if (!play){
						//printf("`\n");
						obj=9;
						IOWR_ALTERA_AVALON_PIO_DATA(OBJ_BASE,obj);
					}
				case 188: //chaos (key c)
					if (!play){
						obj=10;
						IOWR_ALTERA_AVALON_PIO_DATA(OBJ_BASE,obj);
					}
					break;
				case 187: //chaos (key x)
					if (!play){
						obj=11;
						IOWR_ALTERA_AVALON_PIO_DATA(OBJ_BASE,obj);
					}
					break;
				case 206: //home - reset all parameters
					//printf("home\n");
					period_gol=period_gol_def; IOWR_ALTERA_AVALON_PIO_DATA(PERIOD_GOL_BASE,period_gol);
					en0=0; IOWR_ALTERA_AVALON_PIO_DATA(EN0_BASE,en0);
					en1=0; IOWR_ALTERA_AVALON_PIO_DATA(EN1_BASE,en1);
					en2=0; IOWR_ALTERA_AVALON_PIO_DATA(EN2_BASE,en2);
					tone_mode = 0; IOWR_ALTERA_AVALON_PIO_DATA(TONE_MODE_BASE,tone_mode);
					break;
			}
			obj=0;
			IOWR_ALTERA_AVALON_PIO_DATA(OBJ_BASE,obj);
			IOWR_ALTERA_AVALON_PIO_DATA(EVENT_HAS_BEEN_READ_BASE,1);
			IOWR_ALTERA_AVALON_PIO_DATA(EVENT_HAS_BEEN_READ_BASE,0);
			
		} 
		
		//printf("in while(1)\n");
	}

}
