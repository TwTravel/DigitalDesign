% open the file with write permission
fid = fopen('test2.v', 'w');
fprintf(fid,'case ({vga_x[9:2],vga_y[8:2]})\n');
count=0;
for i=1:116
    for j=1:153
        if (m(i,j)) 
            count=count+1;
            %fprintf(fid, '    {(cur_x[9:2]+(8''d%i)),(cur_y[8:2]+(7''d%i))}: begin mem_outR <= 1''b1; mem_weR <= 1''b1; pixels_drawn <= pixels_drawn+20''d1; end\n',j,i);
            fprintf(fid, '    {(8''d%i),(7''d%i)}: begin mem_outR <= 1''b1; mem_weR <= 1''b1; pixels_drawn <= pixels_drawn+20''d1; end\n',j,i);
        end
    end
end
fprintf(fid,'    default: mem_weR <= 1''b0;\n');
fprintf(fid,'endcase\n');