using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;
using System.IO;

namespace HRTFGui
{
    public partial class Form1 : Form
    {
        static SerialPort s;
        byte currAz, currEl;

        String[] azToString = new String[] { "-80", "-65", "-55", "-45", "-40", "-35", "-30", "-25", "-20",
                                             "-15", "-10", "-5", "0", "5", "10", "15", "20", "25", "30",
                                             "35", "40", "45", "55", "65", "80" };

        String[] elToString = new String[] { "-45", "-33.75", "-22.5", "-11.25", "0", "11.25", "22.5",
                                             "33.75", "45", "56.25", "67.5", "78.75", "90", "101.25", "112.5",
                                             "123.75", "135", "146.25", "157.5", "168.75", "180", "191.25",
                                             "202.5", "213.75", "225" };

        public Form1()
        {
            // initialize form elements
            InitializeComponent();

            // initialize serial port
            s = new SerialPort("COM4", 115200, Parity.None, 8, StopBits.One);
            s.DataReceived += new SerialDataReceivedEventHandler(received);
            s.Open();

            // by default set to invalid azimuth/elevation
            currAz = 30;
            currEl = 30;

            // by default set 
            cb_stream.SelectedIndex = 0;
        }

        private void received(object sender, SerialDataReceivedEventArgs e)
        {
            MessageBox.Show("Data read from serial port: " + s.ReadExisting());
        }

        private void listBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left) // user is holding left mouse button while dragging cursor
            {
                // convert mouse pointer location to azimuth & elevation
                byte az, el;
                az = (byte) (e.X / 10);
                el = (byte) ((251 - e.Y) / 10);

                if (az > 24 || el > 24) // out of bounds?
                    return;

                if (az != currAz || el != currEl) // should we update the HRTF?
                {
                    currAz = az;
                    currEl = el;

                    // display current azimuth & elevation to user
                    tb_display_az.Text = azToString[currAz];
                    tb_display_el.Text = elToString[currEl];

                    byte[] b = new byte[6];
                    byte currStream = byte.Parse((String)cb_stream.SelectedItem);
                    b[0] = 0;
                    b[1] = 1;                    
                    b[2] = currStream;
                    b[3] = az;
                    b[4] = 0;
                    b[5] = el;
                    s.Write(b, 0, 6);
                    s.BaseStream.Flush();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure?", "", MessageBoxButtons.YesNo) != DialogResult.Yes)
                return;
            int count = 0;

            tb_out.Text += "Loading subject 021\r\n";

            byte[] b = new byte[2];
            b[0] = 0;
            b[1] = 0;
            s.Write(b, 0, 2);

            tb_out.Text += "  Left coefficients\r\n";
            TextReader tr = new StreamReader("021_16bit_l.txt");
            String str;
            while ((str = tr.ReadLine()) != null)
            {
                b[0] = byte.Parse(str.Substring(0, 2), System.Globalization.NumberStyles.HexNumber);
                b[1] = byte.Parse(str.Substring(2, 2), System.Globalization.NumberStyles.HexNumber);
                s.Write(b, 0, 2);
                if (count % 1000 == 0)
                {
                    tb_out.Text = "Coeff " + count.ToString() + "\r\n";
                    s.BaseStream.Flush();
                }
                count++;
            }

            count = 0;
            tb_out.Text += "  Right coefficients\r\n";
            tr = new StreamReader("021_16bit_r.txt");
            while ((str = tr.ReadLine()) != null)
            {
                b[0] = byte.Parse(str.Substring(0, 2), System.Globalization.NumberStyles.HexNumber);
                b[1] = byte.Parse(str.Substring(2, 2), System.Globalization.NumberStyles.HexNumber);
                s.Write(b, 0, 2);
                if (count % 1000 == 0)
                {
                    tb_out.Text = "Coeff " + count.ToString() + "\r\n";
                    s.BaseStream.Flush();
                }
                count++;
            }

            // send final bytes which are not a command
            b[0] = 0;
            b[1] = 2;
            s.Write(b, 0, 2);

            tb_out.Text += "Done!\r\n";
        }
    }
}