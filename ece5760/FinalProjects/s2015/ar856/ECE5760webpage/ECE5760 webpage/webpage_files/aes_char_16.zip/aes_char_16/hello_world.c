// --------------------------------------------------------------------
// Copyright (c) 2010 by Terasic Technologies Inc.
// --------------------------------------------------------------------
//
// Permission:
//
//   Terasic grants permission to use and modify this code for use
//   in synthesis for all Terasic Development Boards and Altera Development
//   Kits made by Terasic.  Other use of this code, including the selling
//   ,duplication, or modification of any portion is strictly prohibited.
//
// Disclaimer:
//
//   This VHDL/Verilog or C/C++ source code is intended as a design reference
//   which illustrates how these types of functions can be implemented.
//   It is the user's responsibility to verify their design for
//   consistency and functionality through the use of formal
//   verification methods.  Terasic provides no warranty regarding the use
//   or functionality of this code.
//
// --------------------------------------------------------------------
//
//                     Terasic Technologies Inc
//                     356 Fu-Shin E. Rd Sec. 1. JhuBei City,
//                     HsinChu County, Taiwan
//                     302
//
//                     web: http://www.terasic.com/
//                     email: support@terasic.com
//
// --------------------------------------------------------------------
// Last built by: Quartus 9.1 SP2 build 350
// Supported File Format: FAT16 & FAT 32
// Supported SDCARD: SD, HCSD

#include <stdio.h>
#include "terasic_includes.h"
#include "FatFileSystem.h"
//#include "FatFileSystem.c"
#include "debug.h"
//#include "debug.c"
#include "FatConfig.h"
#include<altera_avalon_jtag_uart_regs.h>
#include<altera_avalon_pio_regs.h>
#include<altera_avalon_jtag_uart.h>
#include<system.h>



bool Fat_Test(FAT_HANDLE hFat, char *pDumpFile){
    bool bSuccess;
    int nCount = 0;
    FAT_BROWSE_HANDLE hBrowse;
    FILE_CONTEXT FileContext;

    bSuccess = Fat_FileBrowseBegin(hFat, &hBrowse);
    if (bSuccess){
        while(Fat_FileBrowseNext(&hBrowse, &FileContext)){
            if (FileContext.bLongFilename){
                alt_u16 *pData16;
                alt_u8 *pData8;
                pData16 = (alt_u16 *)FileContext.szName;
                pData8 = FileContext.szName;
                printf("[%d]", nCount);
                while(*pData16){
                    if (*pData8)
                        printf("%c", *pData8);
                    pData8++;
                    if (*pData8)
                        printf("%c", *pData8);
                    pData8++;
                    //
                    pData16++;
                }
                printf("\n");
            }else{
                printf("[%d]%s\n", nCount, FileContext.szName);
            }
            nCount++;
        }
    }
    if (bSuccess && pDumpFile && strlen(pDumpFile)){
        FAT_FILE_HANDLE hFile;
        hFile =  Fat_FileOpen(hFat, pDumpFile);
        if (hFile){
            char szRead[16];
            long read_buffer[7000];
            char text_buffer_31_to_0[4];
            char text_buffer_63_to_32[4];
            char text_buffer_95_to_64[4];
            char text_buffer_127_to_96[4];

            long encrypt_data[4] = {0x00000000,0x00000000,0x00000000,0x00000000};

            int nReadSize, nFileSize, count_int = 0, nTotalReadSize=0, j=0, fpga_read_size, fifo_empty = 0;
            nFileSize = Fat_FileSize(hFile);
            IOWR_ALTERA_AVALON_PIO_DATA(FPGA_READ_COUNT_BASE, nFileSize);
            fpga_read_size = (nFileSize % 16);
            IOWR_ALTERA_AVALON_PIO_DATA(NIOS_IN_MOD_16_BASE,fpga_read_size);//send mod count of read size
            if (nReadSize > sizeof(szRead))
                nReadSize = sizeof(szRead);
            while(bSuccess && nTotalReadSize < nFileSize){
                nReadSize = sizeof(szRead);
                if (nReadSize > (nFileSize - nTotalReadSize))
                    nReadSize = (nFileSize - nTotalReadSize);
                if (Fat_FileRead(hFile, szRead, nReadSize))//finished reading from sd card
                {
                	  int i;
                	  for(i=15;i>=0;i--){
                		  encrypt_data[i>>2] = (encrypt_data[i>>2] << 8) | (szRead[i] & 0xff) ;
                	  }


                	  while(IORD_ALTERA_AVALON_PIO_DATA(FPGA_DATA_IRQ_BASE) == 0);

                	  {
                             // printf("Interrupt received\n");
                			  IOWR_ALTERA_AVALON_PIO_DATA(NIOS_OUT_31_TO_0_BASE,encrypt_data[0]);
                			  IOWR_ALTERA_AVALON_PIO_DATA(NIOS_OUT_63_TO_32_BASE,encrypt_data[1]);
                			  IOWR_ALTERA_AVALON_PIO_DATA(NIOS_OUT_95_TO_64_BASE,encrypt_data[2]);
                			  IOWR_ALTERA_AVALON_PIO_DATA(NIOS_OUT_127_TO_96_BASE,encrypt_data[3]);
                			  IOWR_ALTERA_AVALON_PIO_DATA(FPGA_INT_CLEAR_BASE, 0x01);
                			  IOWR_ALTERA_AVALON_PIO_DATA(FPGA_INT_CLEAR_BASE, 0x00);
                		      count_int++;
                	  }

                	 /* for(i=0;i<nReadSize;i++){
                	                 	       printf("%c", szRead[i]);
                	                 	   }*/


                    nTotalReadSize += nReadSize;

                }else{
                    bSuccess = FALSE;
                    printf("\nFaied to read the file \"%s\"\n", pDumpFile);
                }
            } printf("\n Character count = %d \n", nTotalReadSize );
            if (bSuccess)
                printf("\n");
                Fat_FileClose(hFile);


        }else{
            bSuccess = FALSE;
            printf("Cannot find the file \"%s\"\n", pDumpFile);
        }
    }

    return bSuccess;
}


int main()
{
    const alt_u32 LED_TEST_PATTERN = 0xF0;
    const alt_u32 LED_NG_PATTERN = 0xFF;
    const alt_u32 LED_PASS_PATTERN = 0x00;
    FAT_HANDLE hFat;

	char key_buff[16];
	char test_char = 144;
	int count = 0, i,j = 0, fifo_empty = 0, read_buffer_count = 0;
	long keydata[4] = {0x00000000,0x00000000,0x00000000,0x00000000};
	long read_fpga_data[10000];
	IOWR_ALTERA_AVALON_PIO_DATA(FPGA_KEY_SENT_BASE, 0x00);
	printf("Enter Key\n");
	while(count < 16)
	{
		scanf("%c", &key_buff[count]);
		count = count + 1;

	}

	for(i=0;i<16;i++)
	{
		keydata[i>>2] = (keydata[i>>2]<<8)|(key_buff[i]&0xff);
	}
    //Sending Key to FPGA
	IOWR_ALTERA_AVALON_PIO_DATA(NIOS_OUT_KEY_31_TO_0_BASE, keydata[0]);
	IOWR_ALTERA_AVALON_PIO_DATA(NIOS_OUT_KEY_63_TO_32_BASE, keydata[1]);
	IOWR_ALTERA_AVALON_PIO_DATA(NIOS_OUT_KEY_95_TO_64_BASE, keydata[2]);
	IOWR_ALTERA_AVALON_PIO_DATA(NIOS_OUT_KEY_127_TO_96_BASE, keydata[3]);
	IOWR_ALTERA_AVALON_PIO_DATA(FPGA_KEY_SENT_BASE, 0x01);

	printf("Press Key 3 to start encryption\n");
	while ((IORD_ALTERA_AVALON_PIO_DATA(KEY3_IN_BASE) & 0x01) == 0x01);
	//usleep(400*1000);
      //start timer


        printf("Processing...\r\n");
        //IOWR_ALTERA_AVALON_PIO_DATA(LEDR_BASE, LED_TEST_PATTERN);
        hFat = Fat_Mount(FAT_SD_CARD, 0);

        if (hFat){
            printf("sdcard mount success!\n");
            printf("Root Directory Item Count:%d\n", Fat_FileCount(hFat));
            Fat_Test(hFat, "test.txt");

        }else{
            printf("Failed to mount the SDCARD!\r\nPlease insert the SDCARD into DE2-115 board and press KEY3.\r\n");

        }
     ////////////Read from FPGA

        char a[32];
        for(i=0;i<32;i=i+1){
        	a[i] = 0;
        }
     //Wait for interrupt from FPGA to start reading
        while(IORD_ALTERA_AVALON_PIO_DATA(FPGA_DATA_OUT_IRQ_BASE) == 0);

        read_fpga_data[j] = IORD_ALTERA_AVALON_PIO_DATA(NIOS_IN_31_TO_0_BASE);
        read_fpga_data[j+1] = IORD_ALTERA_AVALON_PIO_DATA(NIOS_IN_63_TO_32_BASE);
        read_fpga_data[j+2] = IORD_ALTERA_AVALON_PIO_DATA(NIOS_IN_95_TO_64_BASE);
        read_fpga_data[j+3] = IORD_ALTERA_AVALON_PIO_DATA(NIOS_IN_127_TO_96_BASE);
        read_fpga_data[j+4] = IORD_ALTERA_AVALON_PIO_DATA(NIOS_IN_256_1_BASE);
        read_fpga_data[j+5] = IORD_ALTERA_AVALON_PIO_DATA(NIOS_IN_256_2_BASE);
        read_fpga_data[j+6] = IORD_ALTERA_AVALON_PIO_DATA(NIOS_IN_256_3_BASE);
        read_fpga_data[j+7] = IORD_ALTERA_AVALON_PIO_DATA(NIOS_IN_256_4_BASE);
       IOWR_ALTERA_AVALON_PIO_DATA(FPGA_DATA_OUT_IRQ_CLR_BASE, 0x01);
	   IOWR_ALTERA_AVALON_PIO_DATA(FPGA_DATA_OUT_IRQ_CLR_BASE, 0x00);

		for(i=0;i<8;i=i++){
			a[4*i] = read_fpga_data[i] & (0x000000ff);
			a[4*i+1] = (read_fpga_data[i] & (0x0000ff00))>>8;
			a[4*i+2] = (read_fpga_data[i] & (0x00ff0000))>>16;
			a[4*i+3] = (read_fpga_data[i] & (0xff000000))>>24;
		}

	 /*  for(i=0; i<8; i++){
			printf("FPGA_DATA = %li\n",read_fpga_data[i]);
		}*/
	   printf("encrypted text : \n");
	   for(i=0;i<32;i++){
		   printf("%c",a[i]);
	   }

  return 0;
}
