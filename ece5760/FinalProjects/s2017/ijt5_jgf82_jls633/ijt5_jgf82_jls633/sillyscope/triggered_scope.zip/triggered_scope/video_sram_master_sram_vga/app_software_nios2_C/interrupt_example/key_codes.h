#define KEY0 0
#define KEY1 1
#define KEY2 2
#define KEY3 3
#define NONE 4

#define LEFT 1
#define RIGHT 2
