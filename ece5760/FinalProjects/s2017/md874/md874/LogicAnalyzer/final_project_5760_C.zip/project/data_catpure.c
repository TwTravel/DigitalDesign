//////////////////////////////////////
/// 640x480 version!
/// This code will segfault the original
/// DE1 computer
/// compile with
/// gcc data_capture.c -o data -O2
/// -- no optimization yields ??? execution time
/// -- opt -O1 yields ??? mS execution time
/// -- opt -O2 yields ??? mS execution time
/// -- opt -O3 yields ??? mS execution time
///////////////////////////////////////
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/ipc.h> 
#include <sys/shm.h> 
#include <sys/mman.h>
#include <sys/time.h> 
#include "address_map_arm_brl4.h"
#include <errno.h>
#include <sys/stat.h>
#include <signal.h>

#define SW_MASK 0x3ff

static volatile int keepRunning = 1;

void intHandler(int dummy) {
  keepRunning = 0;
}

/* function prototypes */
void VGA_text (int, int, char *);
void VGA_text_clear();
void VGA_box (int, int, int, int, short);
void VGA_line(int, int, int, int, short) ;
void clear_life(void);
void draw_cursor(int, int, int);
void file_read( unsigned char* , int , unsigned int* );

// the light weight bus base
void *h2p_lw_virtual_base;
volatile unsigned int * sw_ptr = NULL ;
int SW_value;

// pixel buffer
volatile unsigned int * vga_pixel_ptr = NULL ;
void *vga_pixel_virtual_base;

// character buffer
volatile unsigned int * vga_char_ptr = NULL ;
void *vga_char_virtual_base;

// /dev/mem file id
int fd;

// shared memory 
key_t mem_key=0xf0;
int shared_mem_id; 
int *shared_ptr;
int shared_time;
int shared_note;
char shared_str[64];

// pixel macro
#define VGA_PIXEL(x,y,color) do{\
	char  *pixel_ptr ;\
	pixel_ptr = (char *)vga_pixel_ptr + ((y)<<10) + (x) ;\
	*(char *)pixel_ptr = (color);\
} while(0)
	

// game of life array
// bottom bit is current state
// next bit is next state
char life[640][480] ; //char life[640][480] ;
char life_new[640][480] ;
int count, total_count;
int sum ;

// measure time
struct timeval t1, t2;
double elapsedTime;
	
int main(void)
{
	//int x1, y1, x2, y2;
	int flag1,flag2;
  int cursor_x = 320, cursor_y = 240;
  int old_x = 320, old_y = 240;
  int bus[33];
  int wave[9];
  unsigned int *act_value;
  int left_flag = 0, right_flag = 0;
  int digital_flag = 0, analog_flag = 0, trig_flag = 0;
  int sign = 0;
  int trigger = 0, capture = 0, cap_flag = 0;
  int data_capture;
  unsigned int const mask[33] = {0x0,0x1,0x2,0x4,0x8,0x10,0x20,0x40,0x80,0x100,0x200,0x400,0x800,0x1000,0x2000,0x4000,0x8000,0x10000,0x20000,0x40000,0x80000,0x100000,0x200000,0x400000,0x800000,0x1000000,0x2000000,0x4000000,0x8000000,0x10000000,0x20000000,0x40000000,0x80000000};

  unsigned int const mask4[9] = {0x0,0xf,0xf0,0xf00,0xf000,0xf0000,0xf00000,0xf000000,0xf0000000};
  
  int i,j,k,s,x=0;
  int flag[32][256];
  int flag4[8][256];
  short green = 0x1c;
  int resolution; // point per sample
  int depth; // number of samples
  int ret;

  printf("Enter resolution - ");
  ret = scanf("%d",&resolution);

  printf("Enter depth - ");
  ret = scanf("%d",&depth);
  
  printf("Entered resolution - %d\n",resolution);
  printf("Entered depth - %d\n",depth);
  
  if (depth>1024) {
    depth = 1024;
    printf("Entered depth too large fixing it to - %d\n",depth);
  }


  unsigned char *buf;
  buf = (unsigned char *)malloc(depth*4*sizeof(char));

  act_value = (unsigned int *)malloc(depth*sizeof(int));
  
  for( i = 0; i < depth; i = i + 1 ) {
      act_value[i] = 0;
  }
  
  for( i = 0; i < 32; i = i + 1 ) {
      flag[i][0] = 0;
  }
  
  for( i = 0; i < 8; i = i + 1 ) {
      flag4[i][0] = 0;
  }
  
  for( i = 0; i < 29; i = i + 1 ) {
    bus[28-i] = 28 + (i*16);
  }
  
  for( i = 0; i < 9; i = i + 1 ) {
    wave[8-i] = 36 + (i*48);
  }
  
  file_read(buf,depth,act_value);
  
  for( j = 0; j < 28; j++ ) {
    for( k = 0; k < depth/4; k++ ) {
      flag[27-j][k+1] = (act_value[k] & mask[28-j])>>(27-j);
    }
  }
  printf("\nFirst flag");
  for( j = 0; j < 8; j++ ) {
    for( k = 0; k < depth/4; k++ ) {
      flag4[7-j][k+1] = (act_value[k] & mask4[8-j])>>(4*(7-j));
    }
  }
  printf("\nFirst flag4");
  
  // Declare volatile pointers to I/O registers (volatile 	// means that IO load and store instructions will be used 	// to access these pointer locations, 
	// instead of regular memory loads and stores) 

	// === shared memory =======================
	// with video process
	shared_mem_id = shmget(mem_key, 100, IPC_CREAT | 0666);
 	//shared_mem_id = shmget(mem_key, 100, 0666);
	shared_ptr = shmat(shared_mem_id, NULL, 0);

  /* Below code for detecting mouse position and event */
  int fm, bytes;
  unsigned char data[3];
  const char *pDevice = "/dev/input/mice";

  // Open Mouse
  fm = open(pDevice, O_RDWR);
  if(fm == -1)
  {
      printf("ERROR Opening %s\n", pDevice);
      return -1;
  }
  
  //needed for nonblocking mouse read()
  int flags = fcntl(fm, F_GETFL, 0);
  fcntl(fm, F_SETFL, flags | O_NONBLOCK); 	
  
  int left, middle, right;
  signed char posx, posy;	
  
  // === need to mmap: =======================
	// FPGA_CHAR_BASE
	// FPGA_ONCHIP_BASE      
	// HW_REGS_BASE        
  
	// === get FPGA addresses ==================
    // Open /dev/mem
	if( ( fd = open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) 	{
		printf( "ERROR: could not open \"/dev/mem\"...\n" );
		return( 1 );
	}

	// get virtual addr that maps to physical
	h2p_lw_virtual_base = mmap( NULL, HW_REGS_SPAN, ( 	PROT_READ | PROT_WRITE ), MAP_SHARED, fd, HW_REGS_BASE );	
	if( h2p_lw_virtual_base == MAP_FAILED ) {
		printf( "ERROR: mmap1() failed...\n" );
		close( fd );
		return(1);
	}

	sw_ptr =(unsigned int *)(h2p_lw_virtual_base + SW_BASE);
  SW_value = *(sw_ptr) & SW_MASK;
	printf("\nValue of SW is - %x\n",SW_value);

   //=== get VGA char addr =====================
	// get virtual addr that maps to physical
	vga_char_virtual_base = mmap( NULL, FPGA_CHAR_SPAN, ( 	PROT_READ | PROT_WRITE ), MAP_SHARED, fd, FPGA_CHAR_BASE );	
	if( vga_char_virtual_base == MAP_FAILED ) {
		printf( "ERROR: mmap2() failed...\n" );
		close( fd );
		return(1);
	}
    
    // Get the address that maps to the FPGA LED control 
	vga_char_ptr =(unsigned int *)(vga_char_virtual_base);

	// === get VGA pixel addr ====================
	// get virtual addr that maps to physical
	vga_pixel_virtual_base = mmap( NULL, FPGA_ONCHIP_SPAN, ( 	PROT_READ | PROT_WRITE ), MAP_SHARED, fd, 			FPGA_ONCHIP_BASE);	
	if( vga_pixel_virtual_base == MAP_FAILED ) {
		printf( "ERROR: mmap3() failed...\n" );
		close( fd );
		return(1);
	}
    
    // Get the address that maps to the FPGA pixel buffer
	vga_pixel_ptr =(unsigned int *)(vga_pixel_virtual_base);

	// ===========================================

	/* create a message to be displayed on the VGA 
          and LCD displays */
	char text_top_row[80]    = "DE1-SoC ARM/FPGA   Depth = 1024 samples\0";
	char text_bottom_row[80] = "Cornell ECE5760    Resolution = 16 pixel/sample\0";
  
  
  char bus_signal[32][40];
  for( i = 0; i < 32; i = i + 1 ) {
    sprintf(bus_signal[i], "b[%2d] = 1'b0",i);
  }

  char wave_signal[8][40];
  for( i = 0; i < 8; i = i + 1 ) {
    sprintf(wave_signal[i], "b[%2d:%2d]=4'd 0",4*i+3,4*i);
  }

	// clear the screen
	clear_life();
  VGA_box (0, 0, 639, 479, 0x00);
	// clear the text
	VGA_text_clear();
	VGA_text (1, 1, text_top_row);
	VGA_text (1, 2, text_bottom_row);
  	
	// draw the initial pattern
	for (i=1; i<639; i++) {
		for (j=1; j<479; j++) {
			VGA_PIXEL(i,j,0xff*life[i][j]);
		}
	}
  i=28;	
  for( i = 28; i > 0; i = i - 1 ) {
    VGA_text (1, 4+2*(28-i), bus_signal[i-1]);
  }

  // Take care of Ctrl + C kill
  signal(SIGINT,intHandler);	

  // State Machine starts

	while(keepRunning) 
	{
    
    SW_value = *(sw_ptr) & SW_MASK;
    sign = (SW_value & 0x004) >> 2;
    trigger = (SW_value & 0x008) >> 3;
    // printf("\nSW value is - %d",SW_value);
    
    // Read Mouse     
    bytes = read(fm, data, sizeof(data));
    // printf("\nIn While");
    if(bytes > 0)
    {
        left = data[0] & 0x1;
        right = data[0] & 0x2;
        middle = data[0] & 0x4;

        posx = data[1];
        posy = data[2];
        // printf("x=%d, y=%d, left=%d, middle=%d, right=%d\n", posx, posy, left, middle, right);

        cursor_x += (int )posx;
        cursor_y -= (int )posy;
        // wrap around cursor position if out-of-screen ... 
        if( cursor_x > 639 ) {
          cursor_x = 320;
          VGA_box(129,29,639,479,0x0);
          if ( x < (depth/2 - (512/resolution)) )
            x += 512/resolution; 
        }
        else if( cursor_x < 128 ) {
          cursor_x = 320;
          VGA_box(129,29,639,479,0x0);
          if ( x >= (512/resolution) )
            x -= 512/resolution; 
          else if( x < (512/resolution) )
            x = 0; 
        }
        if( cursor_y > 479 )
          cursor_y = 479;
        else if( cursor_y < 0 )
          cursor_y = 0;
        // printf("Current cursor position x=%d, y=%d\n", cursor_x, cursor_y);
        // printf("\nRightClick=%d, LeftClick=%d, Right_Flag=%d, Left_Flag=%d",right,left,right_flag,left_flag);
    }
    
    VGA_line(128,28,128,479,0xff);
    VGA_line(0,28,639,28,0xff);
    VGA_line(639,28,639,479,0xff);

    if( right != 0 ) {
      if( right_flag == 0 ) {  
        if( resolution < (depth/4) ) {  
          resolution = resolution*2;
          VGA_box(129,29,639,479,0x0);
        } else {
          resolution = depth/4;
        }
        right_flag = 1;
      }
    }
    else if( left != 0 ) {
      if( left_flag == 0 ) {  
        if( resolution > 2 ) {  
          resolution = resolution/2;
          VGA_box(129,29,639,479,0x0);
        } else {
          resolution = 2;
        }
        left_flag = 1;
      }
    }

    if( left == 0 ) {
      left_flag = 0;
    }
    if( right == 0 ) {
      right_flag = 0;
    }
    
    if( trigger == 0 ) {
      trig_flag = 0;
    } 
    // Trigger Mode On
    if ( (trigger == 0x1) && (capture == 0) && (trig_flag == 0) ) {
      if( cap_flag == 0 ) {
        printf("\nEnter trigger value - ");
        ret = scanf("%d",&data_capture);
        printf("\nWaiting for trigger!");
        cap_flag = 1;
      }
	    if( capture == 0 ) {
        file_read(buf,depth,act_value);
        
        for( j = 0; j < 28; j++ ) {
          for( k = 0; k < depth/4; k++ ) {
            flag[27-j][k+1] = (act_value[k] & mask[28-j])>>(27-j);
          }
        }
        // printf("\nFirst flag");
        for( j = 0; j < 8; j++ ) {
          for( k = 0; k < depth/4; k++ ) {
            flag4[7-j][k+1] = (act_value[k] & mask4[8-j])>>(4*(7-j));
          }
        }
        // printf("\nFirst flag4");
        
        for( i=0; i<depth; i++ ) {
          if( act_value[i] == data_capture ) {
            capture = 1;
            trig_flag = 1;
            printf("\nTriggered!");
          }
          if( capture == 0x1 ) {
            printf("\nCapturing Paused!");
            break;
          }
        }
        VGA_box(129,29,639,479,0x0);
      }
    }
    // Continuous Capture Mode On
    else if ( (SW_value  & 0x1) == 0x1 ) {
      capture = 0;
      cap_flag = 0;
      file_read(buf,depth,act_value);
      
      for( j = 0; j < 28; j++ ) {
        for( k = 0; k < depth/4; k++ ) {
          flag[27-j][k+1] = (act_value[k] & mask[28-j])>>(27-j);
        }
      }
      // printf("\nFirst flag");
      for( j = 0; j < 8; j++ ) {
        for( k = 0; k < depth/4; k++ ) {
          flag4[7-j][k+1] = (act_value[k] & mask4[8-j])>>(4*(7-j));
        }
      }
      // printf("\nFirst flag4");
      
      VGA_box(129,29,639,479,0x0);
    }

    // Digital Mode On
    if( ((SW_value & 0x2) == 0x0) && ((trig_flag == 0x1)||(trigger==0x0)) ) {
      //printf("\nIn Digital Mode");
      capture = 0;
      cap_flag = 0;
      // Draw lines at various bus locations
      for( j = 0; j < 28; j++ ) {
        for( k = x; k < (x+(512/resolution)); k++ ) {
          //flag[27-j][k+1] = (act_value[k] & mask[28-j])>>(27-j);
          VGA_line(128+((k-x)*resolution),bus[27-j]-(10*flag[27-j][k+1]),127+(((k-x)+1)*resolution),bus[27-j]-(10*flag[27-j][k+1]),green);
          if( flag[27-j][k+1] != flag[27-j][k] ) {
            VGA_line(128+((k-x)*resolution),bus[27-j]-(10*flag[27-j][k+1]),128+((k-x)*resolution),bus[27-j]-(10*flag[27-j][k]),green);
          }
        }
      }
      
      if( digital_flag == 0 ) {
        VGA_text_clear();
        VGA_box(129,29,639,479,0x0);
        printf("\nEntering Digital Mode!");
        digital_flag = 1;
        analog_flag  = 0;
      }

      // Print Signal values
      s = x + (cursor_x-128)/resolution;
      sprintf(text_top_row, "DE1-SoC ARM/FPGA   Depth = %4d samples         b[31:0]=0x%.8x",depth,act_value[s]);
      sprintf(text_bottom_row, "Cornell ECE5760    Resolution = %3d pixel/sample",resolution);
      VGA_text (1, 1, text_top_row);
      VGA_text (1, 2, text_bottom_row);
      for( j = 0; j < 32; j++ ) {
        sprintf(bus_signal[31-j], "b[%2d] = 1'b%d",(31-j),flag[31-j][s+1]);
      } 
      for( i = 28; i > 0; i = i - 1 ) {
        VGA_text (1, 4+2*(28-i), bus_signal[i-1]);
      }

    }

    // Analog Mode On
    else if( (SW_value & 0x2) == 0x2 ) {
      capture = 0;
      cap_flag = 0;
      // Draw lines at various bus locations
      for( j = 0; j < 8; j++ ) {
        for( k = x; k < (x+(512/resolution)); k++ ) {
          //flag4[7-j][k+1] = (act_value[k] & mask4[8-j])>>(4*(7-j));
          if ( sign ) {
            flag4[7-j][k+1] = (flag4[7-j][k+1] < 8) ? flag4[7-j][k+1] : -1*(16-flag4[7-j][k+1]);
            VGA_line(128+((k-x)*resolution),wave[7-j]-24-(3*flag4[7-j][k+1]),127+(((k-x)+1)*resolution),wave[7-j]-24-(3*flag4[7-j][k+1]),green);
            if( flag4[7-j][k+1] != flag4[7-j][k] ) {
              VGA_line(128+((k-x)*resolution),wave[7-j]-24-(3*flag4[7-j][k+1]),128+((k-x)*resolution),wave[7-j]-24-(3*flag4[7-j][k]),green);
            }
          } else {
            VGA_line(128+((k-x)*resolution),wave[7-j]-(3*flag4[7-j][k+1]),127+(((k-x)+1)*resolution),wave[7-j]-(3*flag4[7-j][k+1]),green);
            if( flag4[7-j][k+1] != flag4[7-j][k] ) {
              VGA_line(128+((k-x)*resolution),wave[7-j]-(3*flag4[7-j][k+1]),128+((k-x)*resolution),wave[7-j]-(3*flag4[7-j][k]),green);
            }
          }
        }
      }

      if( analog_flag == 0 ) {
        VGA_text_clear();
        VGA_box(129,29,639,479,0x0);
        printf("\nEntering Analog Mode!");
        analog_flag  = 1;
        digital_flag = 0;
      }

      // Print Signal values
      s = x + (cursor_x-128)/resolution;
      sprintf(text_top_row, "DE1-SoC ARM/FPGA   Depth = %4d samples         b[31:0]=0x%.8x",depth,act_value[s]);
      sprintf(text_bottom_row, "Cornell ECE5760    Resolution = %3d pixel/sample",resolution);
      VGA_text (1, 1, text_top_row);
      VGA_text (1, 2, text_bottom_row);
      for( j = 0; j < 8; j++ ) {
        sprintf(wave_signal[j], "b[%2d:%2d]=4'd%2d",4*j+3,4*j,flag4[j][s+1]);
      } 
      for( i = 8; i > 0; i = i - 1 ) {
        VGA_text (1, 8+6*(8-i), wave_signal[i-1]);
      }

    }

    // Keep drawing mouse pointer on idle
    if( (cursor_x != old_x) || (cursor_y != old_y) ) {
      draw_cursor(old_x,old_y,0); 
      VGA_line(old_x,0,old_x,479,0x00);
      draw_cursor(cursor_x,cursor_y,1); 
      VGA_line(cursor_x,0,cursor_x,479,0xfc);
      old_x = cursor_x;
      old_y = cursor_y;
      printf("\nSample start value - %d",x);
    } else {
      draw_cursor(cursor_x,cursor_y,1); 
    }

	} // end while(1)
  // free(act_value);
  // free(buf);
  // close(fd_xbus);
  printf("\nExiting main!");
} // end main

/****************************************************************************************
 * Subroutine to send a string of text to the VGA monitor 
****************************************************************************************/
void VGA_text(int x, int y, char * text_ptr)
{
  	volatile char * character_buffer = (char *) vga_char_ptr ;	// VGA character buffer
	int offset;
	/* assume that the text string fits on one line */
	offset = (y << 7) + x;
	while ( *(text_ptr) )
	{
		// write to the character buffer
		*(character_buffer + offset) = *(text_ptr);	
		++text_ptr;
		++offset;
	}
}

/****************************************************************************************
 * Subroutine to clear text to the VGA monitor 
****************************************************************************************/
void VGA_text_clear()
{
  	volatile char * character_buffer = (char *) vga_char_ptr ;	// VGA character buffer
	int offset, x, y;
	for (x=0; x<80; x++){
		for (y=0; y<60; y++){
	/* assume that the text string fits on one line */
			offset = (y << 7) + x;
			// write to the character buffer
			*(character_buffer + offset) = ' ';		
		}
	}
}

/****************************************************************************************
 * Draw a filled rectangle on the VGA monitor 
****************************************************************************************/
#define SWAP(X,Y) do{int temp=X; X=Y; Y=temp;}while(0) 

void VGA_box(int x1, int y1, int x2, int y2, short pixel_color)
{
	char  *pixel_ptr ; 
	int row, col;
        printf("\nVGA Box");	

	/* check and fix box coordinates to be valid */
	if (x1>639) x1 = 639;
	if (y1>479) y1 = 479;
	if (x2>639) x2 = 639;
	if (y2>479) y2 = 479;
	if (x1<0) x1 = 0;
	if (y1<0) y1 = 0;
	if (x2<0) x2 = 0;
	if (y2<0) y2 = 0;
	if (x1>x2) SWAP(x1,x2);
	if (y1>y2) SWAP(y1,y2);
	for (row = y1; row <= y2; row++)
		for (col = x1; col <= x2; ++col)
		{
			//640x480
			pixel_ptr = (char *)vga_pixel_ptr + (row<<10)    + col ;
			// set pixel color
			*(char *)pixel_ptr = pixel_color;		
		}
}

// =============================================
// === Draw a line
// =============================================
//plot a line 
//at x1,y1 to x2,y2 with color 
//Code is from David Rodgers,
//"Procedural Elements of Computer Graphics",1985
void VGA_line(int x1, int y1, int x2, int y2, short c) {
	int e;
	signed int dx,dy,j, temp;
	signed int s1,s2, xchange;
     signed int x,y;
	char *pixel_ptr ;
	/* check and fix line coordinates to be valid */
	if (x1>639) x1 = 639;
	if (y1>479) y1 = 479;
	if (x2>639) x2 = 639;
	if (y2>479) y2 = 479;
	if (x1<0) x1 = 0;
	if (y1<0) y1 = 0;
	if (x2<0) x2 = 0;
	if (y2<0) y2 = 0;
        
	x = x1;
	y = y1;
	
	//take absolute value
	if (x2 < x1) {
		dx = x1 - x2;
		s1 = -1;
	}

	else if (x2 == x1) {
		dx = 0;
		s1 = 0;
	}

	else {
		dx = x2 - x1;
		s1 = 1;
	}

	if (y2 < y1) {
		dy = y1 - y2;
		s2 = -1;
	}

	else if (y2 == y1) {
		dy = 0;
		s2 = 0;
	}

	else {
		dy = y2 - y1;
		s2 = 1;
	}

	xchange = 0;   

	if (dy>dx) {
		temp = dx;
		dx = dy;
		dy = temp;
		xchange = 1;
	} 

	e = ((int)dy<<1) - dx;  
	 
	for (j=0; j<=dx; j++) {
		//video_pt(x,y,c); //640x480
		pixel_ptr = (char *)vga_pixel_ptr + (y<<10)+ x; 
		// set pixel color
		*(char *)pixel_ptr = c;	
		 
		if (e>=0) {
			if (xchange==1) x = x + s1;
			else y = y + s2;
			e = e - ((int)dx<<1);
		}

		if (xchange==1) y = y + s2;
		else x = x + s1;

		e = e + ((int)dy<<1);
	}
}

void clear_life(){
	int i,j;
	for(i = 0; i< 640; i++) {
		for(j = 0; j < 480; j++) {
			life[i][j] = 0;
		}
	}
}

void draw_cursor(int cursor_x, int cursor_y, int val) {
  
  // Masking other bytes 
  short int color = val ? 0xe0 : 0x00;

  // Bounds Check
  if( (cursor_x < 636) && (cursor_y < 476) ) {
	  VGA_PIXEL(cursor_x  ,cursor_y  ,color);
	  VGA_PIXEL(cursor_x+1,cursor_y  ,color);
	  VGA_PIXEL(cursor_x+2,cursor_y  ,color);
	  VGA_PIXEL(cursor_x  ,cursor_y+1,color);
	  VGA_PIXEL(cursor_x  ,cursor_y+2,color);
	  VGA_PIXEL(cursor_x+1,cursor_y+1,color);
	  VGA_PIXEL(cursor_x+2,cursor_y+2,color);
	  VGA_PIXEL(cursor_x+3,cursor_y+3,color);
  }
  else {
	  VGA_PIXEL(cursor_x  ,cursor_y  ,color);
  }
}

void file_read( unsigned char* buf, int depth, unsigned int* act_value ) {
  
  int fd_xbus, rc;

  fd_xbus = open("/dev/xillybus_read_32", O_RDONLY);
  
  if (fd_xbus < 0) {
    if (errno == ENODEV)
      fprintf(stderr, "(Maybe xillybus_read_32 a write-only file?)\n");

    perror("Failed to open devfile");
    exit(1);
  }
  
  rc = read(fd_xbus, buf, (depth*4*sizeof(char)));
  close(fd_xbus);
  if (rc < 0) {
    perror("allread() failed to read");
    exit(1);
  }
  
  if (rc == 0) {
    fprintf(stderr, "Reached read EOF.\n");
    exit(0);
  }
  
  //printf("Data - \n%s\n",buf);

  //printf("Char data - %c\n",(char)buf[0]);
  //printf("Int data - %d\n",(int)buf[0]);
  
  int c,d=0;
  act_value[0] = 0;
  for (c=0;c<depth*4;c++)
  {
       act_value[d] |= ((int)buf[c])<<((c%4)*8);
       // printf("%.2X ", (int)buf[c]);
  
       // put an extra space between every 4 bytes
       if (c % 4 == 3)
       {
          // printf(" ");
           d = d+1;
           act_value[d] = 0;
       }
  
       // Display 16 bytes per line
       if (c % 16 == 15)
       {
           //printf("\n");
       }
  }

  //printf("\n");
  //c=0;
  //for (c=0;c<depth;c++)
  //{
  //    printf("%.8x\n",act_value[c]);
  //}

  // Add an extra line feed for good measure
  //printf("\n");
  //free(buf);
  

}
