function k = subkey(c,d)
%k=zeros(16,48);
cls=[-1, -1, -2, -2, -2, -2, -2, -2, -1, -2, -2, -2, -2, -2, -2, -1]; %circular left shift table 

for i=1:16
c=circshift(c,[0 cls(i)]);
d=circshift(d,[0 cls(i)]);
k(i,:)=pc2(c,d);
end
