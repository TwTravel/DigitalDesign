


%{
key=[dec2bin(hex2dec('54'),8), dec2bin(hex2dec('27'),8), dec2bin(hex2dec('53'),8), dec2bin(hex2dec('8b'),8), ...
    dec2bin(hex2dec('10'),8), dec2bin(hex2dec('00'),8), dec2bin(hex2dec('00'),8), dec2bin(hex2dec('00'),8)];
data = [dec2bin(hex2dec('4b'),8), dec2bin(hex2dec('47'),8), dec2bin(hex2dec('53'),8), dec2bin(hex2dec('21'),8), ...
    dec2bin(hex2dec('40'),8), dec2bin(hex2dec('23'),8), dec2bin(hex2dec('24'),8), dec2bin(hex2dec('25'),8)];
%}


clear all
%
%key=[0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0];
data=[0 1 0 0 1 0 1 1 0 1 0 0 0 1 1 1 0 1 0 1 0 0 1 1 0 0 1 0 0 0 0 1 0 1 0 0 0 0 0 0 0 0 1 0 0 0 1 1 0 0 1 0 0 1 0 0 0 0 1 0 0 1 0 1];

%key for A (after converting to ascii)
key=[0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0];

[c d] =pc1(key);
k = subkey(c,d); %16 subkeys

[l r] = ip(data);

for i=1:16

    
xr=xor(expansion(r),k(i,:)); 
b = sbox(xr);               
rold=r;
r= xor(l,c_p(b));           

deb_r(i,:)=r;
l=rold;
deb_l(i,:)=l;

end

out=fp(r,l);
bin64_2hex(out)
