//////////////////////////////////////
//	Audio HRTF Downselection and Testing HPS Code
/// 640x480 version! 16-bit color
//  Displayed from SDRAM
//  Dual Port SRAM Used for Memory Sharing between HPS and FPGA
//	Edited by Justin Cray and Mihir Marathe and Junpeng Wang
//	Multi-threaded to handle user input and Memory Transfer
// gcc -g top_level_final.c -o top -O2 -lm -pthread
///////////////////////////////////////


// Inclusion of standard libraries and protothreads
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/ipc.h> 
#include <sys/shm.h> 
#include <sys/mman.h>
#include <sys/time.h> 
#include <math.h> 
#include <pthread.h>

// Modified Address Map .h File
#include "address_map_arm_brl4.h"

// Audio Files
#include "impulse.h"
#include "motorcycle.h"	// test mode wav file
#include "fanfare.h"	// test mode wav file
#include "laugh_cough.h"	// test mode wav file
#include "dbell.h"	// down-selection sound

// FILE IO Macros
#define ACQWIDTH 3500
#define MAXFROWS 2504
#define ARRSIZE 200

// Display Macros
#define PI_180 0.0174532925

//----------------------------------------------------------------------------------//
//-----------VGA SETUP----------------//
//----------------------------------------------------------------------------------//

// 16-bit primary colors
#define red  (0+(0<<5)+(31<<11))
#define dark_red (0+(0<<5)+(15<<11))
#define green (0+(63<<5)+(0<<11))
#define dark_green (0+(31<<5)+(0<<11))
#define blue (31+(0<<5)+(0<<11))
#define dark_blue (15+(0<<5)+(0<<11))
#define yellow (0+(63<<5)+(31<<11))
#define cyan (31+(63<<5)+(0<<11))
#define magenta (31+(0<<5)+(31<<11))
#define black (0x0000)
#define gray (15+(31<<5)+(51<<11))
#define white (0xffff)


//	Sub-Function Declarations
void VGA_text (int, int, char *);
void VGA_text_clear();
void VGA_box (int, int, int, int, short);
void VGA_line(int, int, int, int, short) ;
void VGA_disc (int, int, int, short);
int elaz_to_hrirIndex(float, float);
void hrir_lr_assign(int, int);
int get_already_tested(int);
int put_already_tested(int);

// pixel macro
#define VGA_PIXEL(x,y,color) do{\
	int  *pixel_ptr ;\
	pixel_ptr = (int*)((char *)vga_pixel_ptr + (((y)*640+(x))<<1)) ; \
	*(short *)pixel_ptr = (color);\
} while(0)


//----------------------------------------------------------------------------------//
//-----------AVALON BUS READ/WRITE / MEMORY SETUP----------------//
//----------------------------------------------------------------------------------//

// the light weight buss base
void *h2p_lw_virtual_base;

// RAM FPGA command buffer
volatile unsigned int * sram_ptr = NULL ;
void *sram_virtual_base;

// pixel buffer
volatile unsigned int * vga_pixel_ptr = NULL ;
void *vga_pixel_virtual_base;

// character buffer
volatile unsigned int * vga_char_ptr = NULL ;
void *vga_char_virtual_base;

volatile unsigned int * h2p_pio_areset_addr = NULL;

// /dev/mem file id
int fd;

// measure time
struct timeval t1, t2;
double elapsedTime;
struct timespec delay_time ;

// SRAM memory offsets for data transfer
int sram_offset_hrir_l = 0;	// will change as hrir is loaded into memory
int sram_offset_hrir_r = 200; // will change as hrir is loaded into memory
int sram_offset_sound = 400;
int sram_offset_status = 401;


//----------------------------------------------------------------------------------//
//-----------DATA PROCESSING SETUP----------------//
//----------------------------------------------------------------------------------//

typedef signed int fix ;			//Used to convert to fixed point
#define float2fix(a) ((fix)((a)*131072.0))         //Convert float to 10.17 fix. a is a float
int GAIN = 3;		// Gain of System, default to 3 (settable by User Input)

// Global Variables for Down-selection
// Subject and Associated Subjects arrays (subjects[][] can be replaced depending on type of preprocessing)
int subjs[45] = {3, 8, 9, 10, 11, 12, 15, 17, 18, 19, 20, 21, 27, 28, 33, 40, 44, 48, 50, 51, 58, 59, 60, 61, 65, 119, 124, 126, 127, 131, 133, 134, 135, 137, 147, 148, 152, 153, 154, 155, 156, 158, 162, 163, 165};
int subjects[45][6]={{27,48,153,162,147,156},{155,162,153,133,156,163},{162,148,163,60,134,153},{156,165,153,162,155,158},{60,155,137,162,127,153},{153,0,0,0,0,0},{10,165,154,162,124,155},{44,155,119,162,153,135},{162,48,124,131,153,163},{60,155,162,59,153,163},{134,155,162,163,61,65},{153,165,124,155,133,162},{28,48,124,155,162,156},{131,162,155,133,156,165},{59,65,155,162,50,163},{60,155,162,163,135,148},{60,65,119,135,155,162},{153,27,155,162,133,148},{155,162,137,153,163,156},{48,28,131,153,162,156},{44,119,126,155,134,0},{65,155,162,163,148,156},{40,44,155,162,163,137},{155,60,162,124,153,147},{44,59,60,126,155,153},{44,126,60,135,155,162},{28,155,162,156,158,163},{119,60,65,134,155,162},{155,60,162,147,153,163},{28,153,156,165,148,158},{48,153,162,148,158,165},{20,60,155,162,135,153},{44,119,137,155,126,153},{20,60,155,162,163,148},{27,48,162,133,137,131},{162,155,163,153,147,156},{11,155,60,135,137,0},{48,131,162,165,158,147},{10,15,165,153,155,162},{162,124,153,163,158,147},{10,165,131,153,154,162},{153,162,131,156,165,154},{155,48,153,163,133,158},{162,28,59,124,153,147},{10,156,153,154,48,133}};
float el;
float az;
int hrir_index;
int mode = -1;
int incrementer;
int els[4] = {45, 0, 225, 0};
int azs[4] = {-35, 35, 35, -35};
int closeness = 0;
int farness = 0;
int drawing;
int draw = -1;
int hrir_tested[45] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
					    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
int subject_subpntr = -1;
int goodput;

// Global Variables for UI Purposes
int hrir_set;
int sfile;
float left_arr[200];
float right_arr[200];
float *sound_to_play;
int play = 0;
int soundsize;
int replay;

int el_x;
int el_y;
int az_x;
int az_y;

// Test mode Global Variables
int test_elevation[] = {0,180};
int az_sweep_f[] = {-65,-35,-15,5,25,45};
int az_sweep_b[] = {45,25,5,-15,-35,-65};
int az_sample_len;


/* create a message to be displayed on the VGA 
      and LCD displays */
char* text_to_display;

// FILE IO Global Variables
FILE *input;

//Display Variables
int z=0;


// Thread 1 To Read User Input and Handle Audio Processing
void * read1(){
	while(1){
		
		// Startup Mode (initialization)
		if(mode == -1){
		//Test or Downsample
		printf("Please enter Audio Gain Desired(3 for headphones,4 for speakers):\n");
		scanf("%d",&GAIN);
		printf("\n");
		printf("Enter which mode to Enter (2 = Exit, 1 = Test, 0 = Downsample):\n");
		scanf("%d", &mode);
		}
		
		//----------- DOWNSELECTION MODE ----------------//
		else if(mode == 0){
			sleep(3);	// Used for Display thread synchronization (can be reduced to 1 second if needed)
			
			// In this mode, down-sel sound is doorbell
			play = 0;
			sound_to_play = dbell;
			soundsize = 18000;
			
			printf("Enter starting HRIR number (from Available Total List): \n");
			scanf("%d", &hrir_set);
			
			// Iterations to test 4 test points
			int a = -1;
			for (a = 0; a <4 ; a=a+1) {
				el = (float)(els[a]);
				az = (float)(azs[a]);
				drawing = a;		// Display thread synch variable
				sleep(1);
				
				// Display current HRIR Subject
				printf("Current HRIR Subject Number: %d\n", hrir_set);
				
				// Set hrir indices based on User input
				hrir_index = elaz_to_hrirIndex(el,az);
				
				// Pass hrir_set through if else to load left_arr and right_arr
				hrir_lr_assign(hrir_set, hrir_index);
				
				printf("Ready to Play Sound? (0 = No,1 = Yes) : \n");
				scanf("%d", &play);

				draw = 1;

				// Play sound
				while(play == 1){

					// RESET convolution machine
					*h2p_pio_areset_addr = 1;
					sleep(1);
					*h2p_pio_areset_addr = 0;

					// Load HRIRs into memory
					int i;
					for(i = 0; i<200; i = i+1){		
						*(sram_ptr+sram_offset_hrir_l+i) = float2fix(left_arr[i]);
						*(sram_ptr+sram_offset_hrir_r+i) = float2fix(right_arr[i]);
					}			

					// Load sounds and wait on each sample's status to be set to 0
					int j;
					for(j = 0; j<soundsize; j=j+1){			// Soundsize set during sound selection
						*(sram_ptr+sram_offset_sound) = (float2fix(*(sound_to_play + j)))<<GAIN;
						
						if(j ==0){
							*(sram_ptr+sram_offset_status) = 2;
						}
						else{
							*(sram_ptr+sram_offset_status) = 1;
						}
						while((int)(*(sram_ptr+sram_offset_status)) != 0);
					}

					printf("Would you like to replay the sound?(1 = yes,0 = no) \n");
					scanf("%d", &replay);
					play = replay;
				}

				//---------- Downselection Part Start---------------//
				printf("Does this sound like it's in the right position (0 = NO, 1 = YES, 2 = CLOSE)?\n");
				scanf("%d", &incrementer);
				
				if(incrementer ==  1) {
					//Do nothing, let the for loop do its thing
				}
				else if ((incrementer == 0) && (farness < 1)) {
					//One bad reading, keep going
					farness = farness + 1;
				}
				else if ((incrementer== 0) && (farness>=1)) {
					//Start over
					a = -1;
					subject_subpntr = -1;
					hrir_set = best_guess(hrir_set,2,subject_subpntr);
					closeness = 0;
					farness=0;

					// If no random variable subject found, exit code
					if(hrir_set == 0){
						printf("UH-OH! We can't find any other HRIRs that might work....\nExiting Program NOW!");
						sleep(1);
						exit(0);
					}
					goodput = put_already_tested(hrir_set);
					if(goodput==0){
						printf("Unable to put new HRIR into tested array. Exiting program due to this..\n");
						exit(0);
					}
					printf("Starting Over with New 'Random' HRIR Subject #: %d\n\n", hrir_set);
				}
				else if ((incrementer == 2) && (closeness < 1)) {
					//User said it was close
					closeness = closeness + 1;
				}
				else if((incrementer == 2) && (closeness >= 1)){
					// If too many 'close' evals, find a closeby new subject
					printf("You have too many 'close' evaluations. Finding a different but close-by HRIR # for you.\n");
					subject_subpntr = subject_subpntr+1;
					hrir_set = best_guess(hrir_set,1,subject_subpntr);

					// If no closeby subject
					if(hrir_set==0){
						//do random search
						printf("Ran out of close-by subjects. Will be getting a new random HRIR Subject\n");
						a = -1;
						subject_subpntr = -1;
						hrir_set = best_guess(hrir_set,2,subject_subpntr);
						closeness = 0;
						farness=0;
						// If no random subj available
						if(hrir_set == 0){
							printf("UH-OH! We can't find any other HRIRs that might work....\nExiting Program NOW!");
							sleep(1);
							exit(0);
						}
						goodput = put_already_tested(hrir_set);
						if(goodput==0){
							printf("Unable to put new hrir into tested array. Exiting program due to this..\n");
							exit(0);
						}
						printf("Starting Over with New 'Random' HRIR Subject #: %d\n\n", hrir_set);
					}
					goodput = put_already_tested(hrir_set);
					if(goodput==0){
						printf("Unable to put new hrir into tested array. Exiting program due to this..\n");
						exit(0);
					}
					a = -1;
					closeness = 0;
					farness=0;
					printf("Starting Over with New 'Close' HRIR Subject #: %d\n", hrir_set);
				}
				else{
					printf("YOU ENTERED A BAD INPUT, OR SOMETHING WENT WRONG. RESTARTING PROGRAM.\n");
					exit(0);
				}
				//---------- Downselection Part End ---------------//
				
				// Clear display circles and loop
				draw = 0;
				sleep(1);
			}
			// Final subject match decision
			printf("Your best HRIR subject match is Subject #: %d \n", hrir_set);
			printf("What do you want to do now (0 = Retry Downsample, 1 = Test Mode, 2 = Exit)?\n");
			scanf("%d", &mode);
		}
		


		//----------- TESTING MODE ----------------//
		if (mode == 1) {
			sleep(2);
			//Do test mode
			printf("Entering Audio Test Mode\n");
			
			// Enter HRIR to Test
			printf("Please select your best matched HRIR Subject number: \n");
			scanf("%d", &hrir_set);
			
			// Enter sound sample to test
			printf("Select Audio Sound to Play (1 = Motorcycle, 2 = Fanfare, 3 = Laugh_cough): \n");
			scanf("%d", &sfile);

			// Pass sound to play into array pointer
			if(sfile==1){
				sound_to_play = motorcycle;
				soundsize = 221184;
			}
			else if(sfile==2){
				sound_to_play = fanfare;
				soundsize = 221184;
			}
			else{
				sound_to_play = laugh_cough;
				soundsize = 221184;
			}
			
			printf("The Sound will be swept around your head at an elevation of O degrees using your down-selected HRIR subject.\n");
			printf("The starting point of the elevation will be to your left, at an Azimuth of -65 degrees.\n");
			printf("12 different locations will be played sound at around your head, with a total sound sample size of around 5 seconds.\n\n");
			printf("Ready to play audio (0 = No, 1 = Yes):\n");
			scanf("%d", &play);

			while(play == 1){
				// RESET convolution machine
				*h2p_pio_areset_addr = 1;
				sleep(1);
				*h2p_pio_areset_addr = 0;
				
				//play sound in segments of 12
				az_sample_len = soundsize/12;
				int i;
				// First 6 audio points in front of the user
				for(i = 0; i<6; i=i+1){
					// Set hrir indices based on User input
					hrir_index = elaz_to_hrirIndex(test_elevation[0],az_sweep_f[i]);
					
					// Pass hrir_set through if else to load left_arr and right_arr
					hrir_lr_assign(hrir_set, hrir_index);
					
					int k;
					for(k = 0; k<200; k = k+1){		
						*(sram_ptr+sram_offset_hrir_l+k) = float2fix(left_arr[k]);
						*(sram_ptr+sram_offset_hrir_r+k) = float2fix(right_arr[k]);
					}
					for(k = 0; k<az_sample_len; k=k+1){			// Sound size set during sound selection
						*(sram_ptr+sram_offset_sound) = (float2fix(sound_to_play[k + az_sample_len*i]))<<GAIN;
						if(k ==0){
							*(sram_ptr+sram_offset_status) = 2;
						}
						else{
							*(sram_ptr+sram_offset_status) = 1;
						}
						while((int)(*(sram_ptr+sram_offset_status)) != 0);
					}
				}
				// Second six audio samples behind the user
				for(i = 0; i<6; i++){
					// Set hrir indices based on User input
					hrir_index = elaz_to_hrirIndex(test_elevation[1],az_sweep_b[i]);
					// Pass hrir_set through if else to load left_arr and right_arr
					hrir_lr_assign(hrir_set, hrir_index);
					
					int k;
					for(k = 0; k<200; k = k+1){		
						*(sram_ptr+sram_offset_hrir_l+k) = float2fix(left_arr[k]);
						*(sram_ptr+sram_offset_hrir_r+k) = float2fix(right_arr[k]);
					}
					for(k = 0; k<az_sample_len; k=k+1){			// Soundsize set during sound selection
						*(sram_ptr+sram_offset_sound) = (float2fix(sound_to_play[k + az_sample_len*(i+6)]))<<GAIN;
						if(k ==0){
							*(sram_ptr+sram_offset_status) = 2;
						}
						else{
							*(sram_ptr+sram_offset_status) = 1;
						}
						while((int)(*(sram_ptr+sram_offset_status)) != 0);
					}
				}				
				printf("Done playing sound.\n");
				printf("Would you like to replay the sound?(1 = yes,0 = no) \n");
				scanf("%d", &replay);
				play = replay;
			}
			printf("Done testing selected audio.\n\n");
			printf("What do you want to do now (0 = Retry Downsample, 1 = Test Mode, 2 = Exit)?\n");
			scanf("%d", &mode);
			sleep(1);
		} 
		
		//----------- EXIT MODE ----------------//
		if (mode == 2) {
			//Say done program and exit code
			sleep(3);
			printf("Exiting Program. Have a good day!\n");
			sleep(1);
			exit(0);
		}
	}
}


// Thread 2 to Display and Format Data on VGA Display
void * disp1()
{	
	while(1) 
	{	
		//----------- TESTING MODE ----------------//
		while(mode == 1) {
			//Test stuff
			VGA_box (0, 0, 639, 479, green);
			// clear the text
			VGA_text_clear();
			text_to_display = "TESTING YOUR SELECTED AUDIO";
			VGA_text (25, 30, text_to_display);
			VGA_text (19, 56, "HRIR Identification ECE 5760 Final Project");
			VGA_text (20, 57, "Mihir Marathe, Justin Cray, Junpeng Wang");
			// While loop to prevent screen refreshing constantly
			while(mode == 1){
				sleep(1);
			}
			z=0;
		}
		
		//----------- DOWNSELECTION MODE ----------------//
		while(mode == 0) {
			//Downsample stuff, more amusing
			
			// Formt Screen once with static images
			if(z==0){
				VGA_box (0, 0, 639, 479, black);
				// clear the text
				VGA_text_clear();
				VGA_line(1,470,678,470,white);
				VGA_line(1,1,678,1,white);
				VGA_line(320,1,320,439,white);
				VGA_line(1,1,1,470,white);
				VGA_line(678,1,678,470,white);
				VGA_line(1,439,678,439,white);
				
				
				//Draw circles as fake heads
				VGA_disc(160,290,80, white);
				VGA_disc(480,290,80, white);
				
				//Fake Eye Circles
				VGA_disc(115,260,7, cyan);
				VGA_disc(450,230,5, cyan);
				VGA_disc(510,230,5, cyan);
				
				// Fake Nose boxes
				VGA_box(70,280,160,300, dark_red);
				VGA_box(470,200,490,290, dark_red);
				
				//Draw text
				VGA_text (16, 1, "Elevation");
				VGA_text (8, 2, "Side View of Gerald's Head");
				VGA_text (58, 1, "Azimuth");
				VGA_text (45, 2, "Top Down View of Gerald's Head");
				VGA_text (19, 56, "HRIR Identification ECE 5760 Final Project");
				VGA_text (20, 57, "Mihir Marathe, Justin Cray, Junpeng Wang");
				z=1;
			}
			
			// Upon Draw synch from read thread, draw new azimuth/elevation
			if(draw==1){
				el = els[drawing];
				az = azs[drawing];
				
				el_x = 160 - 120 * cos(el * PI_180);
				el_y = 290 - 120 * sin(el * PI_180);
				az_x = 480 + 120 * cos((90-az)*PI_180);
				az_y = 290 - 120 * sin((90-az)*PI_180);
				
				VGA_disc(el_x, el_y, 10, green);
				VGA_disc(az_x, az_y, 10, blue);
				draw = -1;
			}
			// Clear azimuth/elevation indicator circles
			else if(draw == 0){
				VGA_disc(el_x, el_y, 10, black);
				VGA_disc(az_x, az_y, 10, black);
				draw = -1;
			}	
		}
		
		//----------- EXIT MODE ----------------//
		while(mode == 2){
			// exit program line on VGA and exit C code
			VGA_box (0, 0, 639, 479, red);
			// clear the text
			VGA_text_clear();
			text_to_display = "PROGRAM OVER. HAVE A GOOD DAY!";
			VGA_text (25, 30, text_to_display);
			VGA_text (19, 56, "HRIR Identification ECE 5760 Final Project");
			VGA_text (20, 57, "Mihir Marathe, Justin Cray, Junpeng Wang");
			// Prevents constant screen refresh
			while(mode == 2){
				sleep(1);
			}
			z=0;
		}
	}
}


//----------------------------------------------------------------------------------//
//-----------MAIN FUNCTION PROCESSING---------------//
//----------------------------------------------------------------------------------//

int main(void)
{
	// Declare volatile pointers to I/O registers (volatile 	// means that IO load and store instructions will be used 	// to access these pointer locations, 
	// instead of regular memory loads and stores) 
  	
	// === need to mmap: =======================
	// FPGA_CHAR_BASE
	// FPGA_ONCHIP_BASE      
	// HW_REGS_BASE        
  
	// === get FPGA addresses ==================
    // Open /dev/mem
	if( ( fd = open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) 	{
		printf( "ERROR: could not open \"/dev/mem\"...\n" );
		return( 1 );
	}
    
    // get virtual addr that maps to physical
	// for light weight bus
	h2p_lw_virtual_base = mmap( NULL, HW_REGS_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, HW_REGS_BASE );	
	if( h2p_lw_virtual_base == MAP_FAILED ) {
		printf( "ERROR: mmap1() failed...\n" );
		close( fd );
		return(1);
	}

	// Create PIO address using QSYS defined offsets
	h2p_pio_areset_addr = (volatile int *)(h2p_lw_virtual_base+0xC0);

	
	// === get VGA char addr =====================
	// get virtual addr that maps to physical
	vga_char_virtual_base = mmap( NULL, FPGA_CHAR_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, FPGA_CHAR_BASE );	
	if( vga_char_virtual_base == MAP_FAILED ) {
		printf( "ERROR: mmap2() failed...\n" );
		close( fd );
		return(1);
	}
    
    // Get the address that maps to the character 
	vga_char_ptr =(unsigned int *)(vga_char_virtual_base);

	// === get VGA pixel addr ====================
	// get virtual addr that maps to physical
	// SDRAM
	vga_pixel_virtual_base = mmap( NULL, SDRAM_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, SDRAM_BASE); //SDRAM_BASE	and span
	
	if( vga_pixel_virtual_base == MAP_FAILED ) {
		printf( "ERROR: mmap3() failed...\n" );
		close( fd );
		return(1);
	}
    // Get the address that maps to the FPGA pixel buffer
	vga_pixel_ptr =(unsigned int *)(vga_pixel_virtual_base);
	
	// === get RAM FPGA parameter addr =========
	sram_virtual_base = mmap( NULL, FPGA_ONCHIP_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, FPGA_ONCHIP_BASE); //fp	
	
	if( sram_virtual_base == MAP_FAILED ) {
		printf( "ERROR: mmap3() failed...\n" );
		close( fd );
		return(1);
	}

    // Get the address that maps to the RAM buffer
	sram_ptr =(unsigned int *)(sram_virtual_base);
	// ===========================================
	// clear the screen
	VGA_box (0, 0, 639, 479, black);
	// clear the text
	VGA_text_clear();
	// ===========================================
	// RESET Convolution Machine
	*h2p_pio_areset_addr = 1;	
	sleep(1);
	*h2p_pio_areset_addr = 0;
	// ===========================================
	// Setup threads per pthread example on ece5760 website
	pthread_t thread_vgadisplay, thread_read;//, thread_load;
	pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);
	
	// Create threads based on pthread functions defined above
	pthread_create(&thread_read,NULL,read1,NULL);
	pthread_create(&thread_vgadisplay,NULL,disp1,NULL);
	
	// Instantiate all threads
	pthread_join(thread_read,NULL);
	pthread_join(thread_vgadisplay,NULL);

	return 0;
} // end main
	

/****************************************************************************************
 * Subroutine to search if input subj is in tested array
****************************************************************************************/
int get_already_tested(int hset){
	// Global variable HTested array is called hrir_tested
	int succ = 0;
	int i;
	for(i = 0; i<45; i = i+1){
		if(hrir_tested[i] == hset){
			succ = 1;
		}
	}
	return succ;
	// If hset exists in hrir_tested, returns 1, else 0
}

/****************************************************************************************
 * Subroutine to put new HRIR subj number into hrir_tested array
****************************************************************************************/
int put_already_tested(int hset){
	// Global variable HTested array is called hrir_tested
	int i = 0;
	while((i<45)&&(hrir_tested[i] != 0)){
		i = i+1;
	}
	if(i<45){
		hrir_tested[i] = hset;
		return 1;
	}
	else{
		printf("Could Not place Subject into Tested Array\n\n");
		return 0;
	}
	// If successfully able to put in hrir_tested, return 1, else return 0;
}


/****************************************************************************************
 * Subroutine to return best subject guess
****************************************************************************************/
int best_guess(int subj, int closeness, int sub_pntr){
	//Closeness should be 0 = perfect, 1 = close, 2 = far off
	int rowarr[6];
	int ran_index = -1;

	// If correctly identified Subject, then preserve subject and return it
	if(closeness == 0){
		return subj;
	}
	
	// If Subject is 'close', then find next nearest close neighbor
	else if (closeness == 1) {
		if((sub_pntr>=6)||(sub_pntr == -1)){
			return 0;
		}

		//Find index of array
		int index = 0; 
		while(index < 45 && subjs[index] != subj) {
			index++;
		}

		while((sub_pntr>=0) && (sub_pntr<6)){
			
			//Grab 6 nearest neighbors
			memcpy(rowarr, subjects + index, sizeof(int)*6);

			if (rowarr[sub_pntr] == 0){
				return 0; 
			}
			if(get_already_tested(rowarr[sub_pntr])==1){
				sub_pntr = sub_pntr+1;
			}
			else{
				subject_subpntr = sub_pntr;
				return rowarr[sub_pntr];
			}
		}
		if(sub_pntr>=6){
			return 0;
		}
	}
	
	// if needing a random subject, find new random subject that has not been tested yet
	else if(closeness==2){
		int iter = 0;
		ran_index = rand() % (44 + 1 - 0) + 0;
		while(get_already_tested(subjs[ran_index])&&(iter<100)){
			ran_index = rand() % (44 + 1 - 0) + 0;
			iter = iter+1;
		}
		if(iter>=100){
			printf("Random Down-selection took more than 100 cycles.\n");
			return 0;

		}
		else{
			return subjs[ran_index];
		}
	}

	// Not Sure what's happening with inputs
	else{
		return 0;
	}
}



/****************************************************************************************
 * Subroutine to convert float elevations and azimuth to HRIR indices
****************************************************************************************/
int elaz_to_hrirIndex(float el, float az){
	float a, e;
	int hindex;

	if(az>=-45.0 && az<=45.0){
		if(az>=0.0){
			a = (az/5.0) + 1.0 + 11.0;
		}
		else{
			a = (9.0 - (abs(az)/5.0)) + 3.0;
		}
	}
	else if(az == -80.0){
		a = 0.0;
	}
	else if(az == -65.0){
		a = 1.0;
	}
	else if(az == -55.0){
		a = 2.0;
	}
	else if(az == 55.0){
		a = 22.0;
	}
	else if(az == 65.0){
		a = 23.0;
	}
	else {	// az == 80
		a = 24.0;
	}

	// e is converted index
	e = (el+45.0)/5.625;

	// Final HRIR L and R index
	hindex = (int)((a*50.0) + e);
	return hindex;
}


/****************************************************************************************
 * Subroutine to load left and right arrays with User specified subject and index values
****************************************************************************************/
void hrir_lr_assign(int hset, int hind){
	float temp;
	char* lptr;
	char* rptr;
	char buffl[ACQWIDTH];
	char buffr[ACQWIDTH];
	char bufftemp[ACQWIDTH];
	int lhindex, rhindex;
	char* name;
	
	// Convert User Input to correct filename
	if(hset==3){
		name = "hrir_headers/hrir_003.h";
	}
	else if(hset==8){
		name = "hrir_headers/hrir_008.h";
	}
	else if(hset==9){
		name = "hrir_headers/hrir_009.h";
	}
	else if(hset==10){
		name = "hrir_headers/hrir_010.h";
	}
	else if(hset==11){
		name = "hrir_headers/hrir_011.h";
	}
	else if(hset==12){
		name = "hrir_headers/hrir_012.h";
	}
	else if(hset==15){
		name = "hrir_headers/hrir_015.h";
	}
	else if(hset==17){
		name = "hrir_headers/hrir_017.h";
	}
	else if(hset==18){
		name = "hrir_headers/hrir_018.h";
	}
	else if(hset==19){
		name = "hrir_headers/hrir_019.h";
	}
	else if(hset==20){
		name = "hrir_headers/hrir_020.h";
	}
	else if(hset==21){
		name = "hrir_headers/hrir_021.h";
	}
	else if(hset==27){
		name = "hrir_headers/hrir_027.h";
	}
	else if(hset==28){
		name = "hrir_headers/hrir_028.h";
	}
	else if(hset==33){
		name = "hrir_headers/hrir_033.h";
	}
	else if(hset==40){
		name = "hrir_headers/hrir_040.h";
	}
	else if(hset==44){
		name = "hrir_headers/hrir_044.h";
	}
	else if(hset==48){
		name = "hrir_headers/hrir_048.h";
	}
	else if(hset==50){
		name = "hrir_headers/hrir_050.h";
	}
	else if(hset==51){
		name = "hrir_headers/hrir_051.h";
	}
	else if(hset==58){
		name = "hrir_headers/hrir_058.h";
	}
	else if(hset==59){
		name = "hrir_headers/hrir_059.h";
	}
	else if(hset==60){
		name = "hrir_headers/hrir_060.h";
	}
	else if(hset==61){
		name = "hrir_headers/hrir_061.h";
	}
	else if(hset==65){
		name = "hrir_headers/hrir_065.h";
	}
	else if(hset==119){
		name = "hrir_headers/hrir_119.h";
	}
	else if(hset==124){
		name = "hrir_headers/hrir_124.h";
	}
	else if(hset==126){
		name = "hrir_headers/hrir_126.h";
	}
	else if(hset==127){
		name = "hrir_headers/hrir_127.h";
	}
	else if(hset==131){
		name = "hrir_headers/hrir_131.h";
	}
	else if(hset==133){
		name = "hrir_headers/hrir_133.h";
	}
	else if(hset==134){
		name = "hrir_headers/hrir_134.h";
	}
	else if(hset==135){
		name = "hrir_headers/hrir_135.h";
	}
	else if(hset==137){
		name = "hrir_headers/hrir_137.h";
	}
	else if(hset==147){
		name = "hrir_headers/hrir_147.h";
	}
	else if(hset==148){
		name = "hrir_headers/hrir_148.h";
	}
	else if(hset==152){
		name = "hrir_headers/hrir_152.h";
	}
	else if(hset==153){
		name = "hrir_headers/hrir_153.h";
	}
	else if(hset==154){
		name = "hrir_headers/hrir_154.h";
	}
	else if(hset==155){
		name = "hrir_headers/hrir_155.h";
	}
	else if(hset==156){
		name = "hrir_headers/hrir_156.h";
	}
	else if(hset==158){
		name = "hrir_headers/hrir_158.h";
	}
	else if(hset==162){
		name = "hrir_headers/hrir_162.h";
	}
	else if(hset==163){
		name = "hrir_headers/hrir_163.h";
	}
	else{
		name = "hrir_headers/hrir_165.h";
	}
	
	// File Processing Segment
	input = fopen(name,"r");
	/*if (input == NULL){
		printf("Could Not Open File...\n");
	}
	else{
		printf("Successfully Opened File...\n");
	}*/
	
	lhindex = hind + 1;
	rhindex = lhindex + 1251;	
	
	// Get Two Rows with Appropriate HRIRs
	int i;
	for(i = 0; i<MAXFROWS; i++){
		if (i == lhindex){
			fgets(buffl,ACQWIDTH,(FILE*)input);
		}
		if(i == rhindex){
			fgets(buffr,ACQWIDTH,(FILE*)input);
		}
		else{
			fgets(bufftemp,ACQWIDTH,(FILE*)input);
		}
	}
	
	// Parse Row Strings into Float Arrays
	for(i = 0; i<ARRSIZE; i++){
		if(i==0){
			left_arr[i] = strtof(buffl+1, &lptr);
			right_arr[i] = strtof(buffr+1, &rptr);
		}
		else{
			left_arr[i] = strtof(lptr+1,&lptr);
			right_arr[i] = strtof(rptr+1,&rptr);
		}
	}
	
	fclose(input);
}

/****************************************************************************************
 * Subroutine to send a string of text to the VGA monitor 
****************************************************************************************/
void VGA_text(int x, int y, char * text_ptr)
{
  	volatile char * character_buffer = (char *) vga_char_ptr ;	// VGA character buffer
	int offset;
	/* assume that the text string fits on one line */
	offset = (y << 7) + x;
	while ( *(text_ptr) )
	{
		// write to the character buffer
		*(character_buffer + offset) = *(text_ptr);	
		++text_ptr;
		++offset;
	}
}

/****************************************************************************************
 * Subroutine to clear text to the VGA monitor 
****************************************************************************************/
void VGA_text_clear()
{
  	volatile char * character_buffer = (char *) vga_char_ptr ;	// VGA character buffer
	int offset, x, y;
	for (x=0; x<79; x++){
		for (y=0; y<59; y++){
	/* assume that the text string fits on one line */
			offset = (y << 7) + x;
			// write to the character buffer
			*(character_buffer + offset) = ' ';		
		}
	}
}

/****************************************************************************************
 * Draw a filled rectangle on the VGA monitor 
****************************************************************************************/
#define SWAP(X,Y) do{int temp=X; X=Y; Y=temp;}while(0) 

void VGA_box(int x1, int y1, int x2, int y2, short pixel_color)
{
	char  *pixel_ptr ; 
	int row, col;

	/* check and fix box coordinates to be valid */
	if (x1>639) x1 = 639;
	if (y1>479) y1 = 479;
	if (x2>639) x2 = 639;
	if (y2>479) y2 = 479;
	if (x1<0) x1 = 0;
	if (y1<0) y1 = 0;
	if (x2<0) x2 = 0;
	if (y2<0) y2 = 0;
	if (x1>x2) SWAP(x1,x2);
	if (y1>y2) SWAP(y1,y2);
	for (row = y1; row <= y2; row++)
		for (col = x1; col <= x2; ++col)
		{
			//640x480
			VGA_PIXEL(col, row, pixel_color);	
		}
}

/****************************************************************************************
 * Draw a filled circle on the VGA monitor 
****************************************************************************************/

void VGA_disc(int x, int y, int r, short pixel_color)
{
	char  *pixel_ptr ; 
	int row, col, rsqr, xc, yc;
	
	rsqr = r*r;
	
	for (yc = -r; yc <= r; yc++)
		for (xc = -r; xc <= r; xc++)
		{
			col = xc;
			row = yc;
			// add the r to make the edge smoother
			if(col*col+row*row <= rsqr+r){
				col += x; // add the center point
				row += y; // add the center point
				//check for valid 640x480
				if (col>639) col = 639;
				if (row>479) row = 479;
				if (col<0) col = 0;
				if (row<0) row = 0;
				VGA_PIXEL(col, row, pixel_color);
			}
					
		}
}

// =============================================
// === Draw a line
// =============================================
//plot a line 
//at x1,y1 to x2,y2 with color 
//Code is from David Rodgers,
//"Procedural Elements of Computer Graphics",1985
void VGA_line(int x1, int y1, int x2, int y2, short c) {
	int e;
	signed int dx,dy,j, temp;
	signed int s1,s2, xchange;
     signed int x,y;
	char *pixel_ptr ;
	
	/* check and fix line coordinates to be valid */
	if (x1>639) x1 = 639;
	if (y1>479) y1 = 479;
	if (x2>639) x2 = 639;
	if (y2>479) y2 = 479;
	if (x1<0) x1 = 0;
	if (y1<0) y1 = 0;
	if (x2<0) x2 = 0;
	if (y2<0) y2 = 0;
        
	x = x1;
	y = y1;
	
	//take absolute value
	if (x2 < x1) {
		dx = x1 - x2;
		s1 = -1;
	}

	else if (x2 == x1) {
		dx = 0;
		s1 = 0;
	}

	else {
		dx = x2 - x1;
		s1 = 1;
	}

	if (y2 < y1) {
		dy = y1 - y2;
		s2 = -1;
	}

	else if (y2 == y1) {
		dy = 0;
		s2 = 0;
	}

	else {
		dy = y2 - y1;
		s2 = 1;
	}

	xchange = 0;   

	if (dy>dx) {
		temp = dx;
		dx = dy;
		dy = temp;
		xchange = 1;
	} 

	e = ((int)dy<<1) - dx;  
	 
	for (j=0; j<=dx; j++) {

		VGA_PIXEL(x, y, c);	
		 
		if (e>=0) {
			if (xchange==1) x = x + s1;
			else y = y + s2;
			e = e - ((int)dx<<1);
		}

		if (xchange==1) y = y + s2;
		else x = x + s1;

		e = e + ((int)dy<<1);
	}
}

/////////////////////////////////////////////