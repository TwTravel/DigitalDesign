The HPS code works with 'A better chopped down system' on this page:
http://people.ece.cornell.edu/land/courses/ece5760/DE1_SOC/HPS_peripherials/univ_pgm_computer.index.html