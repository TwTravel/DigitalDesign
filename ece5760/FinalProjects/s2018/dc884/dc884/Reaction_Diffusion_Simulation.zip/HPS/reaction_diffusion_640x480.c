///////////////////////////////////////
/// 640x480 version!
/// This code will segfault the original
/// DE1 computer
/// compile with
/// gcc mandelbrot_video_2.c -o mandel -mfpu=neon -ftree-vectorize -O2
/// -- no optimization yields 9100 mS execution time
/// -- opt -O1 yields 4800 mS execution time
/// -- opt -O2 yields 3500 mS execution time
/// -- opt -O3 yields 3400 mS execution time
/// -- adding 'f' to all floating literals (e.g. 1.3f) and opt -O2 yields 2640 mS execution time
///gcc mandelbrot_video_vector.c -o mandel -mfpu=neon -ftree-vectorize 
///               -O3 -mfloat-abi=hard -ffast-math 
/// -- yields 2544 mS execution time
/// change to fixed point 
/// gcc reaction_diffusion.c -o reac -Os
/// -- yields 1615 mS execution time
///////////////////////////////////////
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/ipc.h> 
#include <sys/shm.h> 
#include <sys/mman.h>
#include <sys/time.h> 
#include "address_map_arm_brl4.h"

/* function prototypes */
void VGA_text (int, int, char *);
void VGA_text_clear();
void VGA_box (int, int, int, int, short);
void VGA_line(int, int, int, int, short) ;
void VGA_disc (int, int, int, short);

// fixed pt
typedef signed int fix28 ;
//multiply two fixed 4:28
#define multfix28(a,b) ((fix28)(((( signed long long)(a))*(( signed long long)(b)))>>28)) 
//#define multfix28(a,b) ((fix28)((( ((short)((a)>>17)) * ((short)((b)>>17)) )))) 
#define float2fix28(a) ((fix28)((a)*268435456.0f)) // 2^28
#define fix2float28(a) ((float)(a)/268435456.0f) 
#define int2fix28(a) ((a)<<28);
// the fixed point value 4
#define FOURfix28 0x40000000 
#define SIXTEENTHfix28 0x01000000
#define ONEfix28 0x10000000

// laplace transform
#define laplace(n,x,y) (n[x][y]*(-1) + n[x-1][y]*(0.2) + n[x+1][y]*(0.2) + n[x][y-1]*(0.2) + n[x][y+1]*(0.2) + n[x+1][y+1]*(0.05) + n[x+1][y-1]*(0.05) + n[x-1][y+1]*(0.05) + n[x-1][y-1]*(0.05))



// the light weight buss base
void *h2p_lw_virtual_base;

// pixel buffer
volatile unsigned int * vga_pixel_ptr = NULL ;
void *vga_pixel_virtual_base;

// character buffer
volatile unsigned int * vga_char_ptr = NULL ;
void *vga_char_virtual_base;

// /dev/mem file id
int fd;

// shared memory 
key_t mem_key=0xf0;
int shared_mem_id; 
int *shared_ptr;
int shared_time;
int shared_note;
char shared_str[64];

// pixel macro
#define VGA_PIXEL(x,y,color) do{\
	char  *pixel_ptr ;\
	pixel_ptr = (char *)vga_pixel_ptr + ((y)<<10) + (x) ;\
	*(char *)pixel_ptr = (color);\
} while(0)
	
// iteration max
//#define max_count 1000

// mandelbrot arrays
/*fix28 Zre, Zim, Cre, Cim, Zre_temp, Zim_temp;
fix28 Zre_sq, Zim_sq ;
fix28 x[640], y[480];
int i, j, count, total_count;*/

// wrap a struct for particles
struct mxnmat {
	float **matrix;
	int row;
	int col;
};

// functions for matrix
struct mxnmat initMatrix(int row, int col, int num);
void fillMatrix_Sqr(struct mxnmat mat,int x,int y,int length);
void fillMatrix_Cir(struct mxnmat mat,int x,int y, int radius);
void swapMatrix(struct mxnmat matA, struct mxnmat matB);
void freeMatrix(struct mxnmat mat);

// laplace transform
//fix28 calLaplace(struct mxnmat mat, int x, int y);

// reaction arrays
float dA, dB, f, k, dt;
float a, b;
//fix28 A[640][480], B[640][480];
//fix28 A_nxt[640][480], B_nxt[480][640];
struct mxnmat A,B,A_nxt,B_nxt;
int row = 640;
int col = 480;
int i, j;
int pix_r, pix_g, pix_b;

// measure time
struct timeval t1, t2, tf;
double elapsedTime, frameTime;
	
int main(void)
{
	//int x1, y1, x2, y2;

	// Declare volatile pointers to I/O registers (volatile 	// means that IO load and store instructions will be used 	// to access these pointer locations, 
	// instead of regular memory loads and stores) 

	// === shared memory =======================
	// with video process
	shared_mem_id = shmget(mem_key, 100, IPC_CREAT | 0666);
 	//shared_mem_id = shmget(mem_key, 100, 0666);
	shared_ptr = shmat(shared_mem_id, NULL, 0);

  	
	// === need to mmap: =======================
	// FPGA_CHAR_BASE
	// FPGA_ONCHIP_BASE      
	// HW_REGS_BASE        
  
	// === get FPGA addresses ==================
    // Open /dev/mem
	if( ( fd = open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) 	{
		printf( "ERROR: could not open \"/dev/mem\"...\n" );
		return( 1 );
	}
    
    // get virtual addr that maps to physical
	h2p_lw_virtual_base = mmap( NULL, HW_REGS_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, HW_REGS_BASE );	
	if( h2p_lw_virtual_base == MAP_FAILED ) {
		printf( "ERROR: mmap1() failed...\n" );
		close( fd );
		return(1);
	}
    

	// === get VGA char addr =====================
	// get virtual addr that maps to physical
	vga_char_virtual_base = mmap( NULL, FPGA_CHAR_SPAN, ( 	PROT_READ | PROT_WRITE ), MAP_SHARED, fd, FPGA_CHAR_BASE );	
	if( vga_char_virtual_base == MAP_FAILED ) {
		printf( "ERROR: mmap2() failed...\n" );
		close( fd );
		return(1);
	}
    
    // Get the address that maps to the FPGA LED control 
	vga_char_ptr =(unsigned int *)(vga_char_virtual_base);

	// === get VGA pixel addr ====================
	// get virtual addr that maps to physical
	vga_pixel_virtual_base = mmap( NULL, FPGA_ONCHIP_SPAN, ( 	PROT_READ | PROT_WRITE ), MAP_SHARED, fd, 			FPGA_ONCHIP_BASE);	
	if( vga_pixel_virtual_base == MAP_FAILED ) {
		printf( "ERROR: mmap3() failed...\n" );
		close( fd );
		return(1);
	}
    
    // Get the address that maps to the FPGA pixel buffer
	vga_pixel_ptr =(unsigned int *)(vga_pixel_virtual_base);

	// ===========================================

	/* create a message to be displayed on the VGA 
          and LCD displays */
	char text_top_row[40] = "Cornell ECE5760\0";
	char text_bottom_row[40] = "Reaction Diffusion\0";
	char num_string[20], time_string[20] ;

	//VGA_text (34, 1, text_top_row);
	//VGA_text (34, 2, text_bottom_row);
	// clear the screen
	VGA_box (0, 0, 639, 479, 0x00);
	// clear the text
	VGA_text_clear();

	/*
	// fill a with ones and b with zeros
	for (i=0; i<640; i++) {
		for (j=0; j<480; j++) {
			a[i][j] = float2fix28(1.0f) ;
			b[i][j] = float2fix28(0.0f) ;
			a_nxt[i][j] = float2fix28(1.0f) ;
			b_nxt[i][j] = float2fix28(0.0f) ;
			//printf("%f\n", x[i]);
			//printf("%f\n", y[j]);
		}
		
	}
	
	// fill b to arrays
	for (i=100; i<200; i++) {
		for (j=100; j<300; j++) {
			b[i][j] = float2fix28(1.0f) ;
			b_nxt[i][j] = float2fix28(1.0f) ;
		}
		
	}
	*/
	A = initMatrix(row,col,1);
	B = initMatrix(row,col,0);
	A_nxt = initMatrix(row,col,1);
	B_nxt = initMatrix(row,col,0);
	
	//fillMatrix_Sqr(B,150,200,100);
	//fillMatrix_Sqr(B_nxt,150,200,100);

  fillMatrix_Cir(B,320,240,100);
  fillMatrix_Cir(B_nxt,320,240,100);
  
  //printf("%f\n",B.matrix[0][0]);
  //printf("%f\n",B.matrix[150][200]);
  
	// fixed parameters
	dA   = 1.0;  
	dB   = 0.5;
	f    = 0.055;
	k    = 0.062;
	dt   = 1.0;


	// start timer
    gettimeofday(&t1, NULL);
	
  //clear the screen
	VGA_box (0, 0, 639, 479, 0x00);
  int m = 0;
	while(1)//(m<1000) 
	{
    m++;
    
    // for frame rate
		gettimeofday(&tf, NULL);
		
		for (i=1; i<639; i++) {
			for (j=1; j<479; j++) {
				/*a = A[i][j];
				b = B[i][j];
				A_nxt[i][j] = a + ( multfix28(dA,laplace(A,i,j)) - multfix28(a,multfix28(b,b))
							  + multfix28(f,(float2fix28(1.0f)-a)) );
            	B_nxt[i][j] = b + ( multfix28(dB,laplace(B,i,j)) + multfix28(a,multfix28(b,b))
            				  - multfix28((k+f),b) );
  				*/
  			a = A.matrix[i][j];
				b = B.matrix[i][j];

				A_nxt.matrix[i][j] = a + ( dA*laplace(A.matrix,i,j) - a*b*b + f*(1.0-a)) * dt ;
   	    B_nxt.matrix[i][j] = b + ( dB*laplace(B.matrix,i,j) + a*b*b - (k+f)*b  ) * dt ;
  				
        
				// display updated patterns
				pix_r = (7-(int)(A_nxt.matrix[i][j]*7))<<5;
				pix_g = (int)(B_nxt.matrix[i][j]*7)<<2;
				pix_b = 0;

        //printf("%d\n",pix_b);
        
				VGA_PIXEL(i,j,pix_r + pix_g + pix_b);

			}
		}

    float **tempA = A_nxt.matrix;
	  A_nxt.matrix = A.matrix;
	  A.matrix = tempA;
    float **tempB = B_nxt.matrix;
	  B_nxt.matrix = B.matrix;
	  B.matrix = tempB;
     
    //swapMatrix(A,A_nxt);
		//swapMatrix(B,B_nxt);
    
    //printf("%f\n",B.matrix[150][200]);

		
    // clear the text
		VGA_text_clear();

		VGA_text (10, 1, text_top_row);
    VGA_text (10, 2, text_bottom_row);

		// stop timer
		gettimeofday(&t2, NULL);
		elapsedTime = (t2.tv_sec - t1.tv_sec) * 1000.0;      // sec to ms
		elapsedTime += (t2.tv_usec - t1.tv_usec) / 1000.0;   // us to ms
		frameTime = (t2.tv_sec - tf.tv_sec) * 1000.0;      // sec to ms
		frameTime += (t2.tv_usec - tf.tv_usec) / 1000.0;   // us to ms

    sprintf(num_string, "FPS = %d Frame/Sec", (int)(1000.0/frameTime));
		sprintf(time_string, "T   = %.0f Sec  ", elapsedTime/1000.0);
		VGA_text (10, 3, num_string);
		VGA_text (10, 4, time_string);
		
	} // end while(1)
} // end main

/* Initialize a matrix size of mxn filled up with num*/
struct mxnmat initMatrix(int row, int col, int num){
	int i,j;
	struct mxnmat mat;

	mat.row = row;
	mat.col = col;

	mat.matrix = (float **)malloc(sizeof(fix28*)*mat.row);
	for(i=0;i<mat.row;i++){
		mat.matrix[i] = (float *)malloc(sizeof(fix28*)*mat.col);
	}

	for(i=0;i<mat.row;i++){
		for(j=0;j<mat.col;j++){
			mat.matrix[i][j] = num;
		}
	}

	return mat;
}

void fillMatrix_Sqr(struct mxnmat mat,int x,int y,int length){
	int i,j;
  for(i=(x-length/2);i<(x+length/2);i++){
		for(j=(y-length/2);j<(y+length/2);j++){
			mat.matrix[i][j] = 1;
		}
	}
}
void fillMatrix_Cir(struct mxnmat mat,int x,int y, int radius){
	int i,j;
  for(i=(x-radius);i<(x+radius);i++){
		for(j=(y-radius);j<(y+radius);j++){
			if(pow((i-x),2)+pow((j-y),2) < pow(radius,2)){
				mat.matrix[i][j] = 1;
			}
		}
	}
}


void swapMatrix(struct mxnmat matA, struct mxnmat matB){
	float **temp = matA.matrix;
	matA.matrix = matB.matrix;
	matB.matrix = temp;
}

/* free memory */
void freeMatrix(struct mxnmat mat){
	int i;
	
	for(i=0;i<mat.row;i++){
		free(mat.matrix[i]);
	}	
	free(mat.matrix);
}

/*
// laplace transform
fix28 calLaplace(struct mxnmat mat, int x, int y){
  fix28 sum = float2fix28(0.0f);
  
  int i,j;
  for(i=x-1;i<=x+1;i++){
    for(j=y-1;j<=y+1;j++){
      if(abs(i-x)==0&&abs(j-y)==0){sum = sum + multfix28(mat.matrix[i][j],float2fix28(-1.0f));}
      else if(abs(i-x)==0&&abs(j-y)==1){sum = sum + multfix28(mat.matrix[i][j],float2fix28(0.2f));}
      else if(abs(i-x)==1&&abs(j-y)==0){sum = sum + multfix28(mat.matrix[i][j],float2fix28(0.2f));}
      else{sum = sum + multfix28(mat.matrix[i][j],float2fix28(0.05f));}
      //else(abs(i-x)==1&&abs(j-y)==1){sum = sum + multfix28(mat.matrix[i][j],float2fix28(0.05f));}
    }
  }
  
  
  return sum;
}
*/

/****************************************************************************************
 * Subroutine to send a string of text to the VGA monitor 
****************************************************************************************/
void VGA_text(int x, int y, char * text_ptr)
{
  	volatile char * character_buffer = (char *) vga_char_ptr ;	// VGA character buffer
	int offset;
	/* assume that the text string fits on one line */
	offset = (y << 7) + x;
	while ( *(text_ptr) )
	{
		// write to the character buffer
		*(character_buffer + offset) = *(text_ptr);	
		++text_ptr;
		++offset;
	}
}

/****************************************************************************************
 * Subroutine to clear text to the VGA monitor 
****************************************************************************************/
void VGA_text_clear()
{
  	volatile char * character_buffer = (char *) vga_char_ptr ;	// VGA character buffer
	int offset, x, y;
	for (x=0; x<79; x++){
		for (y=0; y<59; y++){
	/* assume that the text string fits on one line */
			offset = (y << 7) + x;
			// write to the character buffer
			*(character_buffer + offset) = ' ';		
		}
	}
}

/****************************************************************************************
 * Draw a filled rectangle on the VGA monitor 
****************************************************************************************/
#define SWAP(X,Y) do{int temp=X; X=Y; Y=temp;}while(0) 

void VGA_box(int x1, int y1, int x2, int y2, short pixel_color)
{
	char  *pixel_ptr ; 
	int row, col;

	/* check and fix box coordinates to be valid */
	if (x1>639) x1 = 639;
	if (y1>479) y1 = 479;
	if (x2>639) x2 = 639;
	if (y2>479) y2 = 479;
	if (x1<0) x1 = 0;
	if (y1<0) y1 = 0;
	if (x2<0) x2 = 0;
	if (y2<0) y2 = 0;
	if (x1>x2) SWAP(x1,x2);
	if (y1>y2) SWAP(y1,y2);
	for (row = y1; row <= y2; row++)
		for (col = x1; col <= x2; ++col)
		{
			//640x480
			pixel_ptr = (char *)vga_pixel_ptr + (row<<10)    + col ;
			// set pixel color
			*(char *)pixel_ptr = pixel_color;		
		}
}

/****************************************************************************************
 * Draw a filled circle on the VGA monitor 
****************************************************************************************/

void VGA_disc(int x, int y, int r, short pixel_color)
{
	char  *pixel_ptr ; 
	int row, col, rsqr, xc, yc;
	
	rsqr = r*r;
	
	for (yc = -r; yc <= r; yc++)
		for (xc = -r; xc <= r; xc++)
		{
			col = xc;
			row = yc;
			// add the r to make the edge smoother
			if(col*col+row*row <= rsqr+r){
				col += x; // add the center point
				row += y; // add the center point
				//check for valid 640x480
				if (col>639) col = 639;
				if (row>479) row = 479;
				if (col<0) col = 0;
				if (row<0) row = 0;
				pixel_ptr = (char *)vga_pixel_ptr + (row<<10) + col ;
				// set pixel color
				*(char *)pixel_ptr = pixel_color;
			}
					
		}
}

// =============================================
// === Draw a line
// =============================================
//plot a line 
//at x1,y1 to x2,y2 with color 
//Code is from David Rodgers,
//"Procedural Elements of Computer Graphics",1985
void VGA_line(int x1, int y1, int x2, int y2, short c) {
	int e;
	signed int dx,dy,j, temp;
	signed int s1,s2, xchange;
     signed int x,y;
	char *pixel_ptr ;
	
	/* check and fix line coordinates to be valid */
	if (x1>639) x1 = 639;
	if (y1>479) y1 = 479;
	if (x2>639) x2 = 639;
	if (y2>479) y2 = 479;
	if (x1<0) x1 = 0;
	if (y1<0) y1 = 0;
	if (x2<0) x2 = 0;
	if (y2<0) y2 = 0;
        
	x = x1;
	y = y1;
	
	//take absolute value
	if (x2 < x1) {
		dx = x1 - x2;
		s1 = -1;
	}

	else if (x2 == x1) {
		dx = 0;
		s1 = 0;
	}

	else {
		dx = x2 - x1;
		s1 = 1;
	}

	if (y2 < y1) {
		dy = y1 - y2;
		s2 = -1;
	}

	else if (y2 == y1) {
		dy = 0;
		s2 = 0;
	}

	else {
		dy = y2 - y1;
		s2 = 1;
	}

	xchange = 0;   

	if (dy>dx) {
		temp = dx;
		dx = dy;
		dy = temp;
		xchange = 1;
	} 

	e = ((int)dy<<1) - dx;  
	 
	for (j=0; j<=dx; j++) {
		//video_pt(x,y,c); //640x480
		pixel_ptr = (char *)vga_pixel_ptr + (y<<10)+ x; 
		// set pixel color
		*(char *)pixel_ptr = c;	
		 
		if (e>=0) {
			if (xchange==1) x = x + s1;
			else y = y + s2;
			e = e - ((int)dx<<1);
		}

		if (xchange==1) y = y + s2;
		else x = x + s1;

		e = e + ((int)dy<<1);
	}
}

