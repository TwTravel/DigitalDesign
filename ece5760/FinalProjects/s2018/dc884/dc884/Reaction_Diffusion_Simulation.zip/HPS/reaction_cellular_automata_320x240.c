///////////////////////////////////////
/// FPS: 10-13 Frame/Second
/// Require around 50 Seconds  to reach a steady state 
/// gcc reaction_cellular_automata_320x240.c -o reac -Os
///////////////////////////////////////
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/ipc.h> 
#include <sys/shm.h> 
#include <sys/mman.h>
#include <sys/time.h> 
#include "address_map_arm_brl4.h"

/* function prototypes */
void VGA_text (int, int, char *);
void VGA_text_clear();
void VGA_box (int, int, int, int, short);
void VGA_line(int, int, int, int, short) ;
void VGA_disc (int, int, int, short);

// fixed pt
typedef signed int fix28 ;
//multiply two fixed 4:28
#define multfix28(a,b) ((fix28)(((( signed long long)(a))*(( signed long long)(b)))>>28)) 
//#define multfix28(a,b) ((fix28)((( ((short)((a)>>17)) * ((short)((b)>>17)) )))) 
#define float2fix28(a) ((fix28)((a)*268435456.0f)) // 2^28
#define fix2float28(a) ((float)(a)/268435456.0f) 
#define int2fix28(a) ((a)<<28);
// the fixed point value 4
#define FOURfix28 0x40000000 
#define SIXTEENTHfix28 0x01000000
#define ONEfix28 0x10000000


// the light weight buss base
void *h2p_lw_virtual_base;

// pixel buffer
volatile unsigned int * vga_pixel_ptr = NULL ;
void *vga_pixel_virtual_base;

// character buffer
volatile unsigned int * vga_char_ptr = NULL ;
void *vga_char_virtual_base;

// /dev/mem file id
int fd;

// shared memory 
key_t mem_key=0xf0;
int shared_mem_id; 
int *shared_ptr;
int shared_time;
int shared_note;
char shared_str[64];

// pixel macro
#define VGA_PIXEL(x,y,color) do{\
	char  *pixel_ptr ;\
	pixel_ptr = (char *)vga_pixel_ptr + ((y)<<10) + (x) ;\
	*(char *)pixel_ptr = (color);\
} while(0)
	
// iteration max
//#define max_count 1000

// mandelbrot arrays
/*fix28 Zre, Zim, Cre, Cim, Zre_temp, Zim_temp;
fix28 Zre_sq, Zim_sq ;
fix28 x[640], y[480];
int i, j, count, total_count;*/

// wrap a struct for particles
struct mxnmat {
	int **matrix;
	int row;
	int col;
};

struct abs {
	int a;
	int b;
	int s;
};

// functions for matrix
struct mxnmat initMatrix(int row, int col, int num);
struct mxnmat initRandom(int row, int col);
struct mxnmat copyMatrix(struct mxnmat mato);
void fillMatrix_Rdm(struct mxnmat mat,int x,int y,int length);
void fillMatrix_Sqr(struct mxnmat mat,int x,int y,int length);
void fillMatrix_Cir(struct mxnmat mat,int x,int y, int radius);
void swapMatrix(struct mxnmat matA, struct mxnmat matB);
void freeMatrix(struct mxnmat mat);


// function getting param a,b,s
struct abs getABS(struct mxnmat mat, int x, int y);

// params
int q,g,k1,k2;
struct mxnmat A,A_nxt;
struct abs X;
int row = 320;
int col = 240;
int i, j;
int pix_r, pix_g, pix_b;

// measure time
struct timeval t1, t2, tf;
double elapsedTime, frameTime;
	
int main(void)
{
	//int x1, y1, x2, y2;

	// Declare volatile pointers to I/O registers (volatile 	// means that IO load and store instructions will be used 	// to access these pointer locations, 
	// instead of regular memory loads and stores) 

	// === shared memory =======================
	// with video process
	shared_mem_id = shmget(mem_key, 100, IPC_CREAT | 0666);
 	//shared_mem_id = shmget(mem_key, 100, 0666);
	shared_ptr = shmat(shared_mem_id, NULL, 0);

  	
	// === need to mmap: =======================
	// FPGA_CHAR_BASE
	// FPGA_ONCHIP_BASE      
	// HW_REGS_BASE        
  
	// === get FPGA addresses ==================
    // Open /dev/mem
	if( ( fd = open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) 	{
		printf( "ERROR: could not open \"/dev/mem\"...\n" );
		return( 1 );
	}
    
    // get virtual addr that maps to physical
	h2p_lw_virtual_base = mmap( NULL, HW_REGS_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, HW_REGS_BASE );	
	if( h2p_lw_virtual_base == MAP_FAILED ) {
		printf( "ERROR: mmap1() failed...\n" );
		close( fd );
		return(1);
	}
    

	// === get VGA char addr =====================
	// get virtual addr that maps to physical
	vga_char_virtual_base = mmap( NULL, FPGA_CHAR_SPAN, ( 	PROT_READ | PROT_WRITE ), MAP_SHARED, fd, FPGA_CHAR_BASE );	
	if( vga_char_virtual_base == MAP_FAILED ) {
		printf( "ERROR: mmap2() failed...\n" );
		close( fd );
		return(1);
	}
    
    // Get the address that maps to the FPGA LED control 
	vga_char_ptr =(unsigned int *)(vga_char_virtual_base);

	// === get VGA pixel addr ====================
	// get virtual addr that maps to physical
	vga_pixel_virtual_base = mmap( NULL, FPGA_ONCHIP_SPAN, ( 	PROT_READ | PROT_WRITE ), MAP_SHARED, fd, 			FPGA_ONCHIP_BASE);	
	if( vga_pixel_virtual_base == MAP_FAILED ) {
		printf( "ERROR: mmap3() failed...\n" );
		close( fd );
		return(1);
	}
    
    // Get the address that maps to the FPGA pixel buffer
	vga_pixel_ptr =(unsigned int *)(vga_pixel_virtual_base);

	// ===========================================

	/* create a message to be displayed on the VGA 
          and LCD displays */
	char text_top_row[40] = "Cornell ECE5760\0";
	char text_bottom_row[40] = "Reaction Diffusion\0";
	char num_string[20], time_string[20] ;

	//VGA_text (34, 1, text_top_row);
	//VGA_text (34, 2, text_bottom_row);
	// clear the screen
	VGA_box (0, 0, 639, 479, 0x00);
	// clear the text
	VGA_text_clear();

	//A = initMatrix(row,col,0);
  A = initRandom(row,col);
	A_nxt = copyMatrix(A);
  //A_nxt = initMatrix(row,col,10);
	
  	//fillMatrix_Cir(A,320,240,100);
  	//fillMatrix_Cir(A_nxt,320,240,100);
  
  
	// fixed parameters
	q = 100;
	g = 35;
	k1 = 3;
	k2 = 2;

	// start timer
    gettimeofday(&t1, NULL);
	
  //clear the screen
	VGA_box (0, 0, 639, 479, 0x00);
  	int m = 0;
	while(1)//(m<1) 
	{
    m++;
    
    	// for frame rate
		gettimeofday(&tf, NULL);
		
    //printf("(310,230) = %d\n",A_nxt.matrix[310][230]);
   
		for (i=1; i<row-2; i++) {
			for (j=1; j<col-2; j++) {
				X = getABS(A,i,j);  				
        		int cell = A.matrix[i][j];
        		if(cell==0){
        			A_nxt.matrix[i][j] = X.a/k1 + X.b/k2;
        		}
        		else if(cell==q){
        			A_nxt.matrix[i][j] = 0;
        		}
        		else{
        			if(X.s/(X.a+X.b+1) + g<q){
                A_nxt.matrix[i][j] = X.s/(X.a+X.b+1) + g;
              }
              else {
                A_nxt.matrix[i][j] = q;                
              }
        		}
				// display updated patterns
				VGA_PIXEL(i*2,j*2,A_nxt.matrix[i][j]+4);
        VGA_PIXEL(i*2+1,j*2,A_nxt.matrix[i][j]+4);
        VGA_PIXEL(i*2,j*2+1,A_nxt.matrix[i][j]+4);
        VGA_PIXEL(i*2+1,j*2+1,A_nxt.matrix[i][j]+4);
        
        //+A_nxt.matrix[i][j]%2);
				//pix_r = (7-(int)(A_nxt.matrix[i][j]*7))<<5;
				//pix_g = (int)(A_nxt.matrix[i][j]*7)<<2;
				//pix_b = 0;
				//VGA_PIXEL(i,j,pix_r + pix_g + pix_b);

			}
		}

		int **tempA = A_nxt.matrix;
	  	A_nxt.matrix = A.matrix;
	  	A.matrix = tempA;

		
    	// clear the text
		VGA_text_clear();

		VGA_text (10, 1, text_top_row);
    	VGA_text (10, 2, text_bottom_row);

		// stop timer
		gettimeofday(&t2, NULL);
		elapsedTime = (t2.tv_sec - t1.tv_sec) * 1000.0;      // sec to ms
		elapsedTime += (t2.tv_usec - t1.tv_usec) / 1000.0;   // us to ms
		frameTime = (t2.tv_sec - tf.tv_sec) * 1000.0;      // sec to ms
		frameTime += (t2.tv_usec - tf.tv_usec) / 1000.0;   // us to ms

    sprintf(num_string, "FPS = %d Frame/Sec", (int)(1000.0/frameTime));
		sprintf(time_string, "T   = %.0f Sec  ", elapsedTime/1000.0);
		VGA_text (10, 3, num_string);
		VGA_text (10, 4, time_string);
		
	} // end while(1)
} // end main

/* Initialize a matrix size of mxn filled up with num*/
struct mxnmat initMatrix(int row, int col, int num){
	int i,j;
	struct mxnmat mat;

	mat.row = row;
	mat.col = col;

	mat.matrix = (int **)malloc(sizeof(int*)*mat.row);
	for(i=0;i<mat.row;i++){
		mat.matrix[i] = (int *)malloc(sizeof(int*)*mat.col);
	}

	for(i=0;i<mat.row;i++){
		for(j=0;j<mat.col;j++){
			mat.matrix[i][j] = num;
		}
	}

	return mat;
}

/* Initialize a matrix size of mxn filled up with num*/
struct mxnmat initRandom(int row, int col){
	int i,j;
	struct mxnmat mat;

	mat.row = row;
	mat.col = col;

	mat.matrix = (int **)malloc(sizeof(int*)*mat.row);
	for(i=0;i<mat.row;i++){
		mat.matrix[i] = (int *)malloc(sizeof(int*)*mat.col);
	}

  srand(8);
	for(i=0;i<mat.row;i++){
		for(j=0;j<mat.col;j++){
			mat.matrix[i][j] = (int)(rand()%32);
		}
	}

	return mat;
}

struct mxnmat copyMatrix(struct mxnmat mato){
	int i,j;
	struct mxnmat mat;

	mat.row = mato.row;
	mat.col = mato.col;

	mat.matrix = (int **)malloc(sizeof(int*)*mat.row);
	for(i=0;i<mat.row;i++){
		mat.matrix[i] = (int *)malloc(sizeof(int*)*mat.col);
	}

	for(i=0;i<mat.row;i++){
		for(j=0;j<mat.col;j++){
			mat.matrix[i][j] = mato.matrix[i][j];
		}
	}

  return mat;
}

void fillMatrix_Rdm(struct mxnmat mat,int x,int y,int length){
	int i,j;
  for(i=(x-length/2);i<(x+length/2);i++){
		for(j=(y-length/2);j<(y+length/2);j++){
			mat.matrix[i][j] = (int)(rand()%32);
		}
	}
}

void fillMatrix_Sqr(struct mxnmat mat,int x,int y,int length){
	int i,j;
  for(i=(x-length/2);i<(x+length/2);i++){
		for(j=(y-length/2);j<(y+length/2);j++){
			mat.matrix[i][j] = q;
		}
	}
}
void fillMatrix_Cir(struct mxnmat mat,int x,int y, int radius){
	int i,j;
  for(i=(x-radius);i<(x+radius);i++){
		for(j=(y-radius);j<(y+radius);j++){
			if(pow((i-x),2)+pow((j-y),2) < pow(radius,2)){
				mat.matrix[i][j] = q;
			}
		}
	}
}


void swapMatrix(struct mxnmat matA, struct mxnmat matB){
	int **temp = matA.matrix;
	matA.matrix = matB.matrix;
	matB.matrix = temp;
}

/* free memory */
void freeMatrix(struct mxnmat mat){
	int i;
	
	for(i=0;i<mat.row;i++){
		free(mat.matrix[i]);
	}	
	free(mat.matrix);
}


// get params of a,b,s
struct abs getABS(struct mxnmat mat, int x, int y){
  int x_nxt,y_nxt;
  struct abs X;
  X.a = 0;
  X.b = 0;
  X.s = mat.matrix[x][y];
  int i,j;
  int offset[3] = {-1,0,1};
  for(i=0;i<3;i++){
    for(j=0;j<3;j++){
      x_nxt = x + offset[i];
    	y_nxt = y + offset[j];
      if(x_nxt==0&&y_nxt==0){
        continue;
      }
      if(mat.matrix[x_nxt][y_nxt]>0&&mat.matrix[x_nxt][y_nxt]<q){
    		X.a = X.a + 1;
    	}
		if(mat.matrix[x_nxt][y_nxt]==q){
			X.b = X.b + 1;
    	}
    	X.s = X.s + mat.matrix[x_nxt][y_nxt];
    }
  }
  return X;
}


/****************************************************************************************
 * Subroutine to send a string of text to the VGA monitor 
****************************************************************************************/
void VGA_text(int x, int y, char * text_ptr)
{
  	volatile char * character_buffer = (char *) vga_char_ptr ;	// VGA character buffer
	int offset;
	/* assume that the text string fits on one line */
	offset = (y << 7) + x;
	while ( *(text_ptr) )
	{
		// write to the character buffer
		*(character_buffer + offset) = *(text_ptr);	
		++text_ptr;
		++offset;
	}
}

/****************************************************************************************
 * Subroutine to clear text to the VGA monitor 
****************************************************************************************/
void VGA_text_clear()
{
  	volatile char * character_buffer = (char *) vga_char_ptr ;	// VGA character buffer
	int offset, x, y;
	for (x=0; x<79; x++){
		for (y=0; y<59; y++){
	/* assume that the text string fits on one line */
			offset = (y << 7) + x;
			// write to the character buffer
			*(character_buffer + offset) = ' ';		
		}
	}
}

/****************************************************************************************
 * Draw a filled rectangle on the VGA monitor 
****************************************************************************************/
#define SWAP(X,Y) do{int temp=X; X=Y; Y=temp;}while(0) 

void VGA_box(int x1, int y1, int x2, int y2, short pixel_color)
{
	char  *pixel_ptr ; 
	int row, col;

	/* check and fix box coordinates to be valid */
	if (x1>639) x1 = 639;
	if (y1>479) y1 = 479;
	if (x2>639) x2 = 639;
	if (y2>479) y2 = 479;
	if (x1<0) x1 = 0;
	if (y1<0) y1 = 0;
	if (x2<0) x2 = 0;
	if (y2<0) y2 = 0;
	if (x1>x2) SWAP(x1,x2);
	if (y1>y2) SWAP(y1,y2);
	for (row = y1; row <= y2; row++)
		for (col = x1; col <= x2; ++col)
		{
			//640x480
			pixel_ptr = (char *)vga_pixel_ptr + (row<<10)    + col ;
			// set pixel color
			*(char *)pixel_ptr = pixel_color;		
		}
}

/****************************************************************************************
 * Draw a filled circle on the VGA monitor 
****************************************************************************************/

void VGA_disc(int x, int y, int r, short pixel_color)
{
	char  *pixel_ptr ; 
	int row, col, rsqr, xc, yc;
	
	rsqr = r*r;
	
	for (yc = -r; yc <= r; yc++)
		for (xc = -r; xc <= r; xc++)
		{
			col = xc;
			row = yc;
			// add the r to make the edge smoother
			if(col*col+row*row <= rsqr+r){
				col += x; // add the center point
				row += y; // add the center point
				//check for valid 640x480
				if (col>639) col = 639;
				if (row>479) row = 479;
				if (col<0) col = 0;
				if (row<0) row = 0;
				pixel_ptr = (char *)vga_pixel_ptr + (row<<10) + col ;
				// set pixel color
				*(char *)pixel_ptr = pixel_color;
			}
					
		}
}

// =============================================
// === Draw a line
// =============================================
//plot a line 
//at x1,y1 to x2,y2 with color 
//Code is from David Rodgers,
//"Procedural Elements of Computer Graphics",1985
void VGA_line(int x1, int y1, int x2, int y2, short c) {
	int e;
	signed int dx,dy,j, temp;
	signed int s1,s2, xchange;
     signed int x,y;
	char *pixel_ptr ;
	
	/* check and fix line coordinates to be valid */
	if (x1>639) x1 = 639;
	if (y1>479) y1 = 479;
	if (x2>639) x2 = 639;
	if (y2>479) y2 = 479;
	if (x1<0) x1 = 0;
	if (y1<0) y1 = 0;
	if (x2<0) x2 = 0;
	if (y2<0) y2 = 0;
        
	x = x1;
	y = y1;
	
	//take absolute value
	if (x2 < x1) {
		dx = x1 - x2;
		s1 = -1;
	}

	else if (x2 == x1) {
		dx = 0;
		s1 = 0;
	}

	else {
		dx = x2 - x1;
		s1 = 1;
	}

	if (y2 < y1) {
		dy = y1 - y2;
		s2 = -1;
	}

	else if (y2 == y1) {
		dy = 0;
		s2 = 0;
	}

	else {
		dy = y2 - y1;
		s2 = 1;
	}

	xchange = 0;   

	if (dy>dx) {
		temp = dx;
		dx = dy;
		dy = temp;
		xchange = 1;
	} 

	e = ((int)dy<<1) - dx;  
	 
	for (j=0; j<=dx; j++) {
		//video_pt(x,y,c); //640x480
		pixel_ptr = (char *)vga_pixel_ptr + (y<<10)+ x; 
		// set pixel color
		*(char *)pixel_ptr = c;	
		 
		if (e>=0) {
			if (xchange==1) x = x + s1;
			else y = y + s2;
			e = e - ((int)dx<<1);
		}

		if (xchange==1) y = y + s2;
		else x = x + s1;

		e = e + ((int)dy<<1);
	}
}

