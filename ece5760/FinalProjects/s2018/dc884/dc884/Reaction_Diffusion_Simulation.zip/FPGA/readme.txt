Modelsim showed positive results.

The one-cycle delay of M10k memory was considered.
Read and write were pipelined the best I could.

Please read this part with the compliation screenshot:
Combinational logic requires optimization. Nearly no dsp usage was shown in that logic. Probably starting with shrinking the use of conditional statements.
5-bit data length was implemented. More bits can be implemented since there is still enough memory.


VGA Bus Master displayed incorrect figures at the time this note written.