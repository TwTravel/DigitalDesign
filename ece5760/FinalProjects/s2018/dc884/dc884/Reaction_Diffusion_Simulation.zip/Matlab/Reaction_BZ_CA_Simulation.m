% -------------------- ECE5760 Final Project ------------------------------
% -------------------- Reaction Diffusion Simulation ----------------------
% -------------------- Author: Delin Cao ----------------------------------
% -------------------- Date: 2018/04/25 -----------------------------------


clear all

% parameters
itr = 20000;
%resx = 480;
%resy = 640;
resx = 480;
resy = 640;
q = 200;
k1 = 2;
k2 = 2;
g = 1;


% create patricles
A = zeros(resx,resy);
A_nxt = A;

%A = randi([0 31],resx,resy);
%A_nxt = A;

% fill in particles
for y = 1:resy
    for x = 1:resx
        if (x-240)^2+(y-320)^2 ==10000
            A(x,y) = 31;
            A_nxt(x,y) = 31;
        end
    end
end


% loop for displaying the automata
figure
hold on
colormap(jet)
n = 0;
while (n < itr)
    
    n = n + 1;
    %disp(n);
    %disp(A(100,100));
    title(n);
    
    % get matrix after reaction
    for y = 2:(resy-1)
        for x = 2:(resx-1)
            cell = A(x,y);
            %a = getNumofInfected(A,x,y);
            %b = getNumofIll(A,x,y);
            %s = getNumofSum(A,x,y);
            X = getNumofabs(A,x,y);
            a = X(1);
            b = X(2);
            s = X(3);
            if cell == 0
                %A_nxt(x,y) = bitshift(a,-1)+bitshift(b,-1) + 0;
                
                if a == 0 && b ==0
                    A_nxt(x,y) = 0;
                else
                    A_nxt(x,y) = bitshift(a+4,-1)+bitshift(b+4,-1) + 0;
                end
                %A_nxt(x,y) = round(a/2)+round(b/2);
                %disp(a);
                %disp(bitshift(a,-k1));
            elseif cell == 31
                A_nxt(x,y) = 0;
            else
                if 31<bitshift(s,-round(sqrt(a+b+1)))+g
                %if 31<s/(a+b+1)+g
                    A_nxt(x,y) = 31;
                else
                    A_nxt(x,y) = bitshift(s,-round(sqrt(a+b+1)))+g;
                    %A_nxt(x,y) = s/(a+b+1)+g;
                end
            end
                   
        end
    end
    disp(A_nxt(240,320));
    % display colormap
    pause(0.001);
    imagesc(A_nxt);

    % update matrix A
    A_temp = A;
    A = A_nxt;
    A_nxt = A_temp;
end

hold off


function X = getNumofabs (A,x,y)
    X = [0 0 0];
    X(3) = A(x,y);
    for i = [-1,1]
        for j = [-1,1]
            if A(x+i,y+j)>0 && A(x+i,y+j)<31
                X(1) = X(1) + 1;
            elseif A(x+i,y+j)==31
                X(2) = X(2) + 1; 
            end
            X(3) = X(3) + A(x+i,y+j);
        end
    end
    end



function a = getNumofInfected (A,x,y)
    a = 0;
    for i = [-1,1]
        for j = [-1,1]
            % edit here
            if A(x+i,y+j)>0 && A(x+i,y+j)<100
                a = a + 1;
            end
        end
    end
end

function b = getNumofIll (A,x,y)
    b = 0;
    for i = [-1,1]
        for j = [-1,1]
            % edit here
            if A(x+i,y+j)==100
                b = b + 1;
            end
        end
    end
end

function s = getNumofSum (A,x,y)
    s = A(x,y);
    for i = [-1,1]
        for j = [-1,1]
            % edit here
                s = s + A(x+i,y+j);
        end
    end
end
