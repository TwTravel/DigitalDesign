% -------------------- ECE5760 Final Project ------------------------------
% -------------------- Reaction Diffusion Simulation ----------------------
% -------------------- Author: Delin Cao ----------------------------------
% -------------------- Date: 2018/04/25 -----------------------------------


clear all

% parameters
itr = 20000;
resx = 480;
resy = 640;
dA = 1.0;
dB = 0.5;
f = 0.08;%0.055;
k = 0.062;
%f = 0.070;
%k = 0.082;
dt = 1.0;


% create patricles
A = ones(resx,resy);
A_nxt = ones(resx,resy);
B = zeros(resx,resy);
B_nxt = zeros(resx,resy);
%A = randi([0 1.0], resx,resy);
%B = randi([0 1.0], resx,resy);
%A_nxt = A;
%B_nxt = B;

% fill in particles

%B(230:250,310:330) = 1;
%B_nxt(230:250,310:330) = 1;

%for y = 2:(resy-1)
%    for x = 2:(resx-1)
%        if (x-100)^2+(y-200)^2 <=2500
%            B(x,y) = 1;
%            B_nxt(x,y) = 1;
%        end
%    end
%end

for y = 2:(resy-1)
    for x = 2:(resx-1)
        if (x-240)^2+(y-320)^2 <=10000
            B(x,y) = 1;
            B_nxt(x,y) = 1;
        end
    end
end


% RGB color
C = zeros(resx,resy);
%C(:,:) = 0.8;

% loop for displaying the automata
figure
hold on
colormap(gray)

n = 0;
while (n < itr)
    
    n = n + 1;
    %disp(n);
    title(n);
    
    % get matrix after reaction
    for y = 3:(resy-2)
        for x = 3:(resx-2)
            a = A(x,y);
            b = B(x,y);
            A_nxt(x,y) = a + ( dA * laplace(A,x,y) - a*b*b + f*(1-a) ) * dt;
            B_nxt(x,y) = b + ( dB * laplace(B,x,y) + a*b*b - (k+f)*b ) * dt;
        end
    end
    
    rgbImage = cat(3, 1.0-A_nxt, B_nxt,C);
    %disp(B_nxt(400,400))
    %if(rem(n,20)==0)
        imshow(rgbImage);
    %end
    %pause(0.1);
    %disp(B(240));
    % update matrix A and B
    A_temp = A;
    B_temp = B;
    A = A_nxt;
    B = B_nxt;
    A_nxt = A_temp;
    B_nxt = B_temp;
end

hold off

% laplace function
function l = laplace(n,x,y)
    % done with a 3 x 3 matrix with weights
    l = n(x,y)*(-1) + n(x-1,y)*(0.2) + n(x+1,y)*(0.2) + n(x,y-1)*(0.2) + n(x,y+1)*(0.2) ...
        + n(x+1,y+1)*(0.05) + n(x+1,y-1)*(0.05) + n(x-1,y+1)*(0.05) + n(x-1,y-1)*(0.05) ;
end