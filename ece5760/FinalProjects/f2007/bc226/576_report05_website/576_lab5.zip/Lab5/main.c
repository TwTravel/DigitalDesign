/////////////////////////////////////////////////////////////////////////
// Simple MicroC/OS program.
/////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <math.h>
#include <sys/time.h>
#include <sys/types.h>
#include "includes.h"
#include "altera_avalon_pio_regs.h"

///// LCD control: //////////////////////////////////////////////////////
// From: http://www.altera.com/support/examples/nios2/exm-micro_mutex.html
// ESC ssequences:
// From: http://www.isthe.com/chongo/tech/comp/ansi_escapes.html
// ESC[#;#H      Moves the cursor to line #, column #
// ESC[2J        Clear screen and home cursor
// ESC[K         Clear to end of line
#define ESC_TOP_LEFT    "[1;0H"
#define ESC_BOTTOM_LEFT "[2;0H"
#define LCD_CLR "[2J"
#define LCD_CLR_LINE "[K"
static unsigned char esc = 0x1b; // Integer ASCII value of the ESC character

///// Define Task parameters //////////////////////////////////
#define   TASK_STACKSIZE       2048
OS_STK    task1_stk[TASK_STACKSIZE];

#define TASK1_PRIORITY      6

///// LCD define ///////////////////////////////////////////////
FILE * lcd_fd;

///// task 1 ///////////////////////////////////////////////////
// Controls DDS frequency, sends message and signals Task 3
void task1(void* pdata) {
  char wavetype[10], str[255], lpf[10];
  int freq, beta_out;
  float cutoff;
  char wavetype_char, lpf_char;

  freq = 25;
  cutoff = 0.25; // must be (0, 1)
  beta_out = (int)((1-2*cutoff)*pow(2, 16)) & 0x3ffff; // 2-bit signed complement with 1 bit exponent
  strcpy(wavetype, "Sine");
  wavetype_char = 0;
  strcpy(lpf, "off");
  lpf_char = 0;

  while (1) {
    // out0: frequency
    IOWR_ALTERA_AVALON_PIO_DATA(OUT0_BASE, freq);
    // out1: lpf_char + wavetype
    IOWR_ALTERA_AVALON_PIO_DATA(OUT1_BASE, wavetype_char | lpf_char << 4);
    // out2: cutoff
    IOWR_ALTERA_AVALON_PIO_DATA(OUT2_BASE, beta_out);


    fprintf(lcd_fd, "%c%s%s/LPF%s          \n",
            esc, ESC_TOP_LEFT, wavetype, lpf);
    fprintf(lcd_fd, "%c%s%dHz/%0.2f cut            \n",
            esc, ESC_BOTTOM_LEFT, freq, cutoff);

    str[0] = 0;
    printf("Enter command: ");
    scanf("%s", str);

    if ((strcasecmp(str, "help") == 0) |
        (strcasecmp(str, "h") == 0)) {
      printf("valid commands: (sine, square, triangle, noise), fc###, fr###, lpf[on], lpfoff\n");
    }
    else if ((strcasecmp(str, "sine") == 0) |
             (strcasecmp(str, "sin") == 0)) {
      strcpy(wavetype, "Sine");
      wavetype_char = 0;

      printf("Changing to sine waveform\n");
    }
    else if ((strcasecmp(str, "square") == 0) |
             (strcasecmp(str, "squ") == 0) |
             (strcasecmp(str, "sq") == 0)) {
      strcpy(wavetype, "Square");
      wavetype_char = 1;

      printf("Changing to square waveform\n");
    }
    else if ((strcasecmp(str, "triangle") == 0) |
             (strcasecmp(str, "tri") == 0)){
      strcpy(wavetype, "Triangle");
      wavetype_char = 2;

      printf("Changing to triangle waveform\n");
    }
    else if ((strcasecmp(str, "sawtooth") == 0) |
             (strcasecmp(str, "saw") == 0)) {
      strcpy(wavetype, "Sawtooth");
      wavetype_char = 4;

      printf("Changing to sawtooth waveform\n");
    }
    else if ((strcasecmp(str, "noise") == 0) |
             (strcasecmp(str, "n") == 0)) {
      strcpy(wavetype, "Noise");
      wavetype_char = 8;

      printf("Changing to noise waveform\n");
    }
    else if (strncasecmp(str, "fc", 2) == 0) {
      // cutoff frequency
      cutoff = atof(str+2);
      beta_out = (int)((1-2*cutoff)*pow(2, 16)) & 0x3ffff; // 2-bit signed complement with 1 bit exponent

      printf("Changing LPF beta to %0.4f (or 0x%8x)\n", cutoff, beta_out);
    }
    else if (strncasecmp(str, "fr", 2) == 0) {
      // wave freq
      freq = atoi(str+2);

      printf("Changing wave frequency to %dHz\n", freq);
    }
    else if (strcasecmp(str, "lpfoff") == 0) {
      // lpf off
      strcpy(lpf, "off");
      lpf_char = 0;

      printf("Turning lpf off\n");
    }
    else if ((strcasecmp(str, "lpf") == 0) |
             (strcasecmp(str, "lpfon") == 0)) {
      // lpf on
      strcpy(lpf, "on");
      lpf_char = 1;

      printf("Turning lpf on\n");
    }

    /*
    // read the toggle switches on the DE2
    sw = IORD_ALTERA_AVALON_PIO_DATA(IN0_BASE);
    // read the pushbuttons -- inverted because a pressed KEY is a zero
    key = 0xf & ~IORD_ALTERA_AVALON_PIO_DATA(IN1_8BIT_BASE);
    // write to the DDS controller
    //IOWR_ALTERA_AVALON_PIO_DATA(OUT0_BASE, 85899*sw/4000);
    IOWR_ALTERA_AVALON_PIO_DATA(OUT0_BASE, freq);
    */
  }
}

////// main ////////////////////////////////////////////////////
// The main function makes a queue and a semaphore,
//creates three tasks, and starts multi-tasking
int main(void) {
  // initialize the LCD
  lcd_fd = fopen(LCD_NAME, "w");
  if (lcd_fd == NULL) {
    printf("Unable to open lcd display\n");
  }
  else {
    printf("Opened the the lcd display\n");
  }

  //position cursor and print static text
  fprintf(lcd_fd, "%c%s%s\n", esc, ESC_TOP_LEFT, "ECE576\n");

  OSTaskCreateExt(task1,
                  NULL,
                  (void *)&task1_stk[TASK_STACKSIZE],
                  TASK1_PRIORITY,
                  TASK1_PRIORITY,
                  task1_stk,
                  TASK_STACKSIZE,
                  NULL,
                  0);

  OSStart();
  return 0;
}

//////////////////////////////////////////////////////////////////

