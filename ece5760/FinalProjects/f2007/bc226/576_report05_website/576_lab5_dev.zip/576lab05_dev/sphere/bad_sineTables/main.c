#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

int ftrans(float fnum) {
  // 2-bit signed complement with 1 bit exponent
  float fnormed;
  int retval;

  if (fnum < -2.0) return 0x20000;
  else if (fnum >= 2.0) return 0x1ffff;

  if (fnum < 0) fnormed = fnum + 2.0;
  else fnormed = fnum;

  retval = (int)(fnum*65536);
  if (fnum < 0)
    retval |= 0x2000;

  return retval & 0x3ffff;
}

float itrans(int inum) {
  // sign bit is at 0x20000, equiv to -2
  // 0x1_0000 is +1
  // 0x0_0000 is zero
  // 0x3_0000 is -1
  // 0x2_0000 is -2
  // 2^16 = 65536
  float fnum = ((inum & 0x1ffff)/(float)65536);
  if (0x20000 & inum) fnum -= 2.0;
  return fnum;
}

int main (int argc, char **argv) {
  int inum;
  float fnum;
  int i;
  int steps = 512;

  if (argc > 1) {
    sscanf(argv[1], "%d", &steps);
  }

  /*
  printf(" // 8x18-bit sine table with 2^8=%d steps\n", steps);
  for(i = 0; i < steps; i++) {
    fnum = sin(2*M_PI*i/(float)steps);
    inum = ftrans(fnum);
    printf("    8'h%02x: sine_out = 18'h%05x; // sine_out = %f\n", i, inum, fnum);
  }
  */

  printf(" // 9x16-bit sine table with 2^9=%d steps\n", steps);
  for(i = 0; i < steps; i++) {
    fnum = sin(2*M_PI*i/(float)steps);
    inum = ftrans(fnum);
    printf("    9'h%03x: sine_out = 16'h%04x; // addr = %d, sine_out = %f\n", i, inum >> 2, i, fnum);
  }

  printf(" // 9x16-bit cosine table with 2^9=%d steps\n", steps);
  for(i = 0; i < steps; i++) {
    fnum = cos(2*M_PI*i/(float)steps);
    inum = ftrans(fnum);
    printf("    9'h%03x: cosine_out = 16'h%04x; // addr = %d, cosine_out = %f\n", i, inum >> 2, i, fnum);
  }

  return 0;
}
