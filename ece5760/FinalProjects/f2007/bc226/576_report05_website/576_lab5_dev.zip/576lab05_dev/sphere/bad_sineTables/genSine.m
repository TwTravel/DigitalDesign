%generate a sine table for Verilog ROM 
x = 1:256;
% Sin : scale to 10-bits and offset 9-bits
y = fix(512 + 511*sin(2*pi*(x-1)/256)); 
for i=x
fprintf('\t\t\t8''h%02x: sine = 10''h%03x ; // sine = %f\n', x(i)-1, y(i), y(i));
end


%generate a sine table for Verilog ROM 
x = 1:256;
% Sin : scale to 16-bits and offset 15-bits
y = fix(32768 + 32767*sin(2*pi*(x-1)/256)); 
for i=x
fprintf('\t\t\t8''h%02x: sine = 16''h%04x ; // sine = %f\n', x(i)-1, y(i), y(i));
end

512 records?

%generate a sine table for Verilog ROM 
x = 1:512;
% Sin : scale to 16-bits and offset 15-bits
y = sin(2*pi*(x-1)/512);
y2 = fix(32768 + 32767*sin(2*pi*(x-1)/512));
for i=x
fprintf('\t\t\t9''h%03x: sine = 16''h%04x ; // sine = %f = %f\n', x(i)-1, y2(i), y(i), y2(i));
end

2^10 =  1024
2^9 = 512
2^16 = 65536
2^15 = 32768
2^14 = 16384
