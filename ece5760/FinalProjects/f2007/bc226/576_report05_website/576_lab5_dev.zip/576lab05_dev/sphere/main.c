#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int ftrans(float fnum) {
  // 2-bit signed complement with 1 bit exponent
  float fnormed;
  int retval;

  if (fnum < -2.0) return 0x20000;
  else if (fnum >= 2.0) return 0x1ffff;

  if (fnum < 0) fnormed = fnum + 2.0;
  else fnormed = fnum;

  retval = (int)(fnum*65536);
  if (fnum < 0)
    retval |= 0x20000;

  return retval & 0x3ffff;
}


int main (int argc, char** argv) {
  int theta = 0, phi = 0, i = 0, steps = 8;
  double **m_next, **m_init;

  double minorR = 1.00, majorR = 0.00;

  m_next = (double**)malloc(sizeof(double*)*3);
  m_init = (double**)malloc(sizeof(double*)*3);

  for (i = 0; i < 3; i++) {
    m_next[0] = (double*)malloc(sizeof(double)*(steps+1));
    m_next[1] = (double*)malloc(sizeof(double)*(steps+1));
    m_next[2] = (double*)malloc(sizeof(double)*(steps+1));
    m_init[0] = (double*)malloc(sizeof(double)*(steps+1));
    m_init[1] = (double*)malloc(sizeof(double)*(steps+1));
    m_init[2] = (double*)malloc(sizeof(double)*(steps+1));
  }


  for (phi = 0; phi <= steps; phi++) {
    m_next[0][phi] = cos((double)phi/steps * 2 * M_PI) * (minorR * cos((double)theta/steps * 2 * M_PI) + majorR);
    m_next[1][phi] = minorR * sin((double)theta/steps * 2 * M_PI);
    m_next[2][phi] = -sin((double)phi/steps * 2 * M_PI) * (minorR * cos((double)theta/steps * 2 * M_PI) + majorR);

    if (phi != 0) {
      //      printf("Edge (%f, %f, %f) - (%f, %f, %f)\t(%04x, %04x, %04x) - (%04x, %04x, %04x)\n",
      //m_next[0][phi-1], m_next[1][phi-1], m_next[2][phi-1],
      //       m_next[0][phi], m_next[1][phi], m_next[2][phi],
      printf("[(%04x, %04x, %04x), (%04x, %04x, %04x)] phi = %d, theta = %d\n",
             ftrans(m_next[0][phi-1]) >> 2, ftrans(m_next[1][phi-1]) >> 2, ftrans(m_next[2][phi-1]) >> 2,
             ftrans(m_next[0][phi]) >> 2, ftrans(m_next[1][phi]) >> 2, ftrans(m_next[2][phi]) >> 2,
             64*phi, 64*theta);

    }
  }

  //return 0;

  for (theta = 1; theta <= steps; theta++) {
    for (i = 0; i <= steps; i++) {
      m_init[0][i] = m_next[0][i];
      m_init[1][i] = m_next[1][i];
      m_init[2][i] = m_next[2][i];
    }

    for (phi = 0; phi <= steps; phi++) {
      m_next[0][phi] = cos((double)phi/steps * 2 * M_PI) * (minorR * cos((double)theta/steps * 2 * M_PI) + majorR);
      m_next[1][phi] = minorR * sin((double)theta/steps * 2 * M_PI);
      m_next[2][phi] = -sin((double)phi/steps * 2 * M_PI) * (minorR * cos((double)theta/steps * 2 * M_PI) + majorR);

      if (phi != 0) {
        //printf("Edge (%f, %f, %f) - (%f, %f, %f)\t(%04x, %04x, %04x) - (%04x, %04x, %04x)\n",
        //               m_next[0][phi-1], m_next[1][phi-1], m_next[2][phi-1],
        //       m_next[0][phi], m_next[1][phi], m_next[2][phi],
        printf("[(%04x, %04x, %04x), (%04x, %04x, %04x)] phi = %d, theta = %d\n",
               ftrans(m_next[0][phi-1]) >> 2, ftrans(m_next[1][phi-1]) >> 2, ftrans(m_next[2][phi-1]) >> 2,
               ftrans(m_next[0][phi]) >> 2, ftrans(m_next[1][phi]) >> 2, ftrans(m_next[2][phi]) >> 2,
               64*phi, 64*theta);
      }

      //printf("Edge (%f, %f, %f) - (%f, %f, %f)\t(%04x, %04x, %04x) - (%04x, %04x, %04x)\n",
      //m_init[0][phi-1], m_init[1][phi-1], m_init[2][phi-1],
      //       m_next[0][phi], m_next[1][phi], m_next[2][phi],

      /*
      printf("INIT [(%04x, %04x, %04x), (%04x, %04x, %04x)]\n",
             ftrans(m_init[0][phi-1]) >> 2, ftrans(m_init[1][phi-1]) >> 2, ftrans(m_init[2][phi-1]) >> 2,
             ftrans(m_next[0][phi]) >> 2, ftrans(m_next[1][phi]) >> 2, ftrans(m_next[2][phi]) >> 2);
      */
    }
  }

  return 0;
}
