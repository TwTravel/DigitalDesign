#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

int ftrans(float fnum) {
  // 2-bit signed complement with 1 bit exponent
  float fnormed;
  int retval;

  if (fnum < -2.0) return 0x20000;
  else if (fnum >= 2.0) return 0x1ffff;

  if (fnum < 0) fnormed = fnum + 2.0;
  else fnormed = fnum;

  retval = (int)(fnum*65536);
  if (fnum < 0)
    retval |= 0x2000;

  return retval & 0x3ffff;
}

float itrans(int inum) {
  // sign bit is at 0x20000, equiv to -2
  // 0x1_0000 is +1
  // 0x0_0000 is zero
  // 0x3_0000 is -1
  // 0x2_0000 is -2
  // 2^16 = 65536
  float fnum = ((inum & 0x1ffff)/(float)65536);
  if (0x20000 & inum) fnum -= 2.0;
  return fnum;
}

int main (void) {
  int inum;
  float fnum;

  inum = 0x20000;
  printf("inum = 0x%05x, itrans = %f\n", inum, itrans(inum));

  inum = 0x04000;
  printf("inum = 0x%05x, itrans = %f\n", inum, itrans(inum));

  inum = 0x08000;
  printf("inum = 0x%05x, itrans = %f\n", inum, itrans(inum));

  inum = 0x38000;
  printf("inum = 0x%05x, itrans = %f\n", inum, itrans(inum));

  inum = 0x28000;
  printf("inum = 0x%05x, itrans = %f\n", inum, itrans(inum));

  inum = 0x38000;
  printf("inum = 0x%05x, itrans = %f\n", inum, itrans(inum));

  inum = 0x04000;
  printf("inum = 0x%05x, itrans = %f\n", inum, itrans(inum));

  printf("product = %f\n", itrans(0x38000)*itrans(0x04000));
  printf("ftrans(product) = 0x%05x\n", ftrans(itrans(0x38000)*itrans(0x04000)));
  
  fnum = 0.5;
  inum = ftrans(fnum);
  printf("float = %f, ftrans = 0x%05x\n", fnum, inum);

  fnum = 0.75;
  inum = ftrans(fnum);
  printf("float = %f, ftrans = 0x%05x\n", fnum, inum);

  fnum = 0.25;
  inum = ftrans(fnum);
  printf("float = %f, ftrans = 0x%05x\n", fnum, inum);

  fnum = 0.5*0.75;
  inum = ftrans(fnum);
  printf("float = %f, ftrans = 0x%05x\n", fnum, inum);

  fnum = 0.5*0.25;
  inum = ftrans(fnum);
  printf("float = %f, ftrans = 0x%05x\n", fnum, inum);

}
