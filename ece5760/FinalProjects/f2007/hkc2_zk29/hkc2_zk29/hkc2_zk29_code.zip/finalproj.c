#include "system.h"
#include <math.h>
#include <stdio.h>
#include "includes.h"
#include "projstructs.h"
#include "model.h"
// This include has definition of alt_irq_register
#include "sys/alt_irq.h"
//The next two includes are in syslib/DeviceDrivers[sopc_builder]
//They have the macros for setting values in peripherals
#include "altera_avalon_timer_regs.h"
#include "altera_avalon_pio_regs.h"

// I like these
#define begin {
#define end }

///// Define Task parameters //////////////////////////////////
#define   TASK_STACKSIZE       2048
OS_STK    task1_stk[TASK_STACKSIZE];
OS_STK    task2_stk[TASK_STACKSIZE];
OS_STK    task3_stk[TASK_STACKSIZE];

#define TASK1_PRIORITY      7
#define TASK2_PRIORITY      6
#define TASK3_PRIORITY      5

///// Message queue Define /////////////////////////////////////
#define   MSG_QUEUE_SIZE  10           //Size of message queue
OS_EVENT  *msgqueue;                   //Message queue pointer 
void      *msgqueueSt[MSG_QUEUE_SIZE]; //Storage for messages

#define SSIZE 13 //
#define SSIZEF 8
#define ASIZE 13
#define ASIZEF 8


// this function converts a double to 18 bit 2's complement, 6:12, -32.0 to 31.999755
int double2fixed2(double in)
begin
    unsigned int out = 0;
    double dinc = 16;  //start double increment at 16
    unsigned int finc = 1<<16;  //start fixed increment equivalent 0x10000 = 16
    double value = in;
    int cnt = 0;
    
    // loop through successive checks of the binary value while your increments are valid
    while (value != 0 && dinc >= 1/8192 && finc != 0)
    begin
        if (value > 0)
        begin
           out += finc;
           value -= dinc;
           cnt++;
        end
        if (value < 0)
        begin
            out -= finc;
            value += dinc;
            cnt++;
        end
        // if your count is greater than one, then you have to change your increments
        if (cnt > 1)
        begin
            dinc = dinc/2;
            finc = finc>>1;
        end        
        cnt = 0;
    end
    return out & 0x3ffff;
end

//--------------------------------------------

//global ship index variable to iterate through face list and vertex list
int indexm = 0; 
int icnt = 0;
//global asteroid index variable to iterate through face list and vertex list
int aindexm = 0;
int aicnt = 0;

///// task 1 ///////////////////////////////////////////////////
// user interface to move ship
void task1(void* pdata)
begin
  int ch;  //input char
  int i; 
  
  while (1)
  begin
    ch = getchar();
    switch(ch)
    begin
        case 119: // char w
        begin
            indexm = 0;  //reset indices to redraw ship
            icnt = 0;           
            IOWR_ALTERA_AVALON_PIO_DATA(CONTROL_BASE, 0x4); //clear screen
            for (i=0; i<SIZE; i++)  // shift model up by 3 pixels
            begin
                ship[i].y = ship[i].y-3;
            end
            printf("w\n");  
            break; 
        end
        case 97:  // char a
        begin 
            indexm = 0;  //reset indices to redraw ship
            icnt = 0;  
            IOWR_ALTERA_AVALON_PIO_DATA(CONTROL_BASE, 0x4);
            for (i=0; i<SIZE; i++)  // shift model left by 3 pixels
            begin
                ship[i].x = ship[i].x-3;
            end
            printf("a\n");
            break;   
        end
        case 115: // char s
        begin       
            indexm = 0;  //reset indices to redraw ship
            icnt = 0;  
            IOWR_ALTERA_AVALON_PIO_DATA(CONTROL_BASE, 0x4);
            for (i=0; i<SIZE; i++)  // shift model down by 3 pixels
            begin
                ship[i].y = ship[i].y+3;
            end            
            printf("s\n");
            break;   
        end
        case 100: // char d
        begin 
            indexm = 0;  //reset indices to redraw ship
            icnt = 0;  
            IOWR_ALTERA_AVALON_PIO_DATA(CONTROL_BASE, 0x4);
            for (i=0; i<SIZE; i++)  // shift model right by 3 pixels
            begin
                ship[i].x = ship[i].x+3;
            end                        
            printf("d\n");
            break;   
        end
        default:
            break;                        
    end
    
    // wake task 3
    OSTaskResume(TASK3_PRIORITY);
  end
end

///// task 2 /////////////////////////////////////////////////////
// draw asteroid
void task2(void* pdata)
begin
  int ready = 0;
  int x1, y1, z1;
  int x2, y2, z2;
  int i;
  
  while (1)
  begin
    usleep(10000);  //sleep to let hardware enough time to draw so artifacts don't appear
    ready = IORD_ALTERA_AVALON_PIO_DATA(READY_BASE);
    if (ready && aindexm < 20)
    begin
        // iterate through face list and obtain each vertex pair to send
        switch(aicnt)
        begin
            case 0:
            begin
                x1 = ast[astface[aindexm].i].x;
                y1 = ast[astface[aindexm].i].y;        
                z1 = ast[astface[aindexm].i].z;
                x2 = ast[astface[aindexm].j].x;
                y2 = ast[astface[aindexm].j].y;        
                z2 = ast[astface[aindexm].j].z;
                aicnt++;
                break;         
            end
            case 1:
            begin
                x1 = ast[astface[aindexm].j].x;
                y1 = ast[astface[aindexm].j].y;        
                z1 = ast[astface[aindexm].j].z;
                x2 = ast[astface[aindexm].k].x;
                y2 = ast[astface[aindexm].k].y;        
                z2 = ast[astface[aindexm].k].z;
                aicnt++;
                break;
            end
            case 2:
            begin
                x1 = ast[astface[aindexm].k].x;
                y1 = ast[astface[aindexm].k].y;        
                z1 = ast[astface[aindexm].k].z;
                x2 = ast[astface[aindexm].i].x;
                y2 = ast[astface[aindexm].i].y;        
                z2 = ast[astface[aindexm].i].z;
                aicnt = 0;
                aindexm++;
                break;
            end
            default:
                break;
        end                
        // send the coordinates to hardware       
        IOWR_ALTERA_AVALON_PIO_DATA(WORLD1_X_BASE, x1);
        IOWR_ALTERA_AVALON_PIO_DATA(WORLD1_Y_BASE, y1);
        IOWR_ALTERA_AVALON_PIO_DATA(WORLD1_Z_BASE, z1);
        IOWR_ALTERA_AVALON_PIO_DATA(WORLD2_X_BASE, x2);
        IOWR_ALTERA_AVALON_PIO_DATA(WORLD2_Y_BASE, y2);
        IOWR_ALTERA_AVALON_PIO_DATA(WORLD2_Z_BASE, z2);
        IOWR_ALTERA_AVALON_PIO_DATA(CONTROL_BASE, 0x7);  //0x7 = drawline
    end
    else
    begin
        IOWR_ALTERA_AVALON_PIO_DATA(CONTROL_BASE, 0x0);  //do nothing
    end

    if (aindexm >= 20)
    begin
        for (i=0; i<12; i++)  // move asteroid down and left
        begin
            ast[i].x = ast[i].x-1;
            ast[i].y = ast[i].y+3;
        end
        aindexm = 0;  // reset index to draw again
        aicnt = 0;
        // wake task 1
        OSTaskResume(TASK1_PRIORITY);
        // suspend self 
        OSTaskSuspend(TASK2_PRIORITY);
    end
  end
end

///// task 3 //////////////////////////////////////////////////////
// draw ship
void task3(void* pdata)
begin
  int ready = 0;
  int x1, y1, z1;
  int x2, y2, z2;
   
  while (1)
  begin
    usleep(10000);  //sleep to let hardware enough time to draw so artifacts don't appear
    ready = IORD_ALTERA_AVALON_PIO_DATA(READY_BASE);
    if (ready && indexm < SIZEF)
    begin
        // iterate through face list and obtain each vertex pair to send
        switch(icnt)
        begin
            case 0:
            begin
                x1 = ship[shipface[indexm].i].x;
                y1 = ship[shipface[indexm].i].y;        
                z1 = ship[shipface[indexm].i].z;
                x2 = ship[shipface[indexm].j].x;
                y2 = ship[shipface[indexm].j].y;        
                z2 = ship[shipface[indexm].j].z;
                icnt++;
                break;         
            end
            case 1:
            begin
                x1 = ship[shipface[indexm].j].x;
                y1 = ship[shipface[indexm].j].y;        
                z1 = ship[shipface[indexm].j].z;
                x2 = ship[shipface[indexm].k].x;
                y2 = ship[shipface[indexm].k].y;        
                z2 = ship[shipface[indexm].k].z;
                icnt++;
                break;
            end
            case 2:
            begin
                x1 = ship[shipface[indexm].k].x;
                y1 = ship[shipface[indexm].k].y;        
                z1 = ship[shipface[indexm].k].z;
                x2 = ship[shipface[indexm].i].x;
                y2 = ship[shipface[indexm].i].y;        
                z2 = ship[shipface[indexm].i].z;
                icnt = 0;
                indexm++;
                break;
            end
            default:
                break;
        end                
        // send the coordinates to hardware
        IOWR_ALTERA_AVALON_PIO_DATA(WORLD1_X_BASE, x1);
        IOWR_ALTERA_AVALON_PIO_DATA(WORLD1_Y_BASE, y1);
        IOWR_ALTERA_AVALON_PIO_DATA(WORLD1_Z_BASE, z1);
        IOWR_ALTERA_AVALON_PIO_DATA(WORLD2_X_BASE, x2);
        IOWR_ALTERA_AVALON_PIO_DATA(WORLD2_Y_BASE, y2);
        IOWR_ALTERA_AVALON_PIO_DATA(WORLD2_Z_BASE, z2);
        IOWR_ALTERA_AVALON_PIO_DATA(CONTROL_BASE, 0x7);  //0x7 = drawline
    end
    else
    begin
        IOWR_ALTERA_AVALON_PIO_DATA(CONTROL_BASE, 0x0);  //do nothing
    end

    if (indexm >= SIZEF)
    begin
        // wake task 2
        OSTaskResume(TASK2_PRIORITY);
        // suspend self
        OSTaskSuspend(TASK3_PRIORITY);
    end
  end
end

////// main ////////////////////////////////////////////////////
// The main function makes a queue and a semaphore,
//creates three tasks, and starts multi-tasking
int main(void)
begin
  
  OSTaskCreateExt(task1,
                  NULL,
                  (void *)&task1_stk[TASK_STACKSIZE],
                  TASK1_PRIORITY,
                  TASK1_PRIORITY,
                  task1_stk,
                  TASK_STACKSIZE,
                  NULL,
                  0);            
               
  OSTaskCreateExt(task2,
                  NULL,
                  (void *)&task2_stk[TASK_STACKSIZE],
                  TASK2_PRIORITY,
                  TASK2_PRIORITY,
                  task2_stk,
                  TASK_STACKSIZE,
                  NULL,
                  0);
  
  OSTaskCreateExt(task3,
                  NULL,
                  (void *)&task3_stk[TASK_STACKSIZE],
                  TASK3_PRIORITY,
                  TASK3_PRIORITY,
                  task3_stk,
                  TASK_STACKSIZE,
                  NULL,
                  0);
                  
  OSStart();
  return 0;
end
