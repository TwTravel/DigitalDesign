#ifndef PROJSTRUCTS_H_
#define PROJSTRUCTS_H_

// Vertex list struct description
struct VertexDesc
{
double x;  //x coord
double y;  //y coord
double z;  //z coord
};

// Vertex list struct description
struct FaceDesc
{
int i;  //vertex i
int j;  //vertex j
int k;  //vertex k
};

#endif /*PROJSTRUCTS_H_*/
