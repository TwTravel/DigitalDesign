clc
% input matrix in floating point
input = [4.2709   -1.5051   -1.0165   -0.6099 ...
    0.0000    5.2460   -0.6608   -0.3965 ...
    -3.7964   -1.6932   -1.1436   -0.6862 ...
    -0.2373   -1.0239    5.6741    7.4045];
% resultant output matrix
output = zeros(1,16);
for i = 1:16;
    in = input(i);
    out = uint32(0);
    dinc = 64;  % start floating point increment at 64
    finc = bitshift(1, 18); % start fixed increment at 0x40000 = 64
    value = in;
    cnt = 0;
    % loop through successive checks of the binary value while your increments are valid
    while (value ~= 0) && (dinc >= 1/8192) && (finc ~= 0)
        if (value > 0)
            out = out + finc;
            value = value - dinc;
            cnt = cnt +1;
        end
        if (value < 0)
            out = out - finc;
            value = value + dinc;
            cnt = cnt +1;
        end
        % if your count is greater than one, then you have to change your increments
        if (cnt > 1)
            dinc = dinc/2;
            finc = bitshift(finc,-1);
        end
        cnt = 0;
    end
    %out = bitand(out,hex2dec('3ffff'));
    output(i) = out;
end
dec2hex(output)