
#include "basic_io.h"
#include "system.h"
#include <string.h>

#include "altera_avalon_pio_regs.h"

//#include "test.h"
//#include "LCD.h"
#include "DM9000A.C"

#define NUM_RAM_BLOCKS 48
#define RAM_BLOCK_SIZE 256
#define RAM_WE      0x01
#define SS_WE       0x02
#define TBL_WE      0x04
#define BLOCK_RST   0x08


#define DEBUG

#define SDRAM_START ((unsigned short int *) SDRAM_0_BASE)
#define RESET_SDRAM() sdram_ptr = SDRAM_0_BASE
unsigned int aaa,rx_len,i,packet_num;
unsigned char RXT[2048];
unsigned char buff[7340032];
unsigned char ssbuff[2048], tblbuff[2048];
unsigned short int * sdram_ptr;
unsigned short int * ss_ptr;
unsigned int volatile buffUsed = 0;
unsigned int volatile dataTransferred = 0;
unsigned char volatile goFlag = 0;


void checkData() {
    ior(0xF0);
    printf("%2X\n", ior(0xF2));   
    
}

void ethernet_interrupts()
{   
    unsigned char rx_READY;
  unsigned int  Tmp, i, rx_len, ptype, RxStatus;
    packet_num++;
    
  rx_len = 0;

   /* mask NIC interrupts IMR: PAR only */
  iow(IMR, PAR_set);
  
  /* dummy read a byte from MRCMDX REG. F0H */
  rx_READY = ior(MRCMDX);
  
  /* got most updated byte: rx_READY */
  rx_READY = IORD(DM9000A_BASE,IO_data)&0x03;
  //usleep(STD_DELAY);
  
  /* check if (rx_READY == 0x01): Received Packet READY? */
  
    //printf("rx_READY = %X!\n", rx_READY);
  if (rx_READY == DM9000_PKT_READY)
  {
    /* got RX_Status & RX_Length from RX SRAM */
    IOWR(DM9000A_BASE, IO_addr, MRCMD); /* set MRCMD REG. F2H RX I/O port ready */
    //usleep(STD_DELAY);
    RxStatus = IORD(DM9000A_BASE,IO_data);
    //usleep(STD_DELAY);
    rx_len = IORD(DM9000A_BASE,IO_data);

    /* Check this packet_status GOOD or BAD? */
    if ( !(RxStatus & 0xBF00) && (rx_len < MAX_PACKET_SIZE) )
    {
        //read the destination MAC (and ignore it)
        for (i = 0; i < 6; i+=2) {
            //usleep(STD_DELAY);
            Tmp = IORD(DM9000A_BASE, IO_data);
        }
        //read first 6 bytes of source MAC (and ignore first four)
        for (; i < 12; i += 2) {
             //usleep(STD_DELAY);
            ptype = IORD(DM9000A_BASE, IO_data);
        }
        //usleep(STD_DELAY); //read next two bytes (protocol id?) and discard
        Tmp = IORD(DM9000A_BASE, IO_data);
        i+=2;
        
        if (ptype == 0) { //if reset packet
            #ifdef DEBUG
                printf("Got reset packet!\n");
            #endif
            for (; i < rx_len; i += 2) { //dump the data
              usleep(STD_DELAY);
              Tmp = IORD(DM9000A_BASE, IO_data);
            }
            unsigned int * clearer;
            for (clearer = sdram_ptr; clearer < sdram_ptr; clearer++)
                *clearer = 0; 
            sdram_ptr = buff;
            ss_ptr = ssbuff;
            
        } else if (ptype == 0xAAAA) { //printf packet
            #ifdef DEBUG
            printf("Got print packet!\n");
            #endif
            //puts(buff);
            unsigned char *theend = (unsigned char *) sdram_ptr;
            unsigned char *counter = buff;
            unsigned int checksum = 0;
            
            for (;counter < theend; counter++)
                checksum += *counter;
            
            printf("%d\n",checksum);
               
            for (; i < rx_len; i += 2) { //dump the data
                usleep(STD_DELAY);
                Tmp = IORD(DM9000A_BASE, IO_data);
            } 
            //puts(SDRAM_START);
        } else if (ptype == 0xBBBB) { //printf packet
            #ifdef DEBUG
            printf("Got go packet!\n");
            #endif
            //puts(buff);              
            for (; i < rx_len; i += 2) { //dump the data
                usleep(STD_DELAY);
                Tmp = IORD(DM9000A_BASE, IO_data);
            } 
            goFlag = 1;
            //puts(SDRAM_START);
        } else if (ptype == 0xCCCC) {
        //data packet
            #ifdef DEBUG
            printf("Got search string packet length %d!\n", rx_len);
            #endif
            for (; i < rx_len - 4; i += 2) {
                //usleep(STD_DELAY);
                *(ss_ptr++) = IORD(DM9000A_BASE, IO_data);
               }
               
               //just eat the checksum
                //usleep(STD_DELAY);
                Tmp = IORD(DM9000A_BASE, IO_data);            
                //usleep(STD_DELAY);
                Tmp = IORD(DM9000A_BASE, IO_data);
                i+=2;
            #ifdef DEBUG
            printf(ssbuff);
            printf("\n");
            #endif
                dataTransferred += rx_len - (4 + 14);
        
        } else { //data packet
            #ifdef DEBUG
            printf("Got data packet length %d!\n", rx_len);
            #endif
            for (; i < rx_len - 4; i += 2) {
                //usleep(STD_DELAY);
                *(sdram_ptr++) = IORD(DM9000A_BASE, IO_data);
               }
               
               //just eat the checksum
                //usleep(STD_DELAY);
                Tmp = IORD(DM9000A_BASE, IO_data);            
                //usleep(STD_DELAY);
                Tmp = IORD(DM9000A_BASE, IO_data);
                i+=2;
                
                dataTransferred += rx_len - (4 + 14);
        }
    } /* end if (GoodPacket) */
    else
    {
      /* this packet is bad, dump it from RX SRAM */
      for (i = 0; i < rx_len; i += 2)
      {
        usleep(STD_DELAY);
        Tmp = IORD(DM9000A_BASE, IO_data);        
      }
      
      printf("\nError\n");
    } /* end if (!GoodPacket) */
  } /* end if (rx_READY == DM9000_PKT_READY) ok */
  else if(rx_READY) /* status check first byte: rx_READY Bit[1:0] must be "00"b or "01"b */
  {
    /* software-RESET NIC */
    iow(NCR, 0x03);   /* NCR REG. 00 RST Bit [0] = 1 reset on, and LBK Bit [2:1] = 01b MAC loopback on */
    usleep(20);       /* wait > 10us for a software-RESET ok */
    iow(NCR, 0x00);   /* normalize */
    iow(NCR, 0x03);
    usleep(20);
    iow(NCR, 0x00);    
    /* program operating registers~ */
    iow(NCR,  NCR_set);   /* NCR REG. 00 enable the chip functions (and disable this MAC loopback mode back to normal) */
    iow(0x08, BPTR_set);  /* BPTR  REG.08  (if necessary) RX Back Pressure Threshold in Half duplex moe only: High Water 3KB, 600 us */
    iow(0x09, FCTR_set);  /* FCTR  REG.09  (if necessary) Flow Control Threshold setting High/ Low Water Overflow 5KB/ 10KB */
    iow(0x0A, RTFCR_set); /* RTFCR REG.0AH (if necessary) RX/TX Flow Control Register enable TXPEN, BKPM (TX_Half), FLCE (RX) */
    iow(0x0F, 0x00);      /* Clear the all Event */
    iow(0x2D, 0x80);      /* Switch LED to mode 1 */
    /* set other registers depending on applications */
    iow(ETXCSR, ETXCSR_set); /* Early Transmit 75% */
    /* enable interrupts to activate DM9000 ~on */
    iow(IMR, INTR_set);   /* IMR REG. FFH PAR=1 only, or + PTM=1& PRM=1 enable RxTx interrupts */
    /* enable RX (Broadcast/ ALL_MULTICAST) ~go */
    iow(RCR , RCR_set | RX_ENABLE | PASS_MULTICAST);  /* RCR REG. 05 RXEN Bit [0] = 1 to enable the RX machine/ filter */
  } /* end NIC H/W system Data-Bus error */

    //outport(SEG7_DISPLAY_BASE,packet_num);
    /* clear any pending interrupt */
  iow(ISR, 0x3F);     /* clear the ISR status: PRS, PTS, ROS, ROOS 4 bits, by RW/C1 */

  iow(IMR, INTR_set);   /* IMR REG. FFH PAR=1 only, or + PTM=1& PRM=1 enable RxTx interrupts */
    
    
    
    buffUsed = ((unsigned char *) sdram_ptr) - buff;

}



void genTable() {
    unsigned char * searchString = ssbuff;
    
    unsigned char * table = tblbuff;
    int i,j;
    
    i = 2; //i is the current position we are computing in the table
           //i goes up to the length of the searchString (or when null is found)
    j = 0; //j is the index in the searchString of the next character of the current potential substring
    table[0] = -1; //the first location is -1
    table[1] = 0; //the second location is 0
    while (searchString[i] != '\0') { //while we haven't reached the end of the string
    if (searchString[i-1] == searchString[j]){ //if a repeating substring has been found
        table[i] = j + 1; //put a 1 for the first character match, a 2 for the second, etc
        i++; //go to the next character in the searchString
        j++; //increment j
    }
    else if (j>0){ //if there is no match, set j to table[j] to continue searching
        j = table[j];
    }
    else{ //if there is no match and j <= 0, table[i] gets 0
        table[i] = 0;
        i++; //go to the next character in the searchString
    }
    }
}


int main(void)
{
    unsigned short *sp;
    int j, k;
    unsigned char readback[10240];
    unsigned char sstmp[2048];

  //LCD_Test();
  DM9000_init();
  alt_irq_register( DM9000A_IRQ, NULL, (void*)ethernet_interrupts );
  unsigned int lastPrint = 0;
 
  packet_num=0;
  #ifdef DEBUG
  printf("Terminal works...\n");
  #endif
  
    printf("Starting...\n");
  
  /*sp = (unsigned short *) string512;
  IOWR_ALTERA_AVALON_PIO_DATA(CONTROL_FLAGS_BASE, 1); //write enable
  for (j = 0; j < 256; j++) {
         IOWR_ALTERA_AVALON_PIO_DATA(MEM_ADDR_BASE, j);
         IOWR_ALTERA_AVALON_PIO_DATA(DATA_OUT_BASE, sp[j]);
    
  }
  */
        IOWR_ALTERA_AVALON_PIO_DATA(CONTROL_FLAGS_BASE, 0x04); 

  while (1)
  {

    gets(sstmp);
    
    if (sstmp[1]){
        
        strcpy(ssbuff,sstmp);
        ssbuff[strlen(ssbuff) - 1] = 0;
    }
    //printf(ssbuff);
    goFlag = 1;
            
    #ifdef DEBUG
    if (dataTransferred - lastPrint >= 102400) {
        printf("%d Bytes Tranferred...\n", dataTransferred);
        lastPrint = dataTransferred;
    }
    #endif

    if (goFlag) {
        unsigned char bufferEmpty = 0;
        unsigned char * currentByte;
        unsigned int block, ramIndex;
        
        goFlag = 0;
        currentByte = (unsigned char *) buff;
        
        genTable();
      
            //Write search string...
            IOWR_ALTERA_AVALON_PIO_DATA(CONTROL_FLAGS_BASE, SS_WE | BLOCK_RST); //write enable on
            for (ramIndex = 0; ramIndex < RAM_BLOCK_SIZE; ramIndex++) {
                IOWR_ALTERA_AVALON_PIO_DATA(MEM_ADDR_BASE, ramIndex);
                IOWR_ALTERA_AVALON_PIO_DATA(DATA_OUT_BASE, ssbuff[ramIndex]);      
                
            }                    
            
            
            //Write the table
          while (!bufferEmpty) {
            IOWR_ALTERA_AVALON_PIO_DATA(CONTROL_FLAGS_BASE, TBL_WE | BLOCK_RST); //write enable on
            for (ramIndex = 0; ramIndex < RAM_BLOCK_SIZE; ramIndex++) {
                IOWR_ALTERA_AVALON_PIO_DATA(MEM_ADDR_BASE, ramIndex);
                IOWR_ALTERA_AVALON_PIO_DATA(DATA_OUT_BASE, tblbuff[ramIndex]);               
            }                    
           
            //Write data to RAM blocks
            IOWR_ALTERA_AVALON_PIO_DATA(CONTROL_FLAGS_BASE, RAM_WE | BLOCK_RST); //write enable on
            for (block = 0; block < NUM_RAM_BLOCKS; block++) {
                
                IOWR_ALTERA_AVALON_PIO_DATA(MODULE_SEL_BASE, block);    
                ramIndex = 0;
                if (*currentByte != 0) {
                    do {
                        IOWR_ALTERA_AVALON_PIO_DATA(MEM_ADDR_BASE, ramIndex);
                        IOWR_ALTERA_AVALON_PIO_DATA(DATA_OUT_BASE, *(currentByte));
                        ramIndex++;             
                    } while (*(currentByte++) != 0);      
                } else {
                        bufferEmpty = 1;
                        IOWR_ALTERA_AVALON_PIO_DATA(MEM_ADDR_BASE, 0);
                        IOWR_ALTERA_AVALON_PIO_DATA(DATA_OUT_BASE, 0);
                }
                
            }
            
            //Go!
            IOWR_ALTERA_AVALON_PIO_DATA(CONTROL_FLAGS_BASE, 0); //write enable off
            usleep(5);
            //Read results...
            int blk, retval;
            blk = 0;
            while (blk < NUM_RAM_BLOCKS) {
                
                IOWR_ALTERA_AVALON_PIO_DATA(MODULE_SEL_BASE, blk);
                retval = IORD_ALTERA_AVALON_PIO_DATA(RESULT_IN_BASE);
                if (retval & 0x8000) {
                    blk++;
                    printf("String %d:", blk);
                    if ((retval & 0x00ff) == 0x00ff) {
                        printf(" Not Found!\n");
                    } else {
                        printf(" Location %d\n", retval & 0x0ff);
                    } 
                }
        }
        
        
        

            
           
            

            
        }
    /*
    sp = (unsigned short *) readback;
    for (k = 0; k < NUM_RAM_BLOCKS; k++) {
        IOWR_ALTERA_AVALON_PIO_DATA(MODULE_SEL_BASE, k);
        
        for (j = 0; j < RAM_BLOCK_SIZE; j++) {
             IOWR_ALTERA_AVALON_PIO_DATA(MEM_ADDR_BASE, j);
            sp[j + k * RAM_BLOCK_SIZE] = IORD_ALTERA_AVALON_PIO_DATA(RESULT_IN_BASE);
            }
            
    }
    for (j = 0; j < 700; j++)
        putchar(readback[j]);
*/

    }

  }

  return 0;
}

//-------------------------------------------------------------------------


