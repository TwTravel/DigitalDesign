/* system.h
 *
 * Machine generated for a CPU named "cpu_0" as defined in:
 * C:\DE2_NET\system_0.ptf
 *
 * Generated: 2007-11-26 22:29:55.825
 *
 */

#ifndef __SYSTEM_H_
#define __SYSTEM_H_

/*

DO NOT MODIFY THIS FILE

   Changing this file will have subtle consequences
   which will almost certainly lead to a nonfunctioning
   system. If you do modify this file, be aware that your
   changes will be overwritten and lost when this file
   is generated again.

DO NOT MODIFY THIS FILE

*/

/******************************************************************************
*                                                                             *
* License Agreement                                                           *
*                                                                             *
* Copyright (c) 2003 Altera Corporation, San Jose, California, USA.           *
* All rights reserved.                                                        *
*                                                                             *
* Permission is hereby granted, free of charge, to any person obtaining a     *
* copy of this software and associated documentation files (the "Software"),  *
* to deal in the Software without restriction, including without limitation   *
* the rights to use, copy, modify, merge, publish, distribute, sublicense,    *
* and/or sell copies of the Software, and to permit persons to whom the       *
* Software is furnished to do so, subject to the following conditions:        *
*                                                                             *
* The above copyright notice and this permission notice shall be included in  *
* all copies or substantial portions of the Software.                         *
*                                                                             *
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR  *
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,    *
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE *
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER      *
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING     *
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER         *
* DEALINGS IN THE SOFTWARE.                                                   *
*                                                                             *
* This agreement shall be governed in all respects by the laws of the State   *
* of California and by the laws of the United States of America.              *
*                                                                             *
******************************************************************************/

/*
 * system configuration
 *
 */

#define ALT_SYSTEM_NAME "system_0"
#define ALT_CPU_NAME "cpu_0"
#define ALT_CPU_ARCHITECTURE "altera_nios2"
#define ALT_DEVICE_FAMILY "CYCLONE"
#define DE2_BOARD
#define ALT_STDIN "/dev/jtag_uart_0"
#define ALT_STDIN_TYPE "altera_avalon_jtag_uart"
#define ALT_STDIN_BASE 0x00080860
#define ALT_STDIN_DEV jtag_uart_0
#define ALT_STDIN_PRESENT
#define ALT_STDOUT "/dev/jtag_uart_0"
#define ALT_STDOUT_TYPE "altera_avalon_jtag_uart"
#define ALT_STDOUT_BASE 0x00080860
#define ALT_STDOUT_DEV jtag_uart_0
#define ALT_STDOUT_PRESENT
#define ALT_STDERR "/dev/jtag_uart_0"
#define ALT_STDERR_TYPE "altera_avalon_jtag_uart"
#define ALT_STDERR_BASE 0x00080860
#define ALT_STDERR_DEV jtag_uart_0
#define ALT_STDERR_PRESENT
#define ALT_CPU_FREQ 100000000
#define ALT_IRQ_BASE NULL
#define ALT_EXCEPTION_STACK

/*
 * processor configuration
 *
 */

#define NIOS2_CPU_IMPLEMENTATION "fast"
#define NIOS2_BIG_ENDIAN 0

#define NIOS2_ICACHE_SIZE 4096
#define NIOS2_DCACHE_SIZE 2048
#define NIOS2_ICACHE_LINE_SIZE 32
#define NIOS2_ICACHE_LINE_SIZE_LOG2 5
#define NIOS2_DCACHE_LINE_SIZE 4
#define NIOS2_DCACHE_LINE_SIZE_LOG2 2
#define NIOS2_FLUSHDA_SUPPORTED

#define NIOS2_EXCEPTION_ADDR 0x00000020
#define NIOS2_RESET_ADDR 0x00000000
#define NIOS2_BREAK_ADDR 0x00080020

#define NIOS2_HAS_DEBUG_STUB

#define NIOS2_CPU_ID_SIZE 1
#define NIOS2_CPU_ID_VALUE 0

/*
 * A define for each class of peripheral
 *
 */

#define __ALTERA_AVALON_JTAG_UART
#define __SRAM_16BIT_512K
#define __ALTERA_AVALON_NEW_SDRAM_CONTROLLER
#define __DM9000A
#define __ALTERA_AVALON_PIO

/*
 * jtag_uart_0 configuration
 *
 */

#define JTAG_UART_0_NAME "/dev/jtag_uart_0"
#define JTAG_UART_0_TYPE "altera_avalon_jtag_uart"
#define JTAG_UART_0_BASE 0x00080860
#define JTAG_UART_0_SPAN 8
#define JTAG_UART_0_IRQ 0
#define JTAG_UART_0_WRITE_DEPTH 64
#define JTAG_UART_0_READ_DEPTH 64
#define JTAG_UART_0_WRITE_THRESHOLD 8
#define JTAG_UART_0_READ_THRESHOLD 8
#define JTAG_UART_0_READ_CHAR_STREAM ""
#define JTAG_UART_0_SHOWASCII 1
#define JTAG_UART_0_READ_LE 0
#define JTAG_UART_0_WRITE_LE 0
#define JTAG_UART_0_ALTERA_SHOW_UNRELEASED_JTAG_UART_FEATURES 0
#define ALT_MODULE_CLASS_jtag_uart_0 altera_avalon_jtag_uart

/*
 * sram_0 configuration
 *
 */

#define SRAM_0_NAME "/dev/sram_0"
#define SRAM_0_TYPE "sram_16bit_512k"
#define SRAM_0_BASE 0x00000000
#define SRAM_0_SPAN 524288
#define SRAM_0_HDL_PARAMETERS ""
#define ALT_MODULE_CLASS_sram_0 sram_16bit_512k

/*
 * sdram_0 configuration
 *
 */

#define SDRAM_0_NAME "/dev/sdram_0"
#define SDRAM_0_TYPE "altera_avalon_new_sdram_controller"
#define SDRAM_0_BASE 0x00800000
#define SDRAM_0_SPAN 8388608
#define SDRAM_0_REGISTER_DATA_IN 1
#define SDRAM_0_SIM_MODEL_BASE 1
#define SDRAM_0_SDRAM_DATA_WIDTH 16
#define SDRAM_0_SDRAM_ADDR_WIDTH 12
#define SDRAM_0_SDRAM_ROW_WIDTH 12
#define SDRAM_0_SDRAM_COL_WIDTH 8
#define SDRAM_0_SDRAM_NUM_CHIPSELECTS 1
#define SDRAM_0_SDRAM_NUM_BANKS 4
#define SDRAM_0_REFRESH_PERIOD 15.625
#define SDRAM_0_POWERUP_DELAY 100
#define SDRAM_0_CAS_LATENCY 3
#define SDRAM_0_T_RFC 70
#define SDRAM_0_T_RP 20
#define SDRAM_0_T_MRD 3
#define SDRAM_0_T_RCD 20
#define SDRAM_0_T_AC 5.5
#define SDRAM_0_T_WR 14
#define SDRAM_0_INIT_REFRESH_COMMANDS 2
#define SDRAM_0_INIT_NOP_DELAY 0
#define SDRAM_0_SHARED_DATA 0
#define SDRAM_0_STARVATION_INDICATOR 0
#define SDRAM_0_TRISTATE_BRIDGE_SLAVE ""
#define SDRAM_0_IS_INITIALIZED 1
#define SDRAM_0_SDRAM_BANK_WIDTH 2
#define SDRAM_0_CONTENTS_INFO "SIMDIR/sdram_0.dat 1130817965"
#define ALT_MODULE_CLASS_sdram_0 altera_avalon_new_sdram_controller

/*
 * DM9000A configuration
 *
 */

#define DM9000A_NAME "/dev/DM9000A"
#define DM9000A_TYPE "dm9000a"
#define DM9000A_BASE 0x00080868
#define DM9000A_SPAN 8
#define DM9000A_IRQ 1
#define DM9000A_HDL_PARAMETERS ""
#define ALT_MODULE_CLASS_DM9000A dm9000a

/*
 * module_sel configuration
 *
 */

#define MODULE_SEL_NAME "/dev/module_sel"
#define MODULE_SEL_TYPE "altera_avalon_pio"
#define MODULE_SEL_BASE 0x00080800
#define MODULE_SEL_SPAN 16
#define MODULE_SEL_DO_TEST_BENCH_WIRING 0
#define MODULE_SEL_DRIVEN_SIM_VALUE 0x0000
#define MODULE_SEL_HAS_TRI 0
#define MODULE_SEL_HAS_OUT 1
#define MODULE_SEL_HAS_IN 0
#define MODULE_SEL_CAPTURE 0
#define MODULE_SEL_EDGE_TYPE "NONE"
#define MODULE_SEL_IRQ_TYPE "NONE"
#define MODULE_SEL_FREQ 100000000
#define ALT_MODULE_CLASS_module_sel altera_avalon_pio

/*
 * data_out configuration
 *
 */

#define DATA_OUT_NAME "/dev/data_out"
#define DATA_OUT_TYPE "altera_avalon_pio"
#define DATA_OUT_BASE 0x00080810
#define DATA_OUT_SPAN 16
#define DATA_OUT_DO_TEST_BENCH_WIRING 0
#define DATA_OUT_DRIVEN_SIM_VALUE 0x0000
#define DATA_OUT_HAS_TRI 0
#define DATA_OUT_HAS_OUT 1
#define DATA_OUT_HAS_IN 0
#define DATA_OUT_CAPTURE 0
#define DATA_OUT_EDGE_TYPE "NONE"
#define DATA_OUT_IRQ_TYPE "NONE"
#define DATA_OUT_FREQ 100000000
#define ALT_MODULE_CLASS_data_out altera_avalon_pio

/*
 * ss_out configuration
 *
 */

#define SS_OUT_NAME "/dev/ss_out"
#define SS_OUT_TYPE "altera_avalon_pio"
#define SS_OUT_BASE 0x00080820
#define SS_OUT_SPAN 16
#define SS_OUT_DO_TEST_BENCH_WIRING 0
#define SS_OUT_DRIVEN_SIM_VALUE 0x0000
#define SS_OUT_HAS_TRI 0
#define SS_OUT_HAS_OUT 1
#define SS_OUT_HAS_IN 0
#define SS_OUT_CAPTURE 0
#define SS_OUT_EDGE_TYPE "NONE"
#define SS_OUT_IRQ_TYPE "NONE"
#define SS_OUT_FREQ 100000000
#define ALT_MODULE_CLASS_ss_out altera_avalon_pio

/*
 * result_in configuration
 *
 */

#define RESULT_IN_NAME "/dev/result_in"
#define RESULT_IN_TYPE "altera_avalon_pio"
#define RESULT_IN_BASE 0x00080830
#define RESULT_IN_SPAN 16
#define RESULT_IN_DO_TEST_BENCH_WIRING 0
#define RESULT_IN_DRIVEN_SIM_VALUE 0x0000
#define RESULT_IN_HAS_TRI 0
#define RESULT_IN_HAS_OUT 0
#define RESULT_IN_HAS_IN 1
#define RESULT_IN_CAPTURE 0
#define RESULT_IN_EDGE_TYPE "NONE"
#define RESULT_IN_IRQ_TYPE "NONE"
#define RESULT_IN_FREQ 100000000
#define ALT_MODULE_CLASS_result_in altera_avalon_pio

/*
 * control_flags configuration
 *
 */

#define CONTROL_FLAGS_NAME "/dev/control_flags"
#define CONTROL_FLAGS_TYPE "altera_avalon_pio"
#define CONTROL_FLAGS_BASE 0x00080840
#define CONTROL_FLAGS_SPAN 16
#define CONTROL_FLAGS_DO_TEST_BENCH_WIRING 0
#define CONTROL_FLAGS_DRIVEN_SIM_VALUE 0x0000
#define CONTROL_FLAGS_HAS_TRI 0
#define CONTROL_FLAGS_HAS_OUT 1
#define CONTROL_FLAGS_HAS_IN 0
#define CONTROL_FLAGS_CAPTURE 0
#define CONTROL_FLAGS_EDGE_TYPE "NONE"
#define CONTROL_FLAGS_IRQ_TYPE "NONE"
#define CONTROL_FLAGS_FREQ 100000000
#define ALT_MODULE_CLASS_control_flags altera_avalon_pio

/*
 * mem_addr configuration
 *
 */

#define MEM_ADDR_NAME "/dev/mem_addr"
#define MEM_ADDR_TYPE "altera_avalon_pio"
#define MEM_ADDR_BASE 0x00080850
#define MEM_ADDR_SPAN 16
#define MEM_ADDR_DO_TEST_BENCH_WIRING 0
#define MEM_ADDR_DRIVEN_SIM_VALUE 0x0000
#define MEM_ADDR_HAS_TRI 0
#define MEM_ADDR_HAS_OUT 1
#define MEM_ADDR_HAS_IN 0
#define MEM_ADDR_CAPTURE 0
#define MEM_ADDR_EDGE_TYPE "NONE"
#define MEM_ADDR_IRQ_TYPE "NONE"
#define MEM_ADDR_FREQ 100000000
#define ALT_MODULE_CLASS_mem_addr altera_avalon_pio

/*
 * system library configuration
 *
 */

#define ALT_MAX_FD 32
#define ALT_SYS_CLK TIMER_0
#define ALT_TIMESTAMP_CLK none

/*
 * Devices associated with code sections.
 *
 */

#define ALT_TEXT_DEVICE       SRAM_0
#define ALT_RODATA_DEVICE     SRAM_0
#define ALT_RWDATA_DEVICE     SDRAM_0
#define ALT_EXCEPTIONS_DEVICE SRAM_0
#define ALT_RESET_DEVICE      SRAM_0

/*
 * The text section is initialised so no bootloader will be required.
 * Set a variable to tell crt0.S to provide code at the reset address and
 * to initialise rwdata if appropriate.
 */

#define ALT_NO_BOOTLOADER


#endif /* __SYSTEM_H_ */
