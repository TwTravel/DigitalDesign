#include "stdafx.h"

char *char2lcdhex(char c);

int main(int argc, char* argv[])
{
  // this program has two modes, one in which the user defines a text
  // file for being converted or the other where the user inputs a 
  // line and it is converted to LCD Hex values space delimited 
    char ins[100];
    FILE *in_file;
    FILE *out;
    int slen;
	int done = 0;
    int i,j,k;
	char *temp;
	char filename[20];

	out = fopen("text2hex.mif", "w");
	fprintf(out, "WIDTH=8;\n");
	fprintf(out, "DEPTH=256;\n");
	fprintf(out, "\n");
	fprintf(out, "ADDRESS_RADIX=UNS;\n");
	fprintf(out, "DATA_RADIX=HEX;\n");
	fprintf(out, "\n");
	fprintf(out, "CONTENT BEGIN\n");
    
    if(argc < 2) {
        printf("Enter a string to be converted?\n");
        gets(ins);
        slen = strlen(ins);
        for(i=0;i<slen;i++){
			temp = char2lcdhex(ins[i]);
			printf("\t%03d    :   %s;\n", i, temp); 
			fprintf(out, "\t%03d    :   %s;\n", i, temp);
			free(temp);
        }
		fprintf(out,"\t[%d..255]  :   00;\n", i); 
	} else if(argc == 2) {
		strcpy(filename, argv[1]);
		in_file = fopen(filename, "r");
		if(in_file==NULL) perror("error opening file");
		j=0;
		while(done!=1 && j <=255){	
			fgets(ins, 100, in_file);
			if(feof(in_file)) done = 1;
			slen = strlen(ins);
			for(i=0;i<slen;i++){
				temp = char2lcdhex(ins[i]);
				printf("\t%03d    :   %s;\n", j, temp); 
				fprintf(out, "\t%03d    :   %s;\n", j, temp);
				free(temp);
				j++;
				if(j > 255) break;
			}
		}
		if(j < 255) fprintf(out,"\t[%d..255]  :   00;\n", j);
		else if(j==255) fprintf(out,"\t255  :   00;\n");
	}
	fprintf(out, "END;\n");
	fclose(out);
    system("PAUSE");	
    return 0;
}

// returns a length 2 array of chars 
// that represents the hex value for the LCD
// specifically Crystalfrontz America's:
// CFAH1602B-TMC-JP LCD display
char *char2lcdhex(char c){
    char *hex_out;

	hex_out = (char*)malloc(3);

    switch(c) {
		case(' '):        strcpy(hex_out, "20");
					break;
        case('!'):        strcpy(hex_out, "21");
                    break;
        case('"'):        strcpy(hex_out, "22");
                    break;
		case('#'):        strcpy(hex_out, "23");
                    break;
        case('$'):        strcpy(hex_out, "24");
                    break;
        case('%'):        strcpy(hex_out, "25");
                    break;
        case('&'):        strcpy(hex_out, "26");
                    break;
        case('\''):        strcpy(hex_out, "27");
                    break;
        case('('):        strcpy(hex_out, "28");
                    break;
        case(')'):        strcpy(hex_out, "29");
                    break;
        case('*'):        strcpy(hex_out, "2A");
                    break;
        case('+'):        strcpy(hex_out, "2B");
                    break;
        case(','):        strcpy(hex_out, "2C");
                    break;
        case('-'):        strcpy(hex_out, "2D");
                    break;
        case('.'):        strcpy(hex_out, "2E");
                    break;
        case('/'):        strcpy(hex_out, "2F");
                    break;
        case('0'):        strcpy(hex_out, "30");
                    break;
        case('1'):        strcpy(hex_out, "31");
                    break;
        case('2'):        strcpy(hex_out, "32");
                    break;
        case('3'):        strcpy(hex_out, "33");
                    break;
        case('4'):        strcpy(hex_out, "34");
                    break;
        case('5'):        strcpy(hex_out, "35");
                    break;
        case('6'):        strcpy(hex_out, "36");
                    break;
        case('7'):        strcpy(hex_out, "37");
                    break;
        case('8'):        strcpy(hex_out, "38");
                    break;
        case('9'):        strcpy(hex_out, "39");
                    break;
		case(':'):        strcpy(hex_out, "3A");
                    break;
		case(';'):        strcpy(hex_out, "3B");
                    break;
		case('<'):        strcpy(hex_out, "3C");
                    break;
		case('='):        strcpy(hex_out, "3D");
                    break;
		case('>'):        strcpy(hex_out, "3E");
                    break;
		case('?'):        strcpy(hex_out, "3F");
                    break;
		case('`'):        strcpy(hex_out, "60");
					break;
        case('a'):        strcpy(hex_out, "61");
					break;
        case('b'):        strcpy(hex_out, "62");
                    break;
        case('c'):        strcpy(hex_out, "63");
                    break;
        case('d'):        strcpy(hex_out, "64");
                    break;
        case('e'):        strcpy(hex_out, "65");
                    break;
        case('f'):        strcpy(hex_out, "66");
                    break;
        case('g'):        strcpy(hex_out, "67");
                    break;
        case('h'):        strcpy(hex_out, "68");
                    break;
        case('i'):        strcpy(hex_out, "69");
                    break;
        case('j'):        strcpy(hex_out, "6A");
                    break;
        case('k'):        strcpy(hex_out, "6B");
                    break;
        case('l'):        strcpy(hex_out, "6C");
                    break;
        case('m'):        strcpy(hex_out, "6D");
                    break;
        case('n'):        strcpy(hex_out, "6E");
                    break;
        case('o'):        strcpy(hex_out, "6F");
                    break;
        case('p'):        strcpy(hex_out, "70");
                    break;
        case('q'):        strcpy(hex_out, "71");
                    break;            
        case('r'):        strcpy(hex_out, "72");
                    break;
        case('s'):        strcpy(hex_out, "73");
                    break;
        case('t'):        strcpy(hex_out, "74");
                    break;
        case('u'):        strcpy(hex_out, "75");
                    break;
        case('v'):        strcpy(hex_out, "76");
                    break;
        case('w'):        strcpy(hex_out, "77");
                    break;
        case('x'):        strcpy(hex_out, "78");
                    break;
        case('y'):        strcpy(hex_out, "79");
                    break;
        case('z'):        strcpy(hex_out, "7A");
                    break;
		case('{'):        strcpy(hex_out, "7B");
                    break;
		case('|'):        strcpy(hex_out, "7C");
                    break;
		case('}'):        strcpy(hex_out, "7D");
                    break;
		case('@'):        strcpy(hex_out, "40");
					break;
        case('A'):        strcpy(hex_out, "41");
                    break;
        case('B'):        strcpy(hex_out, "42");
                    break;
        case('C'):        strcpy(hex_out, "43");
                    break;
        case('D'):        strcpy(hex_out, "44");
                    break;
        case('E'):        strcpy(hex_out, "45");
                    break;
        case('F'):        strcpy(hex_out, "46");
                    break;
        case('G'):        strcpy(hex_out, "47");
                    break;
        case('H'):        strcpy(hex_out, "48");
                    break;
        case('I'):        strcpy(hex_out, "49");
                    break;
        case('J'):        strcpy(hex_out, "4A");
                    break;
        case('K'):        strcpy(hex_out, "4B");
                    break;
        case('L'):        strcpy(hex_out, "4C");
                    break;
        case('M'):        strcpy(hex_out, "4D");
                    break;
        case('N'):        strcpy(hex_out, "4E");
                    break;
        case('O'):        strcpy(hex_out, "4F");
                    break;
        case('P'):        strcpy(hex_out, "50");
                    break;
        case('Q'):        strcpy(hex_out, "51");
                    break;
        case('R'):        strcpy(hex_out, "52");
                    break;
        case('S'):        strcpy(hex_out, "53");
                    break;
        case('T'):        strcpy(hex_out, "54");
                    break;
        case('U'):        strcpy(hex_out, "55");
                    break;
        case('V'):        strcpy(hex_out, "56");
                    break;
        case('W'):        strcpy(hex_out, "57");
                    break;
        case('X'):        strcpy(hex_out, "58");
                    break;
        case('Y'):        strcpy(hex_out, "59");
                    break;
        case('Z'):        strcpy(hex_out, "5A");
                    break;
		case('['):        strcpy(hex_out, "5B");
                    break;
		case(']'):        strcpy(hex_out, "5D");
                    break;
		case('^'):        strcpy(hex_out, "5E");
                    break;
		case('_'):        strcpy(hex_out, "5F");
                    break;
		case('\n'):        strcpy(hex_out, "20");
                    break;
		case('\0'):        strcpy(hex_out, "20");
                    break;
        default:    strcpy(hex_out, "00");
			printf("invalid char?: %c", c);
                    break;
    }
    
    return hex_out;
}
