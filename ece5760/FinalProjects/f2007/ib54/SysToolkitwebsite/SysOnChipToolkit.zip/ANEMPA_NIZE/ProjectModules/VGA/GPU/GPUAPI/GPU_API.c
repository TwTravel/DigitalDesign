#include "GPU_API.h"
#include "math.h"

struct LineSegment CreateLine(int iX1, int iY1, int iX2, int iY2, unsigned char cColor)
{
    struct LineSegment l;
    float dx = iX2 - iX1;
    float dy = iY2 - iY1;
    l.mag = sqrt(dx*dx + dy*dy);
    
    // Unit Vector and Normal Vector
    l.u_x = dx / l.mag;
    l.u_y = dy / l.mag;
    l.n_x =  -1*(float)(dy / l.mag);
    l.n_y = (float)(dx / l.mag);
    
    l.x1 = iX1;
    l.y1 = iY1;
    l.x2 = iX2;
    l.y2 = iY2;
    l.color = cColor;
    
    return l;   
}


void DrawLine(int iX1, int iY1, int iX2, int iY2, unsigned char cColor)
{
    // Set the different X, Y pairs
    // Set X1
    *GPUInterface = SETX1 + iX1;
    *GPU_Valid = 1;
    while(1) {if(*GPU_Complete) break; }
    *GPU_Valid = 0;
    // Set Y1
    *GPUInterface = SETY1 + iY1;
    *GPU_Valid = 1;
    while(1) {if(*GPU_Complete) break; }
    *GPU_Valid = 0;
    // Set X2
    *GPUInterface = SETX2 + iX2;
    *GPU_Valid = 1;
    while(1) {if(*GPU_Complete) break; }
    *GPU_Valid = 0;
    // Set Y2
    *GPUInterface = SETY2 + iY2;
    *GPU_Valid = 1;
    while(1) {if(*GPU_Complete) break; }
    *GPU_Valid = 0;
    // Draw Line
    *GPUInterface = DRAWLINE + (int)cColor;
    *GPU_Valid = 1;

    // Wait until GPU Complete
    while(1) {if(*GPU_Complete) break; }
    // Then lower valid bit
    *GPU_Valid = 0;
    *GPUInterface = 0;
}

void DrawLineStruct(struct LineSegment l)
{
    DrawLine(l.x1, l.y1, l.x2, l.y2, l.color);    
}

// These should eventually be handled through Bresenham in the future
void DrawVLine(int iX, int iY, int iLength, unsigned char cColor)
{
    int i = 0;
    for(i=0;i<iLength;i++)
    {
        PlotPixel(iX, iY + i, cColor);    
    }    
}
void DrawHLine(int iX, int iY, int iLength, unsigned char cColor)
{
    int i = 0;
    for(i=0;i<iLength;i++)
    {
        PlotPixel(iX + i, iY, cColor);    
    }    
}

void DrawChar(int iX, int iY, char cChar, unsigned char cColor)
{
    // Set the different X, Y pairs
    // Set X1
    *GPUInterface = SETX1 + iX;
    *GPU_Valid = 1;
    while(1) {if(*GPU_Complete) break; }
    *GPU_Valid = 0;
    
    // Set Y1
    *GPUInterface = SETY1 + iY;
    *GPU_Valid = 1;
    while(1) {if(*GPU_Complete) break; }
    *GPU_Valid = 0;
    
    // Set Char
    *GPUInterface = SETCHAR + cChar;
    *GPU_Valid = 1;
    while(1) {if(*GPU_Complete) break; }
    *GPU_Valid = 0;
    
    // Draw Line
    *GPUInterface = DRAWCHAR + (int)cColor;
    *GPU_Valid = 1;
    // Wait until GPU Complete
    while(1) {if(*GPU_Complete) break; }
    // Then lower valid bit
    *GPU_Valid = 0;
    *GPUInterface = 0;
}

void DrawText(int iX, int iY, char *pszString, int cchLength, unsigned char cColor)
{
    // Note that characters are 3 pixels wide so we simply draw cchLength chars
    int X = iX;
    int i = 0;
    
    for(i = 0; i < cchLength; i++)
    {
        DrawChar(X, iY, pszString[i], cColor); 
        X = X + 4;
    }   
}

void DrawTextNumber(int iX, int iY, int Num, unsigned char cColor)
{
    int temp = Num;
    int X = iX;
    int div = 10000;
    int i = 0;
    for(i=0;i<5;i++)
    {
        DrawChar(X, iY, 0x30 + (Num / div), cColor);
        Num = Num - (Num / div)*div;
        div = div / 10;
        X = X + 4;
    }     
}

void PlotPixel(int iX, int iY, unsigned char cColor)
{
    // Set the different X, Y pairs
    // Set X1
    *GPUInterface = SETX1 + iX;
    *GPU_Valid = 1;
    while(1) {if(*GPU_Complete) break; }
    *GPU_Valid = 0;
    
    // Set Y1
    *GPUInterface = SETY1 + iY;
    *GPU_Valid = 1;
    while(1) {if(*GPU_Complete) break; }
    *GPU_Valid = 0;
    
    // Draw Pixel
    *GPUInterface = DRAWPIXEL + (int)cColor;
    *GPU_Valid = 1;
    // Wait until GPU Complete
    while(1) {if(*GPU_Complete) break; }
    // Then lower valid bit
    *GPU_Valid = 0;
    //*GPUInterface = 0;
} 

void ClearScreen()
{
    // Clear Screen
    *GPUInterface = CLEAR;
    *GPU_Valid = 1;
    // Wait until GPU Complete
    while(1) {if(*GPU_Complete) break; }
    // Then lower valid bit
    *GPU_Valid = 0;
    *GPUInterface = 0;    
}

// For now this will just be a circle of fixed radius 3
void DrawCircle(int iX, int iY, unsigned char cColor)
{
    // Right
    PlotPixel(iX + 3, iY + 1, cColor);
    PlotPixel(iX + 3, iY, cColor);
    PlotPixel(iX + 3, iY - 1, cColor);
    PlotPixel(iX + 2, iY + 2, cColor);
    // Left 
    PlotPixel(iX - 3, iY + 1, cColor);
    PlotPixel(iX - 3, iY, cColor);
    PlotPixel(iX - 3, iY - 1, cColor);
    PlotPixel(iX + 2, iY - 2, cColor);  
    // Top
    PlotPixel(iX - 1, iY - 3, cColor);
    PlotPixel(iX, iY - 3, cColor);
    PlotPixel(iX + 1, iY - 3, cColor);
    PlotPixel(iX - 2, iY + 2, cColor);
    // Bottom
    PlotPixel(iX - 1, iY + 3, cColor);
    PlotPixel(iX, iY + 3, cColor);
    PlotPixel(iX + 1, iY + 3, cColor);
    PlotPixel(iX - 2, iY - 2, cColor);  
}

