/***************************************************
* Network Driven Microprocessor Architecture Reference
* Credit: Idan Beck, spring 2007 Cornell Univeristy
* (Verilog Mode Header)
****************************************************/

`define TICK 		#1

`define		true    1'b1
`define 	false   1'b0

`define     dc		1'bx
`define 	dc5		5'bxxxxx
`define 	dc6		6'bxxxxxx

// Instruction fields of 32 bit instructions

`define 	op 			31:26		// 6 bit operation field
`define		function	5:0			// 6 bit function field
`define 	rs 			25:21		// 5 bit source register field
`define 	rt 			20:16		// 5 bit target register field
`define 	rd 			15:11		// 5 bit destination register field
`define 	immediate	15:0		// 16 bit signed immediate
`define 	target		25:0		// 26 bit indext shifted left (target address for jumps)
`define 	sa			10:6		// 5 bit shift amount

// Instruction types

// I type
//  ____________________________________________
// | op * 6 | rs * 5 | rt * 5  | immediate * 16 |
// template
// opopoprssssrttttimmediateimmedia

// J type
//  _____________________
// | op * 6 | target * 26|
// template
// opopoptargettargettargettargetta

// R type
//  ___________________________________________________________
// | op * 6 | rs * 5 | rt * 5 | rd * 5 | sa * 5 | function * 6 |
// template:
// opopoprssssrttttrddddsaaaafuncti

// Register names

`define r0 		5'b00000
`define r1		5'b00001
`define r2		5'b00010
`define r3		5'b00011
`define r4		5'b00100
`define r5		5'b00101
`define r6		5'b00110
`define r7		5'b00111
`define r8		5'b01000
`define r9		5'b01001
`define r10		5'b01010
`define r11		5'b01011
`define r12		5'b01100
`define r13		5'b01101
`define r14		5'b01110
`define r15		5'b01111
`define r16		5'b10000
`define r17		5'b10001
`define r18		5'b10010
`define r19		5'b10011
`define r20		5'b10100
`define r21		5'b10101
`define r22		5'b10110
`define r23		5'b10111
`define r24		5'b11000
`define r25		5'b11001
`define r26		5'b11010
`define r27		5'b11011
`define r28		5'b11100
`define r29		5'b11101
`define r30		5'b11110
`define r31		5'b11111

// Symbollic Register names (assembler / compiler)

`define zero 	5'b00000
`define at		5'b00001
`define v0		5'b00010
`define v1		5'b00011
`define a0		5'b00100
`define a1		5'b00101
`define a2		5'b00110
`define a3		5'b00111
`define t0		5'b01000
`define t1		5'b01001
`define t2		5'b01010
`define t3		5'b01011
`define t4		5'b01100
`define t5		5'b01101
`define t6		5'b01110
`define t7		5'b01111
`define s0		5'b10000
`define s1		5'b10001
`define s2		5'b10010
`define s3		5'b10011
`define s4		5'b10100
`define s5		5'b10101
`define s6		5'b10110
`define s7		5'b10111
`define t8		5'b11000
`define t9		5'b11001
`define k0		5'b11010
`define k1		5'b11011
`define gp		5'b11100
`define sp		5'b11101
`define s8		5'b11110
`define ra		5'b11111

// Opcode Assignments for `op Operations

`define	SPECIAL		6'b000000
`define	REGIMM		6'b000001

// Jump! and Branch!
`define	J			6'b000010
`define	JAL			6'b000011
`define	BEQ			6'b000100
`define	BNE			6'b000101
`define	BLEZ		6'b000110
`define	BGTZ		6'b000111

`define BLTZ		6'b010100
`define BGEZ		6'b010101

`define	ADDI		6'b001000
`define	ADDIU		6'b001001
`define	SLTI		6'b001010
`define	SLTIU		6'b001011
`define	ANDI		6'b001100
`define	ORI			6'b001101
`define	XORI		6'b001110
`define	LUI			6'b001111

// OUTI instrction
`define OUTI		6'b010110

//`define	COP0		6'b010000	// No Coprocessor
//`define	COP1		6'b010001
//`define	COP2		6'b010010
//`define	COP3		6'b010011
//`define	BEQL		6'b010100 	// No Delay slots in this architecture
//`define	BNEL		6'b010101
//`define	BLEZL		6'b010110
`define	BGTZL		6'b010111

`define	LB			6'b100000
`define	LH			6'b100001
//`define	LWL			6'b100010		// Do not allow unaligned
`define	LW			6'b100011
`define	LBU			6'b100100
`define	LHU			6'b100101
//`define	LWR			6'b100110		// Do not allow unaligned

`define	SB			6'b101000
`define	SH			6'b101001
//`define	SWL			6'b101010		// Do not allow unaligned
`define	SW			6'b101011

`define	SWR			6'b101110
`define	CACHE		6'b101111

/****************************************
* Added the Network Stuff Here
* network ISA is an I type function
* These are the following instructions:
*
* Send Msg:  SMSG dest, Data
* **************************************
* This instruction dispatches a message with the given data
* to the network layer
*
* Recieve Msg: RMSG dest, listen style, data
* **************************************
* This will make the processor wait until a message is obtained
* in accordance with the listening style.  The possible styles:
* 0 - any message is recieved (l_any	00000)
* 1	- message from specific id	(l_id	00001)
* 2 - message from specific id and specific data	(l_idD	00010)
* 3 - message of specific data						(l_D	00011)
* 4 - message from specific id/data from north		(l_idDN 00100)
* 5 -  **************************   from south		(l_idDS 00101)
* 6 -  **************************   from east		(l_idDE 00110)
* 7 -  **************************	from west		(l_idDW 00111)
*
* Set ID:	SID	id_number
* **************************************
* This will set the node id of the cpu both in the CPU
* and in the network layer
*
*/

`define NET_MEM_START 127

`define SMSG		6'b110000
`define RMSG		6'b110001
`define SID			6'b110010
// defined listening styles
`define l_any		5'b00000
`define l_id		5'b00001
`define l_D			5'b00010
`define l_idDN		5'b00100
`define l_idDS		5'b00101
`define l_idDE		5'b00110
`define l_idDW		5'b00111



/*****************************************
* Removed this from the ISA since we dont
* really use it anyways
******************************************/
/*
`define	LL			6'b110000
`define	LWC1		6'b110001
`define	LWC2		6'b110010
`define	LWC3		6'b110011

`define	LDC1		6'b110101
`define	LDC2		6'b110110
`define	LDC3		6'b110111

`define	SC			6'b111000
`define	SWC1		6'b111001
`define	SWC2		6'b111010
`define	SWC3		6'b111011

`define	SDC1		6'b111101
`define	SDC2		6'b111110
`define	SDC3		6'b111111
//****************************************/

// Opcode Assignments for `SPECIAL function Operations

`define	SLL			6'b000000
`define	SRL			6'b000010
`define	SRA			6'b000011
`define	SLLV		6'b000100
`define	SRLV		6'b000110
`define	SRAV		6'b000111

`define	JR			6'b001000
`define	JALR		6'b001001

`define	SYSCALL		6'b001100
`define	BREAK		6'b001101

`define	MFHI		6'b010000
`define	MTHI		6'b010001
`define	MFLO		6'b010010
`define	MTLO		6'b010011

`define	MULT		6'b011000
`define	MULTU		6'b011001
`define	DIV			6'b011010
`define	DIVU		6'b011011
`define MOD			6'b110010

`define	ADD			6'b100000
`define	ADDU		6'b100001
`define	SUB			6'b100010
`define	SUBU		6'b100011
`define	AND			6'b100100
`define	OR			6'b100101
`define	XOR			6'b100110
`define	NOR			6'b100111

`define	SLT			6'b101010
`define	SLTU		6'b101011

// IN OUT Instructions
`define IN			6'b110000
`define OUT			6'b110001

//`define	TGE			6'b110000
//`define	TGEU		6'b110001
//`define	TLT			6'b110010
`define	TLTU		6'b110011
`define	TEQ			6'b110100

`define	TNE			6'b110110

// Opcode Assignments for `REGIMM rt Operations

//`define	BLTZ		5'b00000
//`define	BGEZ		5'b00001
`define	BLTZL		5'b00010
`define	BGEZL		5'b00011

`define	TGEI		5'b01000
`define	TGEIU		5'b01001
`define	TLTI		5'b01010
`define	TLTIU		5'b01011
`define	TEQI		5'b01100

`define	TNEI		5'b01110

`define	BLTZAL		5'b10000
`define	BGEZAL		5'b10001
`define	BLTZALL		5'b10010
`define	BGEZALL		5'b10011


// Opcode Assignments for `COPz rs Operations

`define	MF			5'b00000
`define	CF			5'b00010
`define	MT			5'b00100
`define	CT			5'b00110

`define	BC			5'b01000

// Opcode Assignments for `COPz rt Operations

`define	BCF			5'b00000
`define	BCT			5'b00001
`define	BCFL		5'b00010
`define	BCTL		5'b00011

// Possible pc Selects

`define pc_sel_nex		5'b00000
`define pc_sel_jmp		5'b00001
`define pc_sel_br		5'b00010
`define pc_sel_jmp_reg	5'b00011

// Possible ALU operations

`define alu_add			5'b00000
`define alu_sub			5'b00001
`define alu_or			5'b00010
`define alu_and			5'b00011
`define alu_xor			5'b00100
`define alu_nor			5'b00101
`define alu_slt			5'b00110
`define alu_sltu		5'b00111
`define alu_sll			5'b01000
`define alu_srl			5'b01001
`define alu_sra			5'b01010
`define alu_mult		5'b01011
`define alu_multu		5'b01100
`define alu_div			5'b01101
`define	alu_divu		5'b01110
`define alu_mod			5'b01111

// Network Layer Defines
// We have 4 directions (this is technically scalable)
/*****************************************************
* Message is 32 bits:
*  8 bit Destination ID
*  8 bit Message
*  8 bit Origination ID
*  4 bit Age
*  2 bit origin dispatch direction
*  2 bit last taken direction
******************************************************/

`define delay			#10

`define north			2'b00
`define south			2'b01
`define east			2'b10
`define west			2'b11

`define dest_id			31:24
`define msg_data		23:16
`define origin_id		15:8
`define msg_age			 7:4
`define o_dir		 	 3:2
`define l_dir			 1:0

`define OptVal			10


// PLI Decode Routine
