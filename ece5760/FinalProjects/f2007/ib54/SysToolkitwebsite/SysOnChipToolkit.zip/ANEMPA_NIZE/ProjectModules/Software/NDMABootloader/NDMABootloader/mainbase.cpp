// This is a (hopefully) simple bootloader application
// which takes an input as a .mem file from the NDMA 
// assembler and then sends it out to RS-232 port to
// be received by the NDMA CPU's boot loader module

// Usage:
// NDMABootLoad COM# filename.mem
//  # is the COM port number (such as COM4)
//  filename.mem is the mem file to boot load from the NDMA assembler

#include <windows.h>
#include <AtlBase.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define DELAY_MS 15

// Declerations
HRESULT InitPort(HANDLE *phComPort, char *pszPortName);
BOOL TransmitInstruction(HANDLE hComPort, unsigned long int PC, unsigned long int Ins);
BOOL EndTransmit(HANDLE hComPort);

int main(int argc, char *argv[])
{
    if(argc < 3 || strlen(argv[1]) == 0 || strlen(argv[2]) == 0)
    {
        printf("Usage: NDMABootLoad COM# filename.mem\n");
        printf("# - Com Port Number\n");
        printf("filename.mem - memfile to boot load from the NDMA assembler\n");
        system("PAUSE");
        return 0;
    }

    FILE *fileInput;
    fileInput = fopen(argv[2], "r");

    if(fileInput == NULL)
    {
        printf("Error Opening File: %s\n", argv[2]);
        perror("Error");
        system("PAUSE");
        return 0;
    }

    HANDLE hComPort = NULL;
    
    // Transmitting
    DWORD dwBytesWritten;
    DWORD dwBytesToWrite;
    char szWriteString[40];

    // Receiving
    DWORD dwBytesRead;
    char szReadString[40];
    DWORD dwEventMask = NULL;

    // PC
    unsigned long int PC = 0;
    // Ins
    unsigned long int Ins;
    // Ins In
    char input[100];
    BOOL fDone = FALSE;

    
    if(InitPort(&hComPort, argv[1]) != S_OK)
    {
        printf("Failed to Initialize Port %s\n", argv[1]);
        return E_FAIL;
    }

    // Send Boot Command    
    strcpy(szWriteString, "boot");
    dwBytesToWrite = strlen(szWriteString);
    
    if(!WriteFile(hComPort, szWriteString, dwBytesToWrite, &dwBytesWritten, NULL))
    {
        printf("Failed to write %s to Com Port\n", szWriteString);
    }

    // Give the data a millasecond to arrive
    Sleep(DELAY_MS*10);

    // Wait for boot ready command        
    while(dwEventMask == NULL)
    {
        WaitCommEvent(hComPort, &dwEventMask, NULL);
    }    

    memset(szReadString, 0, sizeof(szReadString));
    if(!(::ReadFile(hComPort, szReadString, sizeof(szReadString), &dwBytesRead, NULL)))
    {
        printf("Failed to read Com Port\n");
    }

    if(strcmp(szReadString, "ready") == 0)
    {
        printf("Boot Loader Ready...\n");
    }
    else
    {
        printf("Boot Loader Cannot Initialize!\n");
        printf("Please Reset Machine\n");
        fclose(fileInput);
        fDone = TRUE;
        system("PAUSE");
        return 0;
    }
    // Give it a moment to recover
    Sleep(DELAY_MS*5);

    // PARSE FILE
    // ********************************
    PC = 0;
    while(fDone != TRUE)
    {
        fgets(input, 100, fileInput);
        if(feof(fileInput))
        {
            fDone = TRUE;
        }
        
        Ins = 0;

        for(int i = 0; i < 32; i++)
        {
            if(input[i] == '1')
            {
                Ins += (double)pow((double)2, (int)(31 - i));
            }
        }

        if(!TransmitInstruction(hComPort, PC, Ins))
        { 
            printf("BootLoader Error!\n");
            printf("Please Reset Machine\n");
            fclose(fileInput);
            fDone = TRUE;
            system("PAUSE");
            return 0;
        }
        PC++;
    }   

    (void)EndTransmit(hComPort);    
    
    fclose(fileInput);    
    //system("PAUSE");

    return 0;
}

BOOL TransmitInstruction(HANDLE hComPort, unsigned long int PC, unsigned long int Ins)
{
    // Transmitting
    DWORD dwBytesWritten;
    DWORD dwBytesToWrite;
    char szWriteString[40];

    // Receiving
    DWORD dwBytesRead;
    char szReadString[40];
    DWORD dwEventMask = NULL;

    // PC
    unsigned long int cPC = 0;
    unsigned long int rPC;

    // Ins
    unsigned long int sIns;
    unsigned long int rIns;

    // Dispatch PC
    cPC = PC;
    memset(szWriteString, 0, sizeof(cPC));
    for(int i = 0; i < 4; i++)
    {
        //long int andor = 255 << 8*i;
        char result = (cPC >> 8*i) & 255;
        szWriteString[i] = result;
    }
    dwBytesToWrite = sizeof(cPC);
    if(!WriteFile(hComPort, szWriteString, dwBytesToWrite, &dwBytesWritten, NULL))
    {
        printf("Failed to write %s to Com Port\n", szWriteString);
        return FALSE;
    }

    // Receive back PC
    dwEventMask = NULL;        
    while(dwEventMask == NULL)
    {
        WaitCommEvent(hComPort, &dwEventMask, NULL);
    }

    // Give the data a millasecond to arrive
    Sleep(DELAY_MS);

    memset(szReadString, 0, sizeof(szReadString));
    if(!(::ReadFile(hComPort, szReadString, sizeof(szReadString), &dwBytesRead, NULL)))
    {
        printf("Failed to read Com Port\n");
        return FALSE;
    }

    rPC = 0;
    // Decode PC Out
    for(int i = 0; i < 4; i++)
    {
        rPC += ((unsigned long int)(unsigned char)szReadString[i] << 8*i);
    }
    // Compare PC values
    if(rPC == cPC)
    {
        printf("Matched PC:%u\n", rPC);
    }
    else
    {
        printf("Mismatch on PC out:%u in:%u\n", cPC, rPC);
        return FALSE;
    }
    // Wait a ms
    Sleep(DELAY_MS);

    // Dispatch Instruction
    sIns = Ins;
    memset(szWriteString, 0, sizeof(sIns));
    for(int i = 0; i < 4; i++)
    {
        //long int andor = 255 << 8*i;
        char result = (sIns >> 8*i) & 255;
        szWriteString[i] = result;
    }
    dwBytesToWrite = sizeof(sIns);
    if(!WriteFile(hComPort, szWriteString, dwBytesToWrite, &dwBytesWritten, NULL))
    {
        printf("Failed to write %s to Com Port\n", szWriteString);
        return FALSE;
    }    

    // Receive back Instruction
    dwEventMask = NULL;        
    while(dwEventMask == NULL)
    {
        WaitCommEvent(hComPort, &dwEventMask, NULL);
    }

    // Give the data a millasecond to arrive
    Sleep(DELAY_MS);

    memset(szReadString, 0, sizeof(szReadString));
    if(!(::ReadFile(hComPort, szReadString, sizeof(szReadString), &dwBytesRead, NULL)))
    {
        printf("Failed to read Com Port\n");
        return FALSE;
    }

    rIns = 0;
    // Decode Instruction Out
    for(int i = 0; i < 4; i++)
    {
        rIns += ((unsigned long int)(unsigned char)szReadString[i] << 8*i);
    }
    // Compare Instruction values
    if(rIns == sIns)
    {
        printf("Matched Ins:%x\n", rIns);
    }
    else
    {
        printf("Mismatch Ins out:%x in:%x\n", sIns, rIns);
        return FALSE;
    }
    // Wait a moment
    Sleep(DELAY_MS);

    return TRUE;
}

BOOL EndTransmit(HANDLE hComPort)
{
    // Transmitting
    DWORD dwBytesWritten;
    DWORD dwBytesToWrite;
    char szWriteString[40];

    // Receiving
    DWORD dwBytesRead;
    char szReadString[40];
    DWORD dwEventMask = NULL;

    // PC
    unsigned long int cPC = 0;
    unsigned long int rPC;
    
    // Send end transmit
    // Dispatch PC
    cPC = 0xffffffff;
    memset(szWriteString, 0, sizeof(cPC));
    for(int i = 0; i < 4; i++)
    {
        //long int andor = 255 << 8*i;
        char result = (cPC >> 8*i) & 255;
        szWriteString[i] = result;
    }
    dwBytesToWrite = sizeof(cPC);
    if(!WriteFile(hComPort, szWriteString, dwBytesToWrite, &dwBytesWritten, NULL))
    {
        printf("Failed to write %s to Com Port\n", szWriteString);
        return FALSE;
    }
    // Receive back PC
    dwEventMask = NULL;        
    while(dwEventMask == NULL)
    {
        WaitCommEvent(hComPort, &dwEventMask, NULL);
    }

    // Give the data a millasecond to arrive
    Sleep(DELAY_MS);

    memset(szReadString, 0, sizeof(szReadString));
    if(!(::ReadFile(hComPort, szReadString, sizeof(szReadString), &dwBytesRead, NULL)))
    {
        printf("Failed to read Com Port\n");
        return FALSE;
    }

    rPC = 0;
    // Decode PC Out
    for(int i = 0; i < 4; i++)
    {
        rPC += ((unsigned long int)(unsigned char)szReadString[i] << 8*i);
    }
    // Compare PC values
    if(rPC == cPC)
    {
        printf("Matched End Transmit PC:%x\n", rPC);
    }
    else
    {
        printf("Mismatch on End Transmit PC out:%u in:%u\n", cPC, rPC);
        return FALSE;
    }
    // Wait a ms
    Sleep(DELAY_MS);
    return TRUE;
}

HRESULT InitPort(HANDLE *phComPort, char *pszPortName)
{  
    OLECHAR* oleChar = NULL;
    oleChar = (OLECHAR*)calloc(strlen(pszPortName)+1, sizeof(OLECHAR));
    MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, pszPortName, -1, oleChar, strlen(pszPortName)+1);  
    BSTR bstrPortName = SysAllocString(oleChar);
    free(oleChar);
    oleChar = NULL;

    *phComPort = ::CreateFile((LPCWSTR)bstrPortName,
                               GENERIC_READ | GENERIC_WRITE,    // access (rw)
                               0,                               // share (no sharing)
                               0,                               // Security
                               OPEN_EXISTING,                   // Creation
                               0,                               // Overlapped Operation
                               0                                // No Template
                               );

    if(*phComPort == NULL || *phComPort == INVALID_HANDLE_VALUE)
    {
        printf("Could not open %s port, error:%d\n", pszPortName, GetLastError());
        if(GetLastError() == ERROR_ACCESS_DENIED)
        {
            printf("Port %s Access Denied\n", pszPortName);
            return E_FAIL;
        }
        else if(GetLastError() == ERROR_FILE_NOT_FOUND)
        {
            printf("Port %s Does Not Exist\n", pszPortName);
            return E_FAIL;
        }
    }

    // Set Up Com Port State with Device Control Block
    DCB dcb = {0};
    dcb.DCBlength = sizeof(DCB);
    if(!(::GetCommState(*phComPort, &dcb)))
    {
        printf("Failed to get Com Device State Error: %d\n", GetLastError());
        return E_FAIL;
    }

    dcb.BaudRate = CBR_115200;
    dcb.ByteSize = 8;
    dcb.Parity = NOPARITY;
    dcb.StopBits = ONESTOPBIT;

    if(!(::SetCommState(*phComPort, &dcb)))
    {
        printf("Failed to set Com Device State Error: %d\n", GetLastError());
        return E_FAIL;
    }

    // Register for Receive Events
    SetCommMask(*phComPort, EV_RXCHAR);
    
    // Print out settings
    printf("port %s connected\nBaud Rate: %d\nByte Size: %d\nStop Bits:%d\n", 
            pszPortName, dcb.BaudRate, dcb.ByteSize, dcb.StopBits);

    return S_OK;
}