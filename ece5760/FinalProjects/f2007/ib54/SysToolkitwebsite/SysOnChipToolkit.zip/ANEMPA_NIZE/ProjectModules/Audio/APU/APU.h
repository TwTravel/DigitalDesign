// Some APU defines that make the code easier to read

// Instruction Structure:
// 8 bits un-used for now 4 bit target 4 bit action

// DDS Unit Control Signals
`define target	7:4
`define AllWaves		4'b0000
`define Sine			4'b0001
`define Square			4'b0010
`define Saw				4'b0011
`define Triangle		4'b0100
`define Noise			4'b0101

`define action	3:0
`define WaveOff				4'b0000
`define WaveOn				4'b0001
`define SetWaveFrequency	4'b0010
`define SetWaveVolume		4'b0011

`define SetWaveAttack		4'b0100
`define SetWaveDecay		4'b0101
`define SetWaveSustain		4'b0110
`define SetWaveRelease		4'b0111

`define SetWaveDuration		4'b1000

`define SetWaveAdditive		4'b1000
`define SetWaveSubtractive	4'b1001

`define DDSFactor	91304
