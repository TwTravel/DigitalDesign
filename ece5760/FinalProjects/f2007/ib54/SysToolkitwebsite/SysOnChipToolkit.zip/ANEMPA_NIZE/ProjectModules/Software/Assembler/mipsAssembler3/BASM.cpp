#include "BASM.h"

// Op Code Map
extern std::map<std::string, OPS> s_mapOP;

// 16 bit immediate converter (support for signed variables)
char* dTob(int input){
	  //int i, j, k;
	  int negFlag = 0;
	  char toutput[17];
	  char output[17];

	  if(input < 0)
      {
	  		   negFlag = 1;
	  		   input = (-1 * input) - 1;
      }

	  // do the first one for sake of string stuff
	  strcpy(toutput, "");

      while(input > 0) 
      {
	  			  if(input & 1 == 1)
                  {
                      if(negFlag) strcat(toutput, "0");
                      else strcat(toutput, "1");
                  }
			      else 
                  {
                      if(negFlag) strcat(toutput, "1");
                      else strcat(toutput, "0");
                  }
				  input >>= 1;
	  }

	  //output = new char[16];
      if(negFlag) memset(output, '1', sizeof(output));
      else memset(output, '0', sizeof(output));

	  output[16] = '\0';

	  for(int i = 15; i >= 0; i--)
      {
	  	  if(strlen(toutput) > (15 - i) ) output[i] = toutput[15 - i];
      }
	  output[16] = '\0';

	  return output;
}

// 26 bit immediate converter (unsigned only)

char* dTob26(int input){
	  int i, j, k;
	  int negFlag = 0;
	  char toutput[27];
	  char output[27];

	  if(input < 0){
	  		   negFlag = 1;
	  		   input = input*-1;
      }

	  // do the first one for sake of string stuff
	  if(input&1 == 1)strcpy(toutput, "1");
	  else strcpy(toutput, "0");
	  input >>= 1;

      while(input > 0) {
	  			  if(input&1 == 1)strcat(toutput, "1");
			      else strcat(toutput, "0");
				  input >>= 1;
	  }

	  //output = new char[16];
      memset(output, '0', sizeof(output));
	  output[26] = '\0';

	  for(i=25;i>=0;i--){
	  	  if(strlen(toutput) > (25 - i) ) output[i] = toutput[25 - i];
      }
	  output[26] = '\0';

	  return output;
}

// returns 16 bit hex number

char* hTob(char *hex){
	char toutput[17];
	char output [17];
	int len;

	memset(toutput, '\0', 17);
	for(len = 0;len < strlen(hex);len++) {
		switch(hex[len]) {
			case '0':	strcat(toutput, "0000");
						break;
			case '1':	strcat(toutput, "0001");
						break;
			case '2':	strcat(toutput, "0010");
						break;
			case '3':	strcat(toutput, "0011");
						break;
			case '4':	strcat(toutput, "0100");
						break;
			case '5':	strcat(toutput, "0101");
						break;
			case '6':	strcat(toutput, "0110");
						break;
			case '7':	strcat(toutput, "0111");
						break;
			case '8':	strcat(toutput, "1000");
						break;
			case '9':	strcat(toutput, "1001");
						break;
			case 'A':	strcat(toutput, "1010");
						break;
			case 'B':	strcat(toutput, "1011");
						break;
			case 'C':	strcat(toutput, "1100");
						break;
			case 'D':	strcat(toutput, "1101");
						break;
			case 'E':	strcat(toutput, "1110");
						break;
			case 'F':	strcat(toutput, "1111");
						break;
			case 'x':	if(len != 0) strcat(toutput, "xxxx");
						break;
			default:	strcat(toutput, "xxxx");
						break;
		}
	}

	toutput[16] = '\0';

	memset(output, '0', sizeof(output));
	output[16] = '\0';
	len = 0;
	for(int i=16 - strlen(toutput) ;i<16;i++){
	  	output[i] = toutput[len];
		len++;
    }
	output[16] = '\0';

	return output;
}

int RegDecode(char *pszReg, char *pszOut)
{
    if(pszReg == NULL)
    {   
        if(pszOut == NULL) 
        {
            return 0;
        }
        else
        {
            strcpy(pszOut, "00000");
            return 0;
        }
    }

    // Get rid of termination character
    char *tempy = strtok(pszReg, "\n");
    
    if(     strcmp(tempy, "$0") == 0  || strcmp(tempy, "$zero") == 0 ) strncpy(pszOut, dTob(0)+11, 5);
    else if(strcmp(tempy, "$1") == 0  || strcmp(tempy, "$at") == 0 )   strncpy(pszOut, dTob(1)+11, 5);
    else if(strcmp(tempy, "$2") == 0  || strcmp(tempy, "$v0") == 0 )   strncpy(pszOut, dTob(2)+11, 5);
    else if(strcmp(tempy, "$3") == 0  || strcmp(tempy, "$v1") == 0 )   strncpy(pszOut, dTob(3)+11, 5);
    else if(strcmp(tempy, "$4") == 0  || strcmp(tempy, "$a0") == 0 )   strncpy(pszOut, dTob(4)+11, 5);
    else if(strcmp(tempy, "$5") == 0  || strcmp(tempy, "$a1") == 0 )   strncpy(pszOut, dTob(5)+11, 5);
    else if(strcmp(tempy, "$6") == 0  || strcmp(tempy, "$a2") == 0 )   strncpy(pszOut, dTob(6)+11, 5);
    else if(strcmp(tempy, "$7") == 0  || strcmp(tempy, "$a3") == 0 )   strncpy(pszOut, dTob(7)+11, 5);
    else if(strcmp(tempy, "$8") == 0  || strcmp(tempy, "$t0") == 0 )   strncpy(pszOut, dTob(8)+11, 5);
    else if(strcmp(tempy, "$9") == 0  || strcmp(tempy, "$t1") == 0 )   strncpy(pszOut, dTob(9)+11, 5);
    else if(strcmp(tempy, "$10") == 0 || strcmp(tempy, "$t2") == 0 )   strncpy(pszOut, dTob(10)+11, 5);
    else if(strcmp(tempy, "$11") == 0 || strcmp(tempy, "$t3") == 0 )   strncpy(pszOut, dTob(11)+11, 5);
    else if(strcmp(tempy, "$12") == 0 || strcmp(tempy, "$t4") == 0 )   strncpy(pszOut, dTob(12)+11, 5);
    else if(strcmp(tempy, "$13") == 0 || strcmp(tempy, "$t5") == 0 )   strncpy(pszOut, dTob(13)+11, 5);
    else if(strcmp(tempy, "$14") == 0 || strcmp(tempy, "$t6") == 0 )   strncpy(pszOut, dTob(14)+11, 5);
    else if(strcmp(tempy, "$15") == 0 || strcmp(tempy, "$t7") == 0 )   strncpy(pszOut, dTob(15)+11, 5);
    else if(strcmp(tempy, "$16") == 0 || strcmp(tempy, "$s0") == 0 )   strncpy(pszOut, dTob(16)+11, 5);
    else if(strcmp(tempy, "$17") == 0 || strcmp(tempy, "$s1") == 0 )   strncpy(pszOut, dTob(17)+11, 5);
    else if(strcmp(tempy, "$18") == 0 || strcmp(tempy, "$s2") == 0 )   strncpy(pszOut, dTob(18)+11, 5);
    else if(strcmp(tempy, "$19") == 0 || strcmp(tempy, "$s3") == 0 )   strncpy(pszOut, dTob(19)+11, 5);
    else if(strcmp(tempy, "$20") == 0 || strcmp(tempy, "$s4") == 0 )   strncpy(pszOut, dTob(20)+11, 5);
    else if(strcmp(tempy, "$21") == 0 || strcmp(tempy, "$s5") == 0 )   strncpy(pszOut, dTob(21)+11, 5);
    else if(strcmp(tempy, "$22") == 0 || strcmp(tempy, "$s6") == 0 )   strncpy(pszOut, dTob(22)+11, 5);
    else if(strcmp(tempy, "$23") == 0 || strcmp(tempy, "$s7") == 0 )   strncpy(pszOut, dTob(23)+11, 5);
    else if(strcmp(tempy, "$24") == 0 || strcmp(tempy, "$t8") == 0 )   strncpy(pszOut, dTob(24)+11, 5);
    else if(strcmp(tempy, "$25") == 0 || strcmp(tempy, "$t9") == 0 )   strncpy(pszOut, dTob(25)+11, 5);
    else if(strcmp(tempy, "$26") == 0 || strcmp(tempy, "$k0") == 0 )   strncpy(pszOut, dTob(26)+11, 5);
    else if(strcmp(tempy, "$27") == 0 || strcmp(tempy, "$k1") == 0 )   strncpy(pszOut, dTob(27)+11, 5);
    else if(strcmp(tempy, "$28") == 0 || strcmp(tempy, "$gp") == 0 )   strncpy(pszOut, dTob(28)+11, 5);
    else if(strcmp(tempy, "$29") == 0 || strcmp(tempy, "$sp") == 0 )   strncpy(pszOut, dTob(29)+11, 5);
    else if(strcmp(tempy, "$30") == 0 || strcmp(tempy, "$s8") == 0 )   strncpy(pszOut, dTob(30)+11, 5);
    else if(strcmp(tempy, "$31") == 0 || strcmp(tempy, "$ra") == 0 )   strncpy(pszOut, dTob(31)+11, 5);
    
    // Cap pszReg
    pszOut[5] = '\0';

    return 1;
}

void InitializeOPMap()
{
    // Memory Ops
    s_mapOP["lw"] = OP_LW;
    s_mapOP["lh"] = OP_LH;
    s_mapOP["lhu"] = OP_LHU;
    s_mapOP["lb"] = OP_LB;
    s_mapOP["lbu"] = OP_LBU;
    s_mapOP["sw"] = OP_SW;
    s_mapOP["sh"] = OP_SH;
    s_mapOP["sb"] = OP_SB;

    // Immediate Ips
    s_mapOP["lui"] = OP_LUI;
    s_mapOP["addi"] = OP_ADDI;
    s_mapOP["addiu"] = OP_ADDIU;
    s_mapOP["slti"] = OP_SLTI;
    s_mapOP["sltiu"] = OP_SLTIU;
    s_mapOP["andi"] = OP_ANDI;
    s_mapOP["xori"] = OP_XORI;
    s_mapOP["ori"] = OP_ORI;
    s_mapOP["smsg"] = OP_SMSG;
    s_mapOP["rmsg"] = OP_RMSG;
    s_mapOP["sid"] = OP_SID;

    // R-Type Ops
    s_mapOP["add"] = OP_ADD;
    s_mapOP["addu"] = OP_ADDU;
    s_mapOP["sub"] = OP_SUB;
    s_mapOP["subu"] = OP_SUBU;
    s_mapOP["and"] = OP_AND;
    s_mapOP["or"] = OP_OR;
    s_mapOP["xor"] = OP_XOR;
    s_mapOP["slt"] = OP_SLT;
    s_mapOP["sltu"] = OP_SLTU;
    s_mapOP["sll"] = OP_SLL;
    s_mapOP["srl"] = OP_SRL;
    s_mapOP["sra"] = OP_SRA;

    // Branching
    s_mapOP["bne"] = OP_BNE;
    s_mapOP["beq"] = OP_BEQ;
    s_mapOP["bgtz"] = OP_BGTZ;
    s_mapOP["bgez"] = OP_BGEZ;
    s_mapOP["bltz"] = OP_BLTZ;
    s_mapOP["blez"] = OP_BLEZ;

    s_mapOP["j"] = OP_J;
    s_mapOP["jr"] = OP_JR;
    s_mapOP["jal"] = OP_JAL;

    // IN/OUT Instructions
    s_mapOP["in"] = OP_IN;
    s_mapOP["out"] = OP_OUT;
    s_mapOP["outi"] = OP_OUTI;

    // Mult Div Mod
    s_mapOP["mult"] = OP_MULT;
    s_mapOP["multu"] = OP_MULTU;
    s_mapOP["div"] = OP_DIV;
    s_mapOP["divu"] = OP_DIVU;
    s_mapOP["mod"] = OP_MOD;

    // Pseudo Instructions
    s_mapOP["la"] = OP_LA;

    // Control Ops
    // repeat with terminator for convinience on single argument ops
    s_mapOP["nop"]  = OP_NOP;
    s_mapOP["nop\n"] = OP_NOP;
    s_mapOP["break"] = OP_BREAK;
    s_mapOP["break\n"] = OP_BREAK;
    s_mapOP["quit"] = OP_QUIT;
    s_mapOP["quit\n"] = OP_QUIT;
}

int OpFunctionSADecode(char *AsmOp, char* OpCode, char* FunctionCode, char *SACode)
{
	int ins_type = NOT_TYPE;
    if(AsmOp == NULL)
	{
		return NOT_TYPE;
	}

    switch(s_mapOP[AsmOp])
            {
                // Memory Ops
                case OP_LW:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "100011");
                        ins_type = I_TYPE;  
                        break;
                    }

                case OP_LH:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "100001");
                        ins_type = I_TYPE;                       
                        break;
                    }

                case OP_LHU:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "100101");
                        ins_type = I_TYPE;                       
                        break;
                    }

                case OP_LB:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "100000");
                        ins_type = I_TYPE;
                        break;
                    }

                case OP_LBU:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "100100");
                        ins_type = I_TYPE;                        
                        break;
                    }

                case OP_SW:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "101011");
			            ins_type = I_TYPE;
                        break;
                    }

                case OP_SH:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "101001");
			            ins_type = I_TYPE;
                        break;
                    }

                case OP_SB:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "101000");
			            ins_type = I_TYPE;
                        break;
                    }

                // Immediate Ops
                case OP_LUI:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "001111");
			            ins_type = I_TYPE;
                        break;
                    }

                case OP_ADDI:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "001000");
			            ins_type = I_TYPE;
                        break;
                    }

                case OP_ADDIU:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "001001");
			            ins_type = I_TYPE;
                        break;
                    }

                case OP_SLTI:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "001010");
			            ins_type = I_TYPE;
                        break;
                    }

                case OP_SLTIU:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "001011");
			            ins_type = I_TYPE;
                        break;
                    }

                case OP_ANDI:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "001100");
			            ins_type = I_TYPE;
                        break;
                    }

                case OP_XORI:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "001110");
			            ins_type = I_TYPE;
                        break;
                    }

                case OP_ORI:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "001101");
			            ins_type = I_TYPE;
                        break;
                    }

                // ***** Pseudo Instructions *****
                case OP_LA:
                    {
                        // LA is just another encoding for addiu
                        if(OpCode != NULL) strcpy(OpCode, "001001");
			            ins_type = P_TYPE;
                        break;
                    }

                // ***** branching instructions ****
                case OP_BNE:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "000101");
                        ins_type = I_TYPE;
                        break;
                    }
                
                case OP_BEQ:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "000100");
                        ins_type = I_TYPE;
                        break;
                    }

                case OP_BGTZ:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "000111");
                        ins_type = I_TYPE;
                        break;
                    }

                case OP_BGEZ:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "010101");
                        ins_type = I_TYPE;
                        break;
                    }

                case OP_BLTZ:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "010100");
                        ins_type = I_TYPE;
                        break;
                    }

                case OP_BLEZ:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "000110");
                        ins_type = I_TYPE;
                        break;
                    }
                // ***** IN OUT INSTRUCTIONS *****
                case OP_OUTI:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "010110");
                        ins_type = I_TYPE;
                        break;
                    }

                case OP_IN:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "000000");
			            if(FunctionCode != NULL) strcpy(FunctionCode, "110000");
			            if(SACode != NULL) strcpy(SACode, "00000");
			            ins_type = R_TYPE;
                        break;
                    }

                case OP_OUT:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "000000");
			            if(FunctionCode != NULL) strcpy(FunctionCode, "110001");
			            if(SACode != NULL) strcpy(SACode, "00000");
			            ins_type = R_TYPE;
                        break;
                    }
                
                // ***** network level instructions ****
                case OP_SMSG:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "110000");
			            ins_type = I_TYPE;
                        break;
                    }

                case OP_RMSG:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "110001");
			            ins_type = I_TYPE;  
                        break;
                    }

                case OP_SID:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "110010");
			            ins_type = I_TYPE;   
                        break;
                    }

                // ********* R_TYPE ********************
                case OP_ADD:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "000000");
			            if(FunctionCode != NULL) strcpy(FunctionCode, "100000");
			            if(SACode != NULL) strcpy(SACode, "00000");
			            ins_type = R_TYPE;
                        break;
                    }

                case OP_ADDU:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "000000");
			            if(FunctionCode != NULL) strcpy(FunctionCode, "100001");
			            if(SACode != NULL) strcpy(SACode, "00000");
			            ins_type = R_TYPE;
                        break;
                    }

                case OP_SUB:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "000000");
			            if(FunctionCode != NULL) strcpy(FunctionCode, "100010");
			            if(SACode != NULL) strcpy(SACode, "00000");
			            ins_type = R_TYPE;
                        break;
                    }
                
                case OP_SUBU:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "000000");
			            if(FunctionCode != NULL) strcpy(FunctionCode, "100011");
			            if(SACode != NULL) strcpy(SACode, "00000");
			            ins_type = R_TYPE;
                        break;
                    }

                case OP_AND:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "000000");
			            if(FunctionCode != NULL) strcpy(FunctionCode, "100100");
			            if(SACode != NULL) strcpy(SACode, "00000");
			            ins_type = R_TYPE;
                        break;
                    }

                case OP_OR:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "000000");
			            if(FunctionCode != NULL) strcpy(FunctionCode, "100101");
			            if(SACode != NULL) strcpy(SACode, "00000");
			            ins_type = R_TYPE;
                        break;
                    }

                case OP_XOR:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "000000");
			            if(FunctionCode != NULL) strcpy(FunctionCode, "100110");
			            if(SACode != NULL) strcpy(SACode, "00000");
			            ins_type = R_TYPE;
                        break;
                    }

                case OP_SLT:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "000000");
			            if(FunctionCode != NULL) strcpy(FunctionCode, "101010");
			            if(SACode != NULL) strcpy(SACode, "00000");
			            ins_type = R_TYPE;
                        break;
                    }

                case OP_SLTU:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "000000");
			            if(FunctionCode != NULL) strcpy(FunctionCode, "101011");
			            if(SACode != NULL) strcpy(SACode, "00000");
			            ins_type = R_TYPE;
                        break;
                    }

                case OP_SLL:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "000000");
			            if(FunctionCode != NULL) strcpy(FunctionCode, "000000");
			            //if(SACode != NULL) strcpy(SACode, "00000");
			            ins_type = SR_TYPE;
                        break;
                    }

                case OP_SRL:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "000000");
			            if(FunctionCode != NULL) strcpy(FunctionCode, "000010");
			            //if(SACode != NULL) strcpy(SACode, "00000");
			            ins_type = SR_TYPE;
                        break;
                    }

                case OP_SRA:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "000000");
			            if(FunctionCode != NULL) strcpy(FunctionCode, "000011");
			            //if(SACode != NULL) strcpy(SACode, "00000");
			            ins_type = SR_TYPE;
                        break;
                    }

                // Mult Div Mod
                case OP_MULT:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "000000");
			            if(FunctionCode != NULL) strcpy(FunctionCode, "011000");
			            if(SACode != NULL) strcpy(SACode, "00000");
			            ins_type = R_TYPE;
                        break;
                    }

                case OP_MULTU:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "000000");
			            if(FunctionCode != NULL) strcpy(FunctionCode, "011001");
			            if(SACode != NULL) strcpy(SACode, "00000");
			            ins_type = R_TYPE;
                        break;
                    }

                case OP_DIV:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "000000");
			            if(FunctionCode != NULL) strcpy(FunctionCode, "011010");
			            if(SACode != NULL) strcpy(SACode, "00000");
			            ins_type = R_TYPE;
                        break;
                    }

                case OP_DIVU:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "000000");
			            if(FunctionCode != NULL) strcpy(FunctionCode, "011011");
			            if(SACode != NULL) strcpy(SACode, "00000");
			            ins_type = R_TYPE;
                        break;
                    }

                case OP_MOD:
                    {
                        if(OpCode != NULL) strcpy(OpCode, "000000");
			            if(FunctionCode != NULL) strcpy(FunctionCode, "110010");
			            if(SACode != NULL) strcpy(SACode, "00000");
			            ins_type = R_TYPE;
                        break;
                    }

                default:
                    {
                        printf("Error!: %s not recognized", AsmOp);
                        if(OpCode != NULL) strcpy(OpCode, "000000");
                        break;
                    }
            } // end switch(s_mapOP[arg[0]])

	return ins_type;
}