#include "BASM.h"

// Op Code Map
std::map<std::string, OPS> s_mapOP;

// Implement Label Data Structure
static std::map<std::string, int> s_mapLabel;

int main(int argc, char *argv[])
{
    int iTokenCount = 0;
    int fDone = 0;
    char input[100], output[40];
	char op[10], rs[6], rt[6], rd[6], sa[10];
	char function[10], immediate[20], target[35];
	int ins_type = 0;
	int rs_arg, rt_arg, rd_arg, op_arg, imm_arg, fn_arg, tar_arg;
    int sa_arg;
    int iPC = 0;
    int cLine = 0;

    // Data Storage
    int cData = 0;
    bool fUseLabel = false;

    // our delimiter in these cases is a ' '
    char delims[] = " ,()\t";
    char *temp = NULL;
	char filename[20];
    char **arg;

    // Check for valid input file parameter
    if(argc < 2 || strlen(argv[1]) == 0)
    {
        printf("No Input File Specified!\n");
        printf("Usage: assembler.exe filename.asm\n");
        system("PAUSE");
        return 0;
    }

	FILE *outputFile;
	FILE *inputFile;

	// Get Input File Name
    strcpy(filename, argv[1]);

    // Create Output File
	temp = strtok(argv[1], ".");
	strcat(temp, ".mem");

	outputFile = fopen(temp, "w");
	inputFile = fopen(filename, "r");

	if(inputFile == NULL)
    {
        perror("error opening file!");
    }
    if(outputFile == NULL)
    {
        perror("error opening/creating output file!");
    }

    // Initialize the Op Map
    (void) InitializeOPMap();

    // Need to scan through the input file for labels
    while(fDone != 1)
    {
        int i = 0;
        bool skip = false;
        char input2[100];
        char input3[100];
        fgets(input, 100, inputFile);
        strcpy(input2, input);
        strcpy(input3, input);

        if(feof(inputFile))
        {
            // Go back to start of file and get out of loop
            rewind(inputFile);
            fDone = 1;
            cLine = 0;
            iPC = 0;
        }
        else
        {
            char *temp2 = NULL;
            char *temp3 = NULL;

            temp2 = strtok(input, " ,()\t");            
            temp3 = strtok(input2, delims); 

            if( strcmp(temp3, "la") == 0  )
            {
                int i = 0;
                char la_args[8][40];
                while(temp3 != NULL)
                {
                    strcpy(la_args[i], temp3);
                    temp3 = strtok(NULL, delims);
                    i++;
                }
                if(i == 3)
                {
                    // first must check if label (labels must have letters?)
                    bool fLabel = false;
                    for(int j = 0; j < strlen(la_args[2]) - 1; j++)
                    {
                        if(la_args[2][j] < 48 || la_args[2][j] > 57)
                        {
                            fLabel = true;
                            break;
                        }
                    }
                    if(fLabel)
                    {
                        iPC += 2;
                    }
                    else
                    {
                        iPC++;
                    }
                }
                else
                {
                    iPC++;
                }
            }
            else if(temp2[0] != '\n')
            {
                temp2 = strtok(temp2, " \n");
                
                
                if(s_mapOP.count(temp2) != 0 || strcmp(temp2, ".SetStack") == 0 ||
                   strcmp(temp2, ".Boot") == 0 )
                {
                    iPC++;
                }
                else if( strcmp(temp2, ".byte") == 0 )
                {
                    iPC += 2;
                }
                
            }
            cLine++;
        }

        // check if label
        for(i = 0; i < strlen(input); i++)
        {
            if(input[i] == ':')
            {
                temp = strtok(input, " :");
                if(s_mapLabel.empty() || s_mapLabel.count(temp) == 0)
                {
                    printf("label: %s found at PC:%d Line: %d\n", temp, iPC, cLine++);
                    s_mapLabel[temp] = iPC;
                }
                else
                {
                    printf("%s label redefined at line: %d\n", temp, cLine);
                    system("PAUSE");
                    exit(0);
                }
                skip = true;
            }
        }
        if(skip) continue;
    }

    // Reset fDone
    fDone = 0;

    while (fDone != 1)
    {
        iTokenCount = 0;
        int i = 0;
        bool skip = false;
        fgets(input, 100, inputFile);

        if(feof(inputFile))
        {
            fDone = 1;
        }
        else
        {
            // increment line count
            cLine++;
        }

        iTokenCount = 0;

        // Quick and Dirty Token Count for allocation issues
        for(i = 0; i < strlen(input); i++)
        {
            if(input[i] == delims[0] || input[i] == delims[1] ||
               input[i] == delims[2] || input[i] == delims[3] ||
               input[i] == delims[4] )
            {
                iTokenCount++;
            }
        }

        if(iTokenCount == 0 && strlen(input) > 0)
        {
            iTokenCount = 1;
        }

	    temp = strtok(input, delims);
        i = 0;
        arg = new char*[iTokenCount];

        while(temp != NULL)
        {
			   arg[i] = new char[strlen(temp)];
			   strcpy(arg[i], temp);
			   temp = strtok(NULL, delims);
			   i++;
        } // end while

        // One Line Comments
        if(arg[0][0] == '#')
        {
            // skip the line
            continue;
        }

        // Directives
        if(arg[0][0] == '.')
        {
            // Store Directive in temp
            temp = strtok(arg[0], ".");
            if(strcmp(temp, "SetStack") == 0)
            {
                if(iTokenCount == 1)
                {
                    char *tempy = strtok(arg[1], "/n");
                    strcpy(immediate, dTob(atoi(tempy)));
                    printf("0011010000011101%s // ori $sp, $0, %d (SetStack)\n", immediate, atoi(tempy));
                    fprintf(outputFile, "0011010000011101%s // ori $sp, $0, %d (SetStack)\n", immediate, atoi(tempy));
                    iPC++;
                }
                else
                {
                    printf("Stack Size not designated\n");
                }
            }
            else if(strcmp(temp, "Boot") == 0)
            {
                if(iTokenCount == 1)
                {
                    int target_pc = 0;
                    
                    // Get PC of program entry point
                    strcpy(op, "000010");
			        ins_type = J_TYPE;

                    // Get rid of termination character
                    char *tempy = strtok(arg[1], "\n");

                    // Check for Label
                    if(s_mapLabel.count(tempy) != 0)
                    {
                        strcpy(target, dTob26(s_mapLabel[tempy]));
                        target_pc = s_mapLabel[tempy];
                    }
                    else
                    {
                        strcpy(target, dTob26(atoi(arg[1])));
                        target_pc = atoi(arg[1]);
                    }

			        strcpy(output, op);
			        strcat(output, target);
                    printf("%s // %s %s pc:%d\n", output, arg[0], arg[1], target_pc);
                    fprintf(outputFile, "%s // %s %s pc:%d\n", output, arg[0], arg[1], target_pc);
                    strcpy(immediate, dTob(atoi(tempy)));
                    iPC++;
                }
                else
                {
                    printf("Boot point not designated\n");
                }
            }
            else if(strcmp(temp, "byte") == 0)
            {
                if(iTokenCount == 1)
                {
                    // Two instructions required, load value into $1
                    // then store $1 into memory:
                    // ori $1, $0, value
                    // sw $1, cData($0)
                    // ori
                    // 001101 00000 00001 0000000000000101 // ori $1, $0, 5
                    // sw
                    // 101011 00000 00001 0000000000000100 // sw $1, 4($0)
                    
                    
                    // Get rid of termination character
                    char *tempy = strtok(arg[1], "\n");

                    strcpy(immediate, dTob(atoi(tempy)));
                    printf("0011010000000001%s // ori $1, $0, %d (.byte)\n", 
                           immediate, atoi(tempy));
                    fprintf(outputFile, "0011010000000001%s // ori $1, $0, %d (.byte)\n", 
                           immediate, atoi(tempy));

                    strcpy(immediate, dTob(cData));
                    printf("1010110000000001%s // sw $1, %d($0) (.byte)\n",
                            immediate, cData);
                    fprintf(outputFile, "1010110000000001%s // sw $1, %d($0) (.byte)\n",
                            immediate, cData);

                    
                    
                    //printf(".byte store:%d at %d\n", atoi(tempy), cData);
                    cData++;
                    iPC += 2;
                }
                else
                {
                    printf(".byte incorrect argument\n");
                }
            }


            continue;
        }

        // Now we need to split up the instructions into different types
        // start off left to right
        if(iTokenCount > 8) {
		       printf("Error: too many arguments %d\n", iTokenCount);
	    //} else if(iTokenCount == 4) {
		     // R type
		     //  ___________________________________________________________
		     // | op * 6 | rs * 5 | rt * 5 | rd * 5 | sa * 5 | function * 6 |
		     // template:
		     // opopoprssssrttttrddddsaaaafuncti

		     // op code


        }
        else if(iTokenCount < 8 && iTokenCount >= 2)
        {
             // I type
		     //  ____________________________________________
		     // | op * 6 | rs * 5 | rt * 5  | immediate * 16 |
		     // template
		     // opopoprssssrttttimmediateimmedia
		     // op code

		    // ************** I_TYPE ***************
            ins_type = OpFunctionSADecode(arg[0], op, function, sa);
            
            fUseLabel = false;

            if(ins_type == NOT_TYPE)
            {
                // Op Decode Failure
                printf("OP Decode Failure!\n");
                continue;
            }


		    if(ins_type == I_TYPE) {
			    if(s_mapOP[arg[0]] == OP_LUI || s_mapOP[arg[0]] == OP_SMSG ) {
				    imm_arg = 2;
			    }
                else
                {
                    imm_arg = 3;
                }
			    rs_arg = 2;
			    rt_arg = 1;


                if(s_mapOP[arg[0]] == OP_LW || 
                   s_mapOP[arg[0]] == OP_LH || s_mapOP[arg[0]] == OP_LHU ||
                   s_mapOP[arg[0]] == OP_LB || s_mapOP[arg[0]] == OP_LBU ||
                   s_mapOP[arg[0]] == OP_SW || 
                   s_mapOP[arg[0]] == OP_SH ||
                   s_mapOP[arg[0]] == OP_SB )
                {
                    imm_arg = 2;
                    rs_arg = 3;
                    rt_arg = 1;
                }
                else if(s_mapOP[arg[0]] == OP_BGTZ || s_mapOP[arg[0]] == OP_BGEZ ||
                        s_mapOP[arg[0]] == OP_BLTZ || s_mapOP[arg[0]] == OP_BLEZ ||
                        s_mapOP[arg[0]] == OP_OUTI )
                {
                    imm_arg = 2;
                    rs_arg = 1;
                }

		    } else if(ins_type == R_TYPE) {
			    if(s_mapOP[arg[0]] == OP_IN || s_mapOP[arg[0]] == OP_OUT )
                {
                    rd_arg = 1;
                    rs_arg = 2;
                    rt_arg = 2; // duplicate rs into rt since rt is dont care
                }
                else
                {
                    rs_arg = 2;
			        rt_arg = 3;
			        rd_arg = 1;
                }
			    //sa_arg = 4;
			    //fn_arg = 5;
            }
            else if(ins_type == SR_TYPE)
            {
		        rd_arg = 1;
                rs_arg = 2;
                rt_arg = 2;
                sa_arg = 3;
            }
            else if(ins_type == J_TYPE)
            {
                // J Type Instructions
		    }
            else if(ins_type == P_TYPE)
            {
                if(s_mapOP[arg[0]] == OP_LA)
                {
                    rt_arg = 1;
                    imm_arg = 2;
                    rs_arg = 3;
                }
            }

		    // RD only used for R and SR types
		    // sid doesnt have rs or rd
		    if(strcmp(arg[0], "sid") == 0)
            {
			    strcpy(rd, "00000");
		    }
            else if(ins_type == R_TYPE || ins_type == SR_TYPE)
            {
			    RegDecode(arg[rd_arg], rd);
		    }
            else
            {
                strcpy(rd, "00000");
            }
            // Cap the string
		    rd[5] = '\0';


	         // RS = 0 always for lui, smsg, sid
		    if(strcmp(arg[0], "lui") == 0 || strcmp(arg[0], "smsg") == 0 ||
		       strcmp(arg[0], "sid") == 0 || (s_mapOP[arg[0]] == OP_LA && iTokenCount <= 3)) 
            {
			    strcpy(rs, "00000");
		    } 
            else if(ins_type != J_TYPE) 
            {
                RegDecode(arg[rs_arg], rs);
		    }
            else
            {
                strcpy(rs, "00000");
            }
		    rs[5] = '\0';

	         // RT
		     if(strcmp(arg[0], "sid") == 0)
             {
			    strcpy(rt, "00000");
		     }
             else if(ins_type != J_TYPE)
             {
                RegDecode(arg[rt_arg], rt);
		     }
             else
             {
                 strcpy(rt, "00000");
             }
		     rt[5] = '\0';

	         // Immediate
             // only need to worry about labels for immediate
		     if(ins_type == I_TYPE || ins_type == P_TYPE)
             {
			     // Get rid of termination character
                 char *tempy = strtok(arg[imm_arg], "\n");

                 if(s_mapLabel.count(tempy) > 0)
                 {
                     int target_pc;
                     if( s_mapOP[arg[0]] == OP_BNE ||
                         s_mapOP[arg[0]] == OP_BEQ ||
                         s_mapOP[arg[0]] == OP_BGTZ ||
                         s_mapOP[arg[0]] == OP_BLEZ)
                     {
                        target_pc = s_mapLabel[tempy] - iPC;
                     }
                     else
                     {
                        fUseLabel = true;
                        target_pc = s_mapLabel[tempy];
                        strcpy(target, dTob26(target_pc));
                     }

                     strcpy(immediate, dTob(target_pc));
                     //printf("cur PC:%d br:%d\n", iPC, target_pc);
                 }
                 else if(arg[imm_arg][0] != 'x')
                 {
                     // Apparently we need to potentially tokenize
                     // the immediate string to handle operands
                     int operands[4];
                     int opcount = 0;
                     char imm_arg_cpy[20];

                     strcpy(imm_arg_cpy, arg[imm_arg]);

                     char *tempy = strtok(imm_arg_cpy, " +");

                     while(tempy != NULL)
                     {
                        operands[opcount] = atoi(tempy);
                        opcount++;
                        tempy = strtok(NULL, " +");
                     }
                     if(opcount == 1)
                     {
                        strcpy(immediate, dTob(atoi(imm_arg_cpy)));
                     }
                     else
                     {
                        int temp_imm = 0;
                        for(int i = 0; i < opcount; i++)
                        {
                            temp_imm += operands[i];
                        }
                        strcpy(immediate, dTob(temp_imm));
                     }
                 }
		         else
                 {
                     strcpy(immediate, hTob(arg[imm_arg]));
                 }
		     }
             else
             {
                 strcpy(immediate, "0000000000000000");
             }

             // Shift Amount
             if(ins_type == SR_TYPE)
             {
                char temp_sa[20];
                strcpy(temp_sa, dTob(atoi(arg[sa_arg])));
                for(int c = 0; c < 5; c++)
                {
                    sa[4 - c] = temp_sa[15 - c];
                }
             }
             else
             {
                strcpy(sa, "00000");
             }


		     if(ins_type == I_TYPE)
             {
			    strcpy(output, op);
			    strcat(output, rs);
			    strcat(output, rt);
			    strcat(output, immediate);
			    if(strcmp(arg[0], "lui") == 0 || strcmp(arg[0], "smsg") == 0 )
                {
				    printf("%s // %s %s, %s\n", output, arg[0], arg[1], arg[2]);
				    fprintf(outputFile, "%s // %s %s, %s\n", output, arg[0], arg[1], arg[2]);
                    iPC++;
                }
                else if(s_mapOP[arg[0]] == OP_LW || 
                        s_mapOP[arg[0]] == OP_LH || s_mapOP[arg[0]] == OP_LHU ||
                        s_mapOP[arg[0]] == OP_LB || s_mapOP[arg[0]] == OP_LBU ||
                        s_mapOP[arg[0]] == OP_SW || 
                        s_mapOP[arg[0]] == OP_SH ||
                        s_mapOP[arg[0]] == OP_SB )
                {
                    printf("%s // %s %s, %s(%s)\n", output, arg[0], arg[1], arg[2], arg[3]);
				    fprintf(outputFile, "%s // %s %s, %s(%s)\n", output, arg[0], arg[1], arg[2], arg[3]);
                    iPC++;
			    }
                else if(s_mapOP[arg[0]] == OP_BGTZ || s_mapOP[arg[0]] == OP_BGEZ ||
                        s_mapOP[arg[0]] == OP_BLTZ || s_mapOP[arg[0]] == OP_BLEZ ||
                        s_mapOP[arg[0]] == OP_OUTI )
                {
                    printf("%s // %s %s, %s\n", output, arg[0], arg[1], arg[2]);
				    fprintf(outputFile, "%s // %s %s, %s\n", output, arg[0], arg[1], arg[2]);
                    iPC++;
                }
                else
                {
				    printf("%s // %s %s, %s, %s\n", output, arg[0], arg[1], arg[2], arg[3]);
				    fprintf(outputFile, "%s // %s %s, %s, %s\n", output, arg[0], arg[1], arg[2], arg[3]);
                    iPC++;
			    }
		     }
             else if(ins_type == P_TYPE)
             {
                strcpy(output, op);
		        strcat(output, rs);
		        strcat(output, rt);
                //strcat(output, "00000");
		        strcat(output, immediate);

                if(s_mapOP[arg[0]] == OP_LA && iTokenCount > 3)
                {    
                    printf("%s // %s %s, %s(%s)\n", output, arg[0], arg[1], arg[2], arg[3]);
				    fprintf(outputFile, "%s // %s %s, %s(%s)\n", output, arg[0], arg[1], arg[2], arg[3]);
                    iPC++;
                }
                if(s_mapOP[arg[0]] == OP_LA && iTokenCount == 3)
                {
                    if(fUseLabel == true)
                    {
                        // In case of Label use means we're loading in a
                        // data address so we jal and then save value into register
                        printf("000011%s // jal %s (data load)\n", target, arg[2]);
                        fprintf(outputFile, "000011%s // jal %s (data load)\n", target, arg[2]);
                        
                        printf("0000000000000001%s00000100000 // add %s, $0, $1 (data load)\n", rt, arg[1]);                        
                        fprintf(outputFile, "0000000000000001%s00000100000 // add %s, $0, $1 (data load)\n", rt, arg[1]);
                        iPC += 2;
                    }
                    else
                    {
                        printf("%s // %s %s, %s\n", output, arg[0], arg[1], arg[2]);
				        fprintf(outputFile, "%s // %s %s, %s\n", output, arg[0], arg[1], arg[2]);
                        iPC++; 
                    }
                    
                    //printf("%s // %s %s, %s\n", output, arg[0], arg[1], arg[2]);
				    //fprintf(outputFile, "%s // %s %s, %s\n", output, arg[0], arg[1], arg[2]);
                    //iPC++;
                }
             }
             else if(ins_type == SR_TYPE)
             {
                strcpy(output, op);
                strcat(output, rs);
                strcat(output, rt);
                strcat(output, rd);
                strcat(output, sa);
                strcat(output, function);
                printf("%s // %s %s, %s, %s", output, arg[0], arg[1], arg[2], arg[3]);
			    fprintf(outputFile, "%s // %s %s, %s, %s", output, arg[0], arg[1], arg[2], arg[3]);
                iPC++;
             }
             else if(ins_type = R_TYPE)
             {
			    strcpy(output, op);
			    strcat(output, rs);
			    strcat(output, rt);
			    strcat(output, rd);
			    strcat(output, sa);
			    strcat(output, function);
                if(s_mapOP[arg[0]] == OP_IN || s_mapOP[arg[0]] == OP_OUT)
                {
                    printf("%s // %s %s, %s\n", output, arg[0], arg[1], arg[2]);
			        fprintf(outputFile, "%s // %s %s, %s\n", output, arg[0], arg[1], arg[2]);
                    iPC++;
                }
                else
                {
			        printf("%s // %s %s, %s, %s\n", output, arg[0], arg[1], arg[2], arg[3]);
			        fprintf(outputFile, "%s // %s %s, %s, %s\n", output, arg[0], arg[1], arg[2], arg[3]);
                    iPC++;
                }
		     }
        }
        else if(iTokenCount == 2)
        {
            // J type
            //  _____________________
            // | op * 6 | target * 26|
            // template
            // opopoptargettargettargettargetta
            /*if(s_mapOP[arg[0]] == OP_LA)
            {
                strcpy(output, op);
			    strcat(output, rs);
			    strcat(output, rt);
                //strcat(output, "00000");
			    strcat(output, immediate);
                printf("%s // %s %s, %s\n", output, arg[0], arg[1], arg[2]);
				fprintf(outputFile, "%s // %s %s, %s\n", output, arg[0], arg[1], arg[2]);
                iPC++;
            }*/

		    printf("J Type instruction\n");
        }
        else if(iTokenCount == 1)
        {
		    
            if( strcmp(arg[0], "nop\n") == 0 || strcmp(arg[0], "nop") == 0 )
            {
			    memset(output, '0', 32);
			    output[32] = '\0';
			    printf("%s // %s", output, arg[0]);
			    fprintf(outputFile, "%s // %s", output, arg[0]);
                iPC++;
		    }
            else if( strcmp(arg[0], "sid") == 0 )
            {
			    strcpy(op, "110010");
			    ins_type = J_TYPE;
			    strcpy(target, dTob26(atoi(arg[1])));
			    strcpy(output, op);
			    strcat(output, target);
			    printf("%s // %s %s", output, arg[0], arg[1]);
			    fprintf(outputFile, "%s // %s %s", output, arg[0], arg[1]);
                iPC++;
		    }
            else if( s_mapOP[arg[0]] == OP_J )
            {
			    strcpy(op, "000010");
			    ins_type = J_TYPE;

                // Get rid of termination character
                char *tempy = strtok(arg[1], "\n");

                // Check for Label
                if(s_mapLabel.count(tempy) != 0)
                {
                    strcpy(target, dTob26(s_mapLabel[tempy]));
                }
                else
                {
                    strcpy(target, dTob26(atoi(arg[1])));
                }

			    strcpy(output, op);
			    strcat(output, target);
			    printf("%s // %s %s\n", output, arg[0], arg[1]);
			    fprintf(outputFile, "%s // %s %s\n", output, arg[0], arg[1]);
                iPC++;
		    }
            else if( s_mapOP[arg[0]] == OP_JAL )
            {
			    strcpy(op, "000011");
			    ins_type = J_TYPE;
                int target_pc = 0;

                // Get rid of termination character
                char *tempy = strtok(arg[1], "\n");

                // Check for Label
                if(s_mapLabel.count(tempy) != 0)
                {
                    strcpy(target, dTob26(s_mapLabel[tempy]));
                    target_pc = s_mapLabel[tempy];
                }
                else
                {
                    strcpy(target, dTob26(atoi(arg[1])));
                    target_pc = atoi(arg[1]);
                }

			    strcpy(output, op);
			    strcat(output, target);
			    printf("%s // %s %s (%d)\n", output, arg[0], arg[1], target_pc);
			    fprintf(outputFile, "%s // %s %s (%d)\n", output, arg[0], arg[1], target_pc);
                iPC++;
		    }
            else if( s_mapOP[arg[0]] == OP_JR )
            {
			    strcpy(op, "000000");
			    ins_type = J_TYPE;

                // Get rid of termination character
                char *tempy = strtok(arg[1], "\n");

                // Convert to register code
                RegDecode(tempy, rs);

			    strcpy(output, op);
			    strcat(output, rs);
                strcat(output, "000000000000000001000");
			    printf("%s // %s %s\n", output, arg[0], arg[1]);
			    fprintf(outputFile, "%s // %s %s\n", output, arg[0], arg[1]);
                iPC++;
		    }
            else if(s_mapOP[arg[0]] == OP_BREAK)
            {
			    ins_type = R_TYPE;
                strcpy(output, "00000000000000000000000000001101");
			    printf("%s // %s\n", output, arg[0]);
			    fprintf(outputFile, "%s // %s\n", output, arg[0]);
                iPC++;
		    }
            else if( strcmp(arg[0], "quit") == 0)
            {
			    printf("Done!");
                fDone = 1;
                break;
		    }
        }
        else if(iTokenCount == 0)
        {
	  	       printf("no arguments\n");
        }
	}

    // Clean up
	fclose(outputFile);
	fclose(inputFile);

	system("PAUSE");
    strcpy(input, "done");
}


