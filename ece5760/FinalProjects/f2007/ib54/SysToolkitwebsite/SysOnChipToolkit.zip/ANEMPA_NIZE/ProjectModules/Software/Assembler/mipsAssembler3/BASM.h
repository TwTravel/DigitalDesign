// Mips-Like Assembler ver 0.4
// Idan Beck, 2007
/***********************************************************************
* This is a mips like assembler takes in a mips like input assembly file
* and outputs a machine code file with annotated instruction comments as
* is acceptable by verilog standards so that the output can be used as
* a memory file for initializing a instruction memory.
*
* Bugs:
* - Does not deal with jump / branch instructions
* - Does not deal with load / store instructions
*
* Planned Work :
* 1. Implement jump instructions
* 2. Implement branch instructions
* 3. Implement loads and stores
*
* apr11: SMSG added
* apr12: SID added
************************************************************************/

#pragma once

#define _CRT_SECURE_NO_DEPRECATE 1

#include <map>
#include <string>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#define DELIMIT ' ()'



enum OPS {
    // Memory Ops
    OP_LW,
    OP_LH,
    OP_LHU,
    OP_LB,
    OP_LBU,
    OP_SW,
    OP_SH,
    OP_SB,

    // Immediate OPs
    OP_LUI,
    OP_ADDI,
    OP_ADDIU,
    OP_SLTI,
    OP_SLTIU,
    OP_ANDI,
    OP_XORI,
    OP_ORI,
    OP_SMSG,
    OP_RMSG,
    OP_SID,
    OP_ADD,
    OP_ADDU,
    OP_SUB,
    OP_SUBU,
    OP_AND,
    OP_OR,
    OP_XOR,
    OP_SLT,
    OP_SLTU,
    OP_SLL,
    OP_SRL,
    OP_SRA,

    // Branching
    OP_BNE,
    OP_BEQ,

    OP_BGTZ,
    OP_BGEZ,
    OP_BLTZ,
    OP_BLEZ,

    OP_J,
    OP_JR,
    OP_JAL,

    // IN/OUT Instructions
    OP_IN,
    OP_OUT,
    OP_OUTI,

    // Mult div mod
    OP_MULT,
    OP_MULTU,
    OP_DIV,
    OP_DIVU,
    OP_MOD,

    // PSEUDO Instructions
    OP_LA,

    // Control OPS
    OP_NOP,
    OP_BREAK,
    OP_QUIT
};

enum InstructionTypes {
    I_TYPE,
    J_TYPE,
    R_TYPE,
    SR_TYPE,
    P_TYPE,
    NOT_TYPE
};

char* dTob(int input);
char* dTob26(int input);
char* hTob(char *hex);

int RegDecode(char *pszReg, char *pszOut);

void InitializeOPMap();
int OpFunctionSADecode(char *AsmOp, char* OpCode, char* FunctionCode, char *SACode);
