#include <stdio.h>
#include <stdlib.h>

void char2lcdhex(char c);

int main(int argc, char *argv[])
{
  // this program has two modes, one in which the user defines a text
  // file for being converted or the other where the user inputs a 
  // line and it is converted to LCD Hex values space delimited 
    char ins[50];
    FILE *in;
    FILE *out;
    int slen;
    int i;
    
    if(argc < 2) {
        out = fopen("text2hex.log", "r");
        printf("Enter a string to be converted?\n");
        gets(ins);
        slen = strlen(ins);
        for(i=0;i<slen;i++){
            char2lcdhex(ins[i]);    
        }
        
        printf("\n", ins);
    }
    system("PAUSE");	
    return 0;
}

// returns a length 2 array of chars 
// that represents the hex value for the LCD
// specifically Crystalfrontz America's:
// CFAH1602B-TMC-JP LCD display
void char2lcdhex(char c){
    char hex_out[3];
    switch(c) {
        case('a'):        strcpy("61", hex_out);
                    break;
        case('b'):        strcpy("62", hex_out);
                    break;
        case('c'):        strcpy("63", hex_out);
                    break;
        case('d'):        strcpy("64", hex_out);
                    break;
        case('e'):        strcpy("65", hex_out);
                    break;
        case('f'):        strcpy("66", hex_out);
                    break;
        case('g'):        strcpy("67", hex_out);
                    break;
        case('h'):        strcpy("68", hex_out);
                    break;
        case('i'):        strcpy("69", hex_out);
                    break;
        case('j'):        strcpy("6A", hex_out);
                    break;
        case('k'):        strcpy("6B", hex_out);
                    break;
        case('l'):        strcpy("6C", hex_out);
                    break;
        case('m'):        strcpy("6D", hex_out);
                    break;
        case('n'):        strcpy("6E", hex_out);
                    break;
        case('o'):        strcpy("6F", hex_out);
                    break;
        case('p'):        strcpy("70", hex_out);
                    break;
        case('q'):        strcpy("71", hex_out);
                    break;            
        case('r'):        strcpy("72", hex_out);
                    break;
        case('s'):        strcpy("73", hex_out);
                    break;
        case('t'):        strcpy("74", hex_out);
                    break;
        case('u'):        strcpy("75", hex_out);
                    break;
        case('v'):        strcpy("76", hex_out);
                    break;
        case('w'):        strcpy("77", hex_out);
                    break;
        case('x'):        strcpy("78", hex_out);
                    break;
        case('y'):        strcpy("79", hex_out);
                    break;
        case('z'):        strcpy("7A", hex_out);
                    break;
        case('A'):        strcpy("41", hex_out);
                    break;
        case('B'):        strcpy("42", hex_out);
                    break;
        case('C'):        strcpy("43", hex_out);
                    break;
        case('D'):        strcpy("44", hex_out);
                    break;
        case('E'):        strcpy("45", hex_out);
                    break;
        case('F'):        strcpy("46", hex_out);
                    break;
        case('G'):        strcpy("47", hex_out);
                    break;
        case('H'):        strcpy("48", hex_out);
                    break;
        case('I'):        strcpy("49", hex_out);
                    break;
        case('J'):        strcpy("4A", hex_out);
                    break;
        case('K'):        strcpy("4B", hex_out);
                    break;
        case('L'):        strcpy("4C", hex_out);
                    break;
        case('M'):        strcpy("4D", hex_out);
                    break;
        case('N'):        strcpy("4E", hex_out);
                    break;
        case('O'):        strcpy("4F", hex_out);
                    break;
        case('P'):        strcpy("50", hex_out);
                    break;
        case('Q'):        strcpy("51", hex_out);
                    break;
        case('R'):        strcpy("52", hex_out);
                    break;
        case('S'):        strcpy("53", hex_out);
                    break;
        case('T'):        strcpy("54", hex_out);
                    break;
        case('U'):        strcpy("55", hex_out);
                    break;
        case('V'):        strcpy("56", hex_out);
                    break;
        case('W'):        strcpy("57", hex_out);
                    break;
        case('X'):        strcpy("58", hex_out);
                    break;
        case('Y'):        strcpy("59", hex_out);
                    break;
        case('Z'):        strcpy("5A", hex_out);
                    break;
        default:    strcpy("00", hex_out);
                    break;
    }
    
    printf("%s ", hex_out);
}
