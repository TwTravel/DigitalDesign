// This is the GPU defines file

// The op codes have 6 bits for a good reason, this allows for more
// functionality to be built into the GPU without too much architechture
// changes

// OP Codes

`define		setX1		6'b000000
`define		setY1   	6'b000001
`define		setX2		6'b000010
`define		setY2		6'b000011
`define		setChar		6'b000100

// Color is the data field of these
`define		drawChar	6'b000101
`define		drawLine	6'b000110
`define		drawPixel	6'b000111
`define		clear		6'b001000

// fields

`define		Op			15:10
`define		Data		9:0
`define     Char		7:0
`define		Color	   	7:0
