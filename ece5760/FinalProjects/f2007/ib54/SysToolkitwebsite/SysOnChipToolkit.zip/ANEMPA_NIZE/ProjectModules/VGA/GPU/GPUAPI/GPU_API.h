#ifndef GPU_API_H_
#define GPU_API_H_

// This is an API header to be used with the GPU.

// GPU Interface
#define GPUInterface    (volatile unsigned int*)0x00800800
#define GPU_Valid       (volatile unsigned char*)0x00800820
#define GPU_Complete    (volatile unsigned char*)0x00800810

// Op Code Defines:

#define SETX1       0x0000  // 0
#define SETY1       0x0400  // 1024
#define SETX2       0x0800  // 2048
#define SETY2       0x0C00  // 3072
#define SETCHAR     0x1000  // 4096
#define DRAWCHAR    0x1400  // 5120
#define DRAWLINE    0x1800  // 6144
#define DRAWPIXEL   0x1C00  // 7168
#define CLEAR       0x200   // 8192

struct LineSegment
{
    // Endpoints
    int x1;
    int y1;
    int x2;
    int y2;
    // Unit Vector
    float u_x;
    float u_y;
    // Normal
    float n_x;
    float n_y;
    // Magnitude
    float mag;
    // Color
    unsigned char color;
};

struct LineSegment CreateLine(int iX1, int iY1, int iX2, int iY2, unsigned char cColor);

void DrawLine(int iX1, int iY1, int iX2, int iY2, unsigned char cColor);
void DrawLineStruct(struct LineSegment l);
// These should eventually be handled through Bresenham in the future
void DrawVLine(int iX, int iY, int iLength, unsigned char cColor);
void DrawHLine(int iX, int iY, int iLength, unsigned char cColor);

void DrawChar(int iX, int iY, char cChar, unsigned char cColor);
void DrawText(int iX, int iY, char *pszString, int cchLength, unsigned char cColor);
void DrawTextNumber(int iX, int iY, int Num, unsigned char cColor);

void DrawCircle(int iX, int iY, unsigned char cColor);
void PlotPixel(int iX, int iY, unsigned char cColot);
void ClearScreen();


#endif /*GPU_API_H_*/
