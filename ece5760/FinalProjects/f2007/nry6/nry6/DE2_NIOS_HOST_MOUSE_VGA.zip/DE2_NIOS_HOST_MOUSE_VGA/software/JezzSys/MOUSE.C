
#include "system.h"
#include "basic_io.h"
#include "LCD.h"
#include "Test.h"
//#include "sys/alt_irq.h"
//#include "VGA.h"




int maxmin(int no, int max, int min)
{
 if(no>max) {no=max;}
 if(no<min) {no=min;}

 return(no);
}

void play_mouse(unsigned int addr)
{
 unsigned int cbuf[128];
 unsigned int rbuf[128];
 //buffer information
 unsigned int atllen,ptllen,intllen;
 unsigned int int_start;
 //int parameters
 unsigned long int_skip=0xFFFFFFFE;
 unsigned long int_last=0x00000001;
 unsigned int  int_blk_size=64;
 unsigned int timecnt;
 unsigned int freq;
 signed char X=0,Y=0,B=0;
 unsigned int pX=320,pY=240;
 unsigned int oX=320,oY=240;
 unsigned int tog=0;
 
 int i;
 int cmdmouse;
 int cmdxy1;
 int cmdxy2;
 int cmdball;
 int ballx, bally;
 int ballxy;
 signed int dx = 1, dy = 1;
 int x_min = 5;          // max and min points - boundaries
 int x_max = 511;
 int y_min = 3;
 int y_max = 478;


 freq=0x00;
 erase_all();

 w16(HcBufStatus,0x00);

 //Setup Int Parameters
 w32(HcIntSkip,int_skip);
 w32(HcIntLast,int_last);
 w16(HcIntBlkSize,int_blk_size);

 //Setup Buffer
 atllen  =r16(HcATLLen);
 ptllen  =r16(HcPTLLen);
 intllen =r16(HcINTLen);

 int_start=ptllen+ptllen;

 do
  {
   //send out DATA IN packet
   make_int_ptd(cbuf,IN,1,4,tog%2,addr,addr,freq);
   timecnt=send_int(cbuf,rbuf);
   if(timecnt!=0)
   {
	   X=(rbuf[4]>>8);
	   Y=(rbuf[5]&0x00FF);
	   B=(rbuf[4]&0x000F);
   }
   else
   {
	   X=0;
	   Y=0;
	   B=0;
   }

   oX=pX;
   oY=pY;

   pX=pX+X;
   pY=pY+Y;
  
   pX=maxmin(pX,639,0);
   pY=maxmin(pY,479,0);
   printf("\nRight here.");

  if(timecnt!=0) 
  {
    tog++;
  }

    //--------------------- start ball code --------------------------//
  
    
        ballxy = IORD(BALL_H2S_BASE, 0);
        i = ( ballxy >> 20 );
        printf("\n--------------Yes Ball_h2s 30 is : %i", i);
        if( i )       // if reset is on
        { 
            x_min = 5;          // max and min points - boundaries
            x_max = 511;
            y_min = 3;
            y_max = 478;
        }
        ballx = ((ballxy << 22) >> 22);                 // [9:0]
        bally = (((ballxy >> 10) << 22) >> 22);         // [19:0]
        printf("\nBALL should be at: (%i,%i) or else %i\n", ballx,bally, ballxy);

        if( ballx == (x_max-1) )  // >=
        {
            dx = -1;
        }
        else if( ballx == (x_min+2) ) // <=
        {
            dx = 1;
        }
        ballx = ballx + dx;
        
        if( bally == (y_max-1) ) // >=
        {
            dy = -1;
        }
        else if( bally == (y_min+1) )  // <=
        {
            dy = 1;
        }
        bally = bally + dy;
        
        cmdball = 0;
        cmdball = (ballx) | (bally << 10);    // add 6 to offset x_corr
        IOWR(BALL_XY_BASE, 0, cmdball);
        printf("\nBALL value passed is: %i or else (%i,%i)\n", cmdball,ballx,bally);
        for( i = 0; i < 1000; i++ )
        {
               // for delay
        }
    //----------------------- ball code end --------------------------//


  IOWR(SEG7_DISPLAY_BASE,0,(pX<<16)+pY);
  IOWR(LED_RED_BASE,0,pX);
  IOWR(LED_GREEN_BASE,0,pY);
  
  cmdmouse = 0;
  cmdmouse = (pX) | (pY << 10);
  IOWR( MOUSE_XY_BASE, 0, cmdmouse );

  //Set_Cursor_XY(pX,pY);
  if(B==1)      //left click mouse - draw vertical line
  {
    cmdxy1 = 0;
    cmdxy1 = (pX+6)| (pY << 10) | ((pX+6) << 20) ;   
    IOWR( WIDEOUT_BASE, 0, cmdxy1 );
    
    cmdxy2 = 0;
    cmdxy2 = (pX+6) | (y_max << 10) | (y_min << 20) ;   
    IOWR( WIDEOUT1_BASE, 0, cmdxy2 );
    //Vga_Set_Pixel(VGA_0_BASE,pX,pY);
    printf("\nleft mouse was clicked on: %i and %i", cmdxy1, cmdxy2);
    printf("\nmouse on: %i and %i", pX, pY);
    
//    // color in the rest of the outside area
//    if( ballx < pX+6 && pX < x_max )
//    {
//        for( i = (pX+7); i < x_max; i++ )
//        {
//            cmdxy1 = 0;
//            cmdxy1 = (i)| (pY << 10) | ((i) << 20) | 1 << 30 ; 
//            cmdxy2 = 0;
//            cmdxy2 = (i) | (y_max << 10) | (y_min << 20) | 1 << 30 ;  
//            IOWR( WIDEOUT_BASE, 0, cmdxy1 );
//            IOWR( WIDEOUT1_BASE, 0, cmdxy2 );
//        } 
//    }
//    else if( ballx > pX+6 && pX > x_min )
//    {
//        for( i = (pX+5); i > x_min; i-- )
//        {
//            cmdxy1 = 0;
//            cmdxy1 = (i)| (pY << 10) | ((i) << 20) | 1 << 30 ; 
//            cmdxy2 = 0;
//            cmdxy2 = (i) | (y_max << 10) | (y_min << 20) | 1 << 30 ;  
//            IOWR( WIDEOUT_BASE, 0, cmdxy1 );
//            IOWR( WIDEOUT1_BASE, 0, cmdxy2 );
//        } 
//    }
    
    // sets the new line to a max/min if necessary
    if( ballx < pX+6 && pX < x_max )
    {
        x_max = pX+6;
    }
    else if( ballx > pX+6 && pX > x_min )
    {
        x_min = pX+6;
    }
  }
  else if(B==2)
  {
    cmdxy1 = 0;
    cmdxy1 = (pX+6) | (pY << 10) | ((x_min) << 20) ;  
    //cmdxy1 = (pX) | (x_min << 8) | (pY << 16) | (pY << 24);   
    IOWR( WIDEOUT_BASE, 0, cmdxy1 );
    
    cmdxy2 = 0;
    cmdxy2 = (x_max) | (pY << 10) | (pY << 20) ;   
    IOWR( WIDEOUT1_BASE, 0, cmdxy2 );
    //Vga_Clr_Pixel(VGA_0_BASE,pX,pY);
    printf("\nright mouse was clicked on: %i and %i", cmdxy1, cmdxy2);
    printf("\nmouse on: %i and %i", pX, pY);
    
    for( i = 0; i < 500; i++ )
    {
        // for delay
    }
    
//    // color in the rest of the outside area
//    if( bally < pY && pY< y_max )
//    {
//        for( i = pY; i < y_max; i++ )
//        {
//            cmdxy1 = 0;
//            cmdxy1 = (pX+6) | (i << 10) | ((x_min) << 20) | 1 << 30 ;    
//            cmdxy2 = 0;
//            cmdxy2 = (x_max) | (i << 10) | (i << 20) | 1 << 30 ; 
//            IOWR( WIDEOUT_BASE, 0, cmdxy1 );  
//            IOWR( WIDEOUT1_BASE, 0, cmdxy2 );
//        } 
//    }
//    else if( bally > pY && pY > y_min )
//    {
//        for( i = pY; i > y_min; i-- )
//        {
//            cmdxy1 = 0;
//            cmdxy1 = (pX+6) | (i << 10) | ((x_min) << 20) | 1 << 30;    
//            cmdxy2 = 0;
//            cmdxy2 = (x_max) | (i << 10) | (i << 20) | 1 << 30 ; 
//            IOWR( WIDEOUT_BASE, 0, cmdxy1 );  
//            IOWR( WIDEOUT1_BASE, 0, cmdxy2 );
//        } 
//    }
    
    
    // to set new max / min
    if( bally < pY && pY < y_max )
    {
        y_max = pY;
    }
    else if( bally > pY && pY > y_min )
    {
        y_min = pY;
    }
  }
  
  }// end of do statement
  while(1);
  //(r16(HcRhP2) & 0x01) ==0x01);
     printf("\nMouse Not Detected");
     
}

void mouse(void)
{
 unsigned int rbuf[128];
 unsigned int dev_req[4]={0x0680,0x0100,0x0000,0x0008};
 unsigned int uni_req[4]={0x0500,3,0x0000,0x0000};

 //buffer information
 unsigned int atllen,ptllen,intllen;
 unsigned int atl_start;

 //atl parameters
 unsigned long atl_skip=0xFFFFFFFE;
 unsigned long atl_done=0;
 unsigned long atl_last=0x00000001;
 unsigned int  atl_blk_size=64;
 unsigned int  atl_cnt=1;
 unsigned int  atl_timeout=200;
 unsigned int mycode;
 unsigned int iManufacturer,iProduct;
 unsigned int starty=5;
 unsigned int status;
 unsigned int mouse01=0,mouse02=0;
 unsigned int g=0;

while(1)
{
  dev_req[0]=0x0680;
  dev_req[1]=0x0100;
  dev_req[2]=0x0000;
  dev_req[3]=0x0008;
  uni_req[0]=0x0500;
  uni_req[1]=3;
  uni_req[2]=0x0000;
  uni_req[3]=0x0000;


 //atl parameters
  atl_skip=0xFFFFFFFE;
  atl_done=0;
  atl_last=0x00000001;
  atl_blk_size=64;
  atl_cnt=1;
  atl_timeout=200;
  starty=5;
  mouse01=0,mouse02=0;
 

 set_operational();
 enable_port();

 reset_usb();
 erase_all();
 set_operational();
 enable_port();

 
 w16(HcControl,0x6c0);
 w16(HcUpInt,0x1a9);
 //delay(300);

 w16(HcBufStatus,0x00);

 //Setup ATL Parameters
 w32(HcATLSkip,atl_skip);
 w32(HcATLLast,atl_last);
 w16(HcATLBlkSize,atl_blk_size);
 w16(HcATLThrsCnt,atl_cnt);
 w16(HcATLTimeOut,atl_timeout);

 //Setup ATL Buffer
 atllen  =r16(HcATLLen);
 ptllen  =r16(HcPTLLen);
 intllen =r16(HcINTLen);

 atl_start=ptllen+ptllen+intllen;

 status=assign_address(1,2,0);
 status=assign_address(1,2,0);

 if(g==0)
 {
  printf("ISP1362 Mouse Demo.....\n");
  g=1;
 }

 w16(HcUpIntEnable,0x120);

 if( (status&0x0001)!=0) //port 2 active
 {
//  Check port 2 for mouse
  mycode=get_control(rbuf,2,'D',0,2);
  if(mycode==0x0300)
  {
   iManufacturer = rbuf[7]&0xFF;
   iProduct = (rbuf[7]&0xFF00)>>8;
   addr_info(2,'W','O',iManufacturer);
   addr_info(2,'W','P',iProduct);
   mycode=get_control(rbuf,2,'H',addr_info(2,'R','P',0),2);
   if( *(rbuf+1)==0x0209  )
   {
	   printf("\nMouse Detected");
	   mouse02=1;
   }
  }
  printf("\nIn status not 0");
 }

 if((mouse02==1)&&(mouse01==0))
 {
  mycode=set_config(2,1);
  if(mycode==0)
  play_mouse(2);
  printf("\nIn mouse02 = 1 and mouse01=0");
 }
 usleep(100000);
}
}

