int maxmin(int no, int max, int min);

void play_mouse(unsigned int addr);

void mouse(void);

