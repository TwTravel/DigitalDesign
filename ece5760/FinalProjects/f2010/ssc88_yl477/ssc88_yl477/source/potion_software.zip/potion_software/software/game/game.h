/*
 * game.h
 *
 *  Created on: Dec 2, 2010
 *      Author: Yunchi Luo
 */
#include "altera_avalon_pio_regs.h"

#define CENTER_X (320 << Q_FRAC_LEN)
#define CENTER_Y (240 << Q_FRAC_LEN)
#define WIDTH_X (640 << Q_FRAC_LEN)
#define WIDTH_Y (480 << Q_FRAC_LEN)
#define DEPTH_Z 240

#define WINDOW_X_CENTER 320
#define WINDOW_Y_CENTER 240
#define D_EYE_SCREEN 100

#define PADDLE_WIDTH (150 << Q_FRAC_LEN)
#define PADDLE_HEIGHT (120 << Q_FRAC_LEN)
#define PADDLE_HALF_WIDTH (PADDLE_WIDTH/2)
#define PADDLE_HALF_HEIGHT (PADDLE_HEIGHT/2)

#define VIDEO_PADDLE_WIDTH (PADDLE_WIDTH >> Q_FRAC_LEN)
#define VIDEO_PADDLE_HEIGHT (PADDLE_HEIGHT >> Q_FRAC_LEN)
#define VIDEO_PADDLE_HALF_WIDTH (VIDEO_PADDLE_WIDTH/2)
#define VIDEO_PADDLE_HALF_HEIGHT (VIDEO_PADDLE_HEIGHT/2)
#define VIDEO_BALL_RADIUS (BALL_RADIUS >> Q_FRAC_LEN)

#define INIT_AI_VEL (1 << Q_FRAC_LEN) // pixels per frame, manhattan distance

// Fixed point definition
#define Q_LEN 16
#define Q_DECI_LEN 11
#define Q_FRAC_LEN 5

#define MAX_CURVE 25

#define BALL_RADIUS (25 << Q_FRAC_LEN)

#define SINGLE_PLAYER 0
#define DOUBLE_PLAYER 1

// Convert game coordinates to screen coordinates and vice versa
#define G2S(x) (x >> Q_FRAC_LEN)
#define S2G(x) (x << Q_FRAC_LEN)

// Shorter PIO macros
#define RD(base) 				IORD_ALTERA_AVALON_PIO_DATA(base)
#define WR(base, data) 			IOWR_ALTERA_AVALON_PIO_DATA(base, data)
