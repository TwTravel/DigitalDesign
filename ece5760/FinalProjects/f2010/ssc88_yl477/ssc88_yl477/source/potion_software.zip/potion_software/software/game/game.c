/*
 * game.c
 *
 *  Created on: Dec 2, 2010
 *      Author: Yunchi Luo
 */
/*
 * Inputs:
 *  x y position of my paddle
 *  x y position of his paddle
 * Outputs
 *  x y z position of the ball
 *  total velocity of the ball
 */

//#define MATLAB
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include "system.h"
#include "priv/alt_busy_sleep.h"
#include "game.h"

typedef struct ball_t {
  short x, y, z;
  short vx, vy, vz;
  short ax, ay;
} ball_t;

ball_t ball0;
short his_x, his_y;
short last_his_x, last_his_y;
short my_x, my_y;
short last_my_x, last_my_y;
char game_mode;

short p1_score;
short p2_score;

#define CURVE_FACTOR 5
//#define CURVE_FACTOR 16 //Completely remove curveball mechanics

#define WIN 0
#define LOSE 1

void update_outputs();

void initialize() {
  ball0.x = CENTER_X;
  ball0.y = CENTER_Y;
  ball0.z = 1;
  ball0.vx = 0;
  ball0.vy = 0;
  ball0.vz = 0;
  ball0.ax = 0;
  ball0.ay = 0;
  his_x = CENTER_X;
  his_y = CENTER_Y;
  my_x = CENTER_X;
  my_y = CENTER_Y;
}

void game_start(int mode) {
  ball0.vx = 0;
  ball0.vy = 0;
  ball0.vz = 5;
  last_his_x = his_x;
  last_his_y = his_y;
  last_my_x = my_x;
  last_my_y = my_y;
  game_mode = !mode;
}

void game_over(char result) {
  printf("Game over!\n");
  if (result == WIN) {
	p1_score++;
	WR(P1_SCORE_BASE, p1_score);
    printf("Right Wins!\n");
  } else {
	p2_score++;
	WR(P2_SCORE_BASE, p2_score);
    printf("Left Wins!\n");
  }
  // TODO: assert some game over signal
  while (RD(START_BUTTON_BASE) == 1) {
    // Loop until start button is pressed (KEY[1])
  }
  initialize();
  if (WIN) {
	ball0.z = DEPTH_Z;
  } else {
	ball0.z = 0;
  }
  update_outputs();
  game_start(game_mode);
}

void step(ball_t *ball) {
  short x_next, y_next, z_next;
  // First perform the next position calculations for "ideal" case
  x_next = ball->x + ball->vx;
  y_next = ball->y + ball->vy;
  z_next = ball->z + ball->vz;

  if (game_mode == SINGLE_PLAYER) {
    // Our amazing AI
    his_x = ball->x;
    his_y = ball->y;
    last_his_x = his_x;
    last_his_y = his_y;
  } else {
    // Multiplayer, something else will set his_x and his_y;
  }

  // Check side boundaries
  if (x_next < 0) {
    // Past left wall, vx must be negative
    x_next = -x_next;
    ball->vx = -ball->vx;
  } else if (x_next > WIDTH_X) {
    // Past right wall, vx must be positive
    x_next = WIDTH_X - (x_next - WIDTH_X);
    ball->vx = -ball->vx;
  }
  if (y_next < 0) {
    // Past left wall, vy must be negative
    y_next = -y_next;
    ball->vy = -ball->vy;
  } else if (y_next > WIDTH_Y) {
    // Past right wall, vy must be positive
    y_next = WIDTH_Y - (y_next - WIDTH_Y);
    ball->vy = -ball->vy;
  }

  // Check hitting the ball and win/lose
  if (z_next <= 0) {
    // Check for my hit
    if (((ball->x > my_x - PADDLE_HALF_WIDTH - BALL_RADIUS) && (ball->x < my_x + PADDLE_HALF_WIDTH + BALL_RADIUS))
      &&((ball->y > my_y - PADDLE_HALF_HEIGHT - BALL_RADIUS) && (ball->y < my_y + PADDLE_HALF_HEIGHT + BALL_RADIUS  ))) {
      // I hit the ball!
      z_next = 0;
      ball->vz = -ball->vz;

      // Add some velocity to the ball depending on where you hit it
      ball->vx += (ball->x - my_x) >> CURVE_FACTOR;
      ball->vy += (ball->y - my_y) >> CURVE_FACTOR;

      // Curveball mechanics
      ball->ax = (last_my_x - my_x) >> CURVE_FACTOR;
      ball->ay = (last_my_y - my_y) >> CURVE_FACTOR;
    } else {
      // Lose
      //printf("%i %i %i %i", my_x, my_y, ball->x, ball->y);
      game_over(LOSE);
    }
  } else if (z_next >= DEPTH_Z) {
    // Check for his hit
    if (((ball->x > his_x - PADDLE_HALF_WIDTH - BALL_RADIUS) && (ball->x < his_x + PADDLE_HALF_WIDTH + BALL_RADIUS))
      &&((ball->y > his_y - PADDLE_HALF_HEIGHT - BALL_RADIUS) && (ball->y < his_y + PADDLE_HALF_HEIGHT + BALL_RADIUS))) {
      // Opponent hit the ball!
      z_next = DEPTH_Z;
      ball->vz = -ball->vz;

      // Add some velocity to the ball depending on where he hits it
      ball->vx += (ball->x - his_x) >> CURVE_FACTOR;
      ball->vy += (ball->y - his_y) >> CURVE_FACTOR;

      // Curveball mechanics;
      ball->ax = (last_his_x - his_x) >> CURVE_FACTOR;
      ball->ay = (last_his_y - his_y) >> CURVE_FACTOR;
    } else {
      // Win
      game_over(WIN);
    }
  }
  last_my_x = my_x;
  last_my_y = my_y;

  if (ball->ax > MAX_CURVE) {
    ball->ax = MAX_CURVE;
  } else if (ball->ax < -MAX_CURVE) {
    ball->ax = -MAX_CURVE;
  }

  if (ball->ay > MAX_CURVE) {
    ball->ay = MAX_CURVE;
  } else if (ball->ay < -MAX_CURVE) {
    ball->ay = -MAX_CURVE;
  }

  // Curve ball mechanics (set acceleration to 0 to go without them)
  ball->vx = ball->vx + ball->ax;
  ball->vy = ball->vy + ball->ay;

  // Update ball position
  ball->x = x_next;
  ball->y = y_next;
  ball->z = z_next;
}

// Read inputs from PIO
void update_inputs() {
	his_x = S2G(RD(HIS_PADDLE_X_BASE));
	his_y = S2G(RD(HIS_PADDLE_Y_BASE));
	my_x = S2G(RD(MY_PADDLE_X_BASE));
	my_y = S2G(RD(MY_PADDLE_Y_BASE));
}

// Write outputs to PIO
static int debug = 0;
void update_outputs() {
	WR(BALL0_X_BASE, G2S(ball0.x));
	WR(BALL0_Y_BASE, G2S(ball0.y));
	WR(BALL0_Z_BASE, ball0.z);
	WR(HIS_PADDLE_X_BASE, G2S(ball0.x));
	WR(HIS_PADDLE_Y_BASE, G2S(ball0.y));
	WR(DEBUG_BASE, game_mode);
	debug++;
}

int main() {
  initialize(ball0);

  update_outputs();

  p1_score = 0;
  p2_score = 0;
  WR(P1_SCORE_BASE, p1_score);
  WR(P2_SCORE_BASE, p2_score);
  game_start(RD(MODE_BASE));

  // Game loop
  while (1) {
    update_inputs();
    step(&ball0);
    update_outputs();
    alt_busy_sleep(30000);
  }
}
