/* 
 * File:   keyboard_defines.h
 * Author: Manish Patel, Tahmid Mahbub, Matt Filipek
 *
 * Created on May 14, 2016, 9:01 AM
 */

#ifndef KEYBOARD_DEFINES_H
#define	KEYBOARD_DEFINES_H

#define key_w BIT_7
#define key_a BIT_8
#define key_s BIT_9
#define key_d BIT_10
#define key_shift BIT_11
#define key_up BIT_13
#define key_down BIT_14
#define key_right BIT_5
#define key_left BIT_3
//#define key_alt BIT_5
#define key_control BIT_1
//#define key_space BIT_13

#define w_code 0
#define a_code 1
#define s_code 2
#define d_code 3
#define shift_code 4
#define up_code 5
#define down_code 6
#define right_code 7
#define left_code 8
#define control_code 9
#define shot1_code 10
#define shot2_code 11
#define shot3_code 12
#define shot4_code 13
#define shot5_code 14
#define shot6_code 15
#define shot7_code 16
#define shot8_code 17
#define shot9_code 18
#define shot10_code 19
#define shot11_code 20
#define shot12_code 21
#define shot13_code 22
#define shot14_code 23
#define shot15_code 24

#endif	/* KEYBOARD_DEFINES_H */

