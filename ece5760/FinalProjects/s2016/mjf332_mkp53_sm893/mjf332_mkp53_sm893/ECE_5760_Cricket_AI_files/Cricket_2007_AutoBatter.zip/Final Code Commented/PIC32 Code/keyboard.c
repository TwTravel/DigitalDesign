/* 
 * File:   keyboard.c
 * Author: Manish Patel, Tahmid Mahbub, Matt Filipek
 *
 * Created on May 14, 2016, 8:58 AM
 */

#define _SUPPRESS_PLIB_WARNING 1

#include <stdio.h>
#include <stdlib.h>
#include <plib.h>

#include "config.h"

//================================
// Defines
//================================

#include "keyboard_defines.h"

//================================
// Function Prototypes
//================================

void shot1();
void shot2();
void shot3();
void shot4();
void shot5();
void shot6();
void shot7();
void shot8();
void shot9();
void shot10();
void shot11();
void shot12();
void shot13();
void shot14();
void shot15();
void typeW();
void typeW();
void typeA();
void typeS();
void typeD();
void typeShift();
void typeUp();
void typeDown();
void typeRight();
void typeLeft();
void typeControl();
void delay_ms(unsigned long i);
char buffer[30];
//================================


/*
 * 
 */
int main(int argc, char** argv) {
    SYSTEMConfigPerformance(40000000);
    
    // configure port pins for driving keyboard
    mPORTBSetPinsDigitalOut(key_w | key_a | key_s | key_d | key_shift | 
            key_up | key_down | key_right | key_left /*| key_alt*/ | key_control //|
            /*key_space*/);
    
    mPORTBClearBits(key_w | key_a | key_s | key_d | key_shift | 
            key_up | key_down | key_right | key_left /*| key_alt*/ | key_control //|
            /*key_space*/);
    
    // configure SPI
    
    mPORTBSetPinsDigitalIn(BIT_15);
    mPORTASetPinsDigitalIn(BIT_2);
    mPORTASetPinsDigitalIn(BIT_3);
    SDI2R = 0;  // pin 9, data in
    SS2R = 0;
    OpenSPI2(DISABLE_SDO_PIN | SPI_MODE8_ON | MASTER_ENABLE_OFF | 
            SLAVE_ENABLE_ON | CLK_POL_ACTIVE_HIGH | SPI_CKE_OFF, 
            SPI_ENABLE);
    
    volatile unsigned int data = 0;
    volatile unsigned int row = 0;
    volatile unsigned int dir = 0;
    int counter = 0;
    
    while(1) {
        
        // wait until SPI data is ready, then read it
        while(!DataRdySPI2());
        data = ReadSPI2();

        
        // select the appropriate shot based on the SPI command
        if(data == w_code) {
            typeW();
        }
        else if(data == a_code) {
            typeA();
        }
        else if(data == s_code) {
            typeS();
        }
        else if(data == d_code) {
            typeD();
        }
        else if(data == shift_code) {
            typeShift();
        }
        else if(data == up_code) {
            typeUp();
        }
        else if(data == down_code) {
            typeDown();
        }
        else if(data == right_code) {
            typeRight();
        }
        else if(data == left_code) {
            typeLeft();
        }
        else if(data == control_code) {
            typeControl();
        }
        else if(data == shot1_code) {
            shot1();
        }
        else if(data == shot2_code) {
            shot2();
        }
        else if(data == shot3_code) {
            shot3();
        }
        else if(data == shot4_code) {
            shot4();
        }
        else if(data == shot5_code) {
            shot5();
        }
        else if(data == shot6_code) {
            shot6();
        }
        else if(data == shot7_code) {
            shot7();
        }
        else if(data == shot8_code) {
            shot8();
        }
        else if(data == shot9_code) {
            shot9();
        }
        else if(data == shot10_code) {
            shot10();
        }
        else if(data == shot11_code) {
            shot11();
        }
        else if(data == shot12_code) {
            shot12();
        }
        else if(data == shot13_code) {
            shot13();
        }
        else if(data == shot14_code) {
            shot14();
        }        
        else if(data == shot15_code) {
            shot15();
        }
        
        //data = ReadSPI2();
    }
     
    return (EXIT_SUCCESS);
}

//================================ 
// Delay Function, Written by Tahmid
// https://people.ece.cornell.edu/land/courses/ece4760/PIC32/index_TFT_display.html
//================================
void delay_ms(unsigned long i){
/* Create a software delay about i ms long
 * Parameters:
 *      i:  equal to number of milliseconds for delay
 * Returns: Nothing
 * Note: Uses Core Timer. Core Timer is cleared at the initialiazion of
 *      this function. So, applications sensitive to the Core Timer are going
 *      to be affected
 */
    unsigned int j;
    j = (pb_clock/2000) * i;
    WriteCoreTimer(0);
    while (ReadCoreTimer() < j);
}

//==================================

void typeW() {
    mPORTBSetBits(key_w);
    delay_ms(50);
    mPORTBClearBits(key_w);
    delay_ms(50);
}

void typeA() {
    mPORTBSetBits(key_a);
    delay_ms(50);
    mPORTBClearBits(key_a);
    delay_ms(50);
}

void typeS() {
    mPORTBSetBits(key_s);
    delay_ms(50);
    mPORTBClearBits(key_s);
    delay_ms(50);
}

void typeD() {
    mPORTBSetBits(key_d);
    delay_ms(50);
    mPORTBClearBits(key_d);
    delay_ms(50);
}

void typeShift() {
    mPORTBSetBits(key_shift);
    delay_ms(50);
    mPORTBClearBits(key_shift);
    delay_ms(50);
}

void typeUp() {
    mPORTBSetBits(key_up);
    delay_ms(50);
    mPORTBClearBits(key_up);
    delay_ms(50);
}

void typeDown() {
    mPORTBSetBits(key_down);
    delay_ms(50);
    mPORTBClearBits(key_down);
    delay_ms(50);
}

void typeRight() {
    mPORTBSetBits(key_right);
    delay_ms(50);
    mPORTBClearBits(key_right);
    delay_ms(50);
}

void typeLeft() {
    mPORTBSetBits(key_left);
    delay_ms(50);
    mPORTBClearBits(key_left);
    delay_ms(50);
}

//void typeAlt() {
//    mPORTBSetBits(key_alt);
//    delay_ms(50);
//    mPORTBClearBits(key_alt);
//}

void typeControl() {
    mPORTBSetBits(key_control);
    delay_ms(50);
    mPORTBClearBits(key_control);
    delay_ms(50);
}

//void typeSpace() {
//    mPORTBSetBits(key_space);
//    delay_ms(50);
//    mPORTBClearBits(key_space);
//}

//=====================================
// Region 1
//=====================================

void shot1() {  // s, up, right
    mPORTBSetBits(key_s | key_up | key_right);
    delay_ms(50);
    mPORTBClearBits(key_s | key_up | key_right);
    delay_ms(50);
//    typeS();
}

void shot2() {  // shift, s, up, right
    mPORTBSetBits(key_shift | key_s | key_up | key_right);
    delay_ms(50);
    mPORTBClearBits(key_shift | key_s | key_up | key_right);
    delay_ms(50);
}

//=====================================
// Region 2
//=====================================

void shot3() {  // s, right
    mPORTBSetBits(key_s | key_right);
    delay_ms(50);
    mPORTBClearBits(key_s | key_right);
    delay_ms(50);
}

void shot4() {  // shift, s, right
    mPORTBSetBits(key_shift | key_right | key_s);
//    delay_ms(5);
//    mPORTBSetBits(key_right);
//    delay_ms(5);
//    mPORTBSetBits(key_s);
    delay_ms(50);
    mPORTBClearBits(key_shift | key_s | key_right);
    delay_ms(50);
}

//=====================================
// Region 3
//=====================================

void shot5() {  // s, down, right
    mPORTBSetBits(key_s | key_down | key_right);
    delay_ms(50);
    mPORTBClearBits(key_s | key_down | key_right);
    delay_ms(50);
}

void shot6() {  // shift, s, down, right
    mPORTBSetBits(key_shift | key_s | key_down | key_right);
    delay_ms(50);
    mPORTBClearBits(key_shift | key_s | key_down | key_right);
    delay_ms(50);
}

//=====================================
// Region 4
//=====================================

void shot7() {  // s, down
    mPORTBSetBits(key_s | key_down);
    delay_ms(50);
    mPORTBClearBits(key_s | key_down);
    delay_ms(50);
}

void shot8() {  // shift, s, down
    mPORTBSetBits(key_shift | key_s | key_down);
    delay_ms(50);
    mPORTBClearBits(key_shift | key_s | key_down);
    delay_ms(50);
}

//=====================================
// Region 5
//=====================================

void shot9() {  // s, down, left
    mPORTBSetBits(key_s | key_down | key_left);
    delay_ms(50);
    mPORTBClearBits(key_s | key_down | key_left);
    delay_ms(50);
}

void shot10() {  // shift, s, down, left
    mPORTBSetBits(key_shift | key_s | key_down | key_left);
    delay_ms(50);
    mPORTBClearBits(key_shift | key_s | key_down | key_left);
    delay_ms(50);
}

//=====================================
// Region 6
//=====================================

void shot11() {  // s, left
    mPORTBSetBits(key_s | key_left);
    delay_ms(50);
    mPORTBClearBits(key_s | key_left);
    delay_ms(50);
}

void shot12() {  // shift, s, left
    mPORTBSetBits(key_shift | key_s | key_left);
    delay_ms(50);
    mPORTBClearBits(key_shift | key_s | key_left);
    delay_ms(50);
}

//=====================================
// Region 7
//=====================================

void shot13() {  // s, up, left
    mPORTBSetBits(key_s | key_up | key_left);
    delay_ms(50);
    mPORTBClearBits(key_s | key_up | key_left);
    delay_ms(50);
}

void shot14() {  // shift, s, up, left
    mPORTBSetBits(key_shift | key_s | key_up | key_left);
    delay_ms(50);
    mPORTBClearBits(key_shift | key_s | key_up | key_left);
    delay_ms(50);
}

void shot15() { // shift, w, down, right
    mPORTBSetBits(key_shift | key_w | key_down | key_right);
    delay_ms(50);
    mPORTBClearBits(key_shift | key_w | key_down | key_right);
    delay_ms(50);
}

void typeShiftS() {
    mPORTBSetBits(key_shift | key_s);
    delay_ms(50);
    mPORTBClearBits(key_shift | key_s);
    delay_ms(50);
}

