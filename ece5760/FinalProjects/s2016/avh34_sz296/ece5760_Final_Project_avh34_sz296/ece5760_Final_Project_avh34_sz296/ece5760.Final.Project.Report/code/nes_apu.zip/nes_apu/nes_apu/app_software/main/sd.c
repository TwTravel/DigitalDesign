////////////////////////////////////////////////////////////////////////////////
//
// @file:   sd.c
//
// @author: Andre Heil <andre.v.heil@gmail.com>
//
// @date:   05/14/16
//
// @brief:  Perform functions on the .nsf file
//
////////////////////////////////////////////////////////////////////////////////


/// Includes ///////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdint.h>
#include <time.h>
#include "../terasic_lib/terasic_includes.h"
#include "../terasic_fat/FatFileSystem.h"
#include "../terasic_fat/FatInternal.h"


/// Global Vars ////////////////////////////////////////////////////////////////

static FAT_HANDLE      hFat;
static FAT_FILE_HANDLE hFile;

static char * str_to_lower( char * str );


/// Functions //////////////////////////////////////////////////////////////////

void sd_mount()
{
	hFat = NULL;

    while ( !hFat )
    {
        hFat = Fat_Mount( FAT_SD_CARD, 0 );
    }
}

void sd_list()
{
    bool bSuccess;
    int nCount = 0;
    FAT_BROWSE_HANDLE hBrowse;
    FILE_CONTEXT      fContext;
    char * p;

    bSuccess = Fat_FileBrowseBegin( hFat, &hBrowse );

    if ( bSuccess )
    {
        // Skip first three files, SD card info
        Fat_FileBrowseNext( &hBrowse, &fContext );
        Fat_FileBrowseNext( &hBrowse, &fContext );
        Fat_FileBrowseNext( &hBrowse, &fContext );
      
        printf( "Files:\n" );
        while( Fat_FileBrowseNext( &hBrowse, &fContext ) )
        {
            str_to_lower( fContext.szName );
            printf( "    %s\t[%x]\n", fContext.szName, fContext.FileSize );
            nCount++;
        }
        printf( "\n" );
    }
}

void sd_file_open( char * file_name )
{
	hFile = NULL;
    
    while( !hFile )
    {
        hFile = Fat_FileOpen( hFat, file_name );
    }
}

int  sd_file_size()
{
	return Fat_FileSize( hFile );
}

void sd_file_read( void* buf, int size )
{
    Fat_FileRead( hFile, buf, size );
}

void sd_file_close()
{
    Fat_FileClose(hFile);
    Fat_Unmount(hFat);
    sd_mount();
}

/// Helper Functions ///////////////////////////////////////////////////////////

static char * str_to_lower( char * str )
{
    int i;

    for( i = 0; str[i]; i++ )
    {
        str[i] = tolower( str[i] );
    }
}
