////////////////////////////////////////////////////////////////////////////////
//
// @file:   nsf.c
//
// @author: Andre Heil <andre.v.heil@gmail.com>
//
// @date:   05/14/16
//
// @brief:  Perform functions on the .nsf file
//
////////////////////////////////////////////////////////////////////////////////


/// Includes ///////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdint.h>
#include <time.h>
#include "../nes/6502.h"
#include "../nes/mem.h"
#include "nsf.h"
#include "sd.h"


/// Global Vars ////////////////////////////////////////////////////////////////

uint8_t bankswitch[8];
uint8_t use_bankswitching = 0;
float nsf_playfreq;
struct nsfhead_s nsfHead;



/// Functions //////////////////////////////////////////////////////////////////

void nsf_open( char *file_name )
{
    uint8_t i;
    
    sd_file_open( file_name );
    sd_file_read( &nsfHead, sizeof( struct nsfhead_s ) );
    sd_file_read( mem_rom,  sizeof( mem_rom ) );

    mem_load = nsfHead.load;

    if( memcmp( nsfHead.id, "NESM\x1A", 5 ) != 0 )
        printf("Error: not a NSF file.\n");

    if( nsfHead.version != 1 )
        printf("Error: invalid NSF version.\n");

    if( ( nsfHead.songs == 0 ) || ( nsfHead.start == 0 ) )
        printf("Error: no songs in NSF.\n");

    use_bankswitching = 0;
    for( i = 0; i < 8; ++i )
    {
        if( nsfHead.bankswitch[i] != 0 )
        {
            use_bankswitching = 1;
            break;
        }
    }

    if ( nsfHead.palntsc & 1 )
        nsf_playfreq = 1000000.0f / nsfHead.speedpal;
    else if ( nsfHead.palntsc >> 1 )       
        nsf_playfreq = 1000000.0f / nsfHead.speedpal;
    else
        nsf_playfreq = 1000000.0f / nsfHead.speedntsc;
}

void nsf_info()
{
    printf ("Title:\t %s\n",     nsfHead.name);
    printf ("Artist:\t %s\n",    nsfHead.artist);
    printf ("Copyright:\t %s\n", nsfHead.copyright);
    printf ("Load:\t $%04X\n",   nsfHead.load);
    printf ("Init:\t $%04X\n",   nsfHead.init);
    printf ("Play:\t $%04X\n\n", nsfHead.play);
    printf ("Clock standard:\t");

    printf ("Clock standard:\t");
    if ( nsfHead.palntsc & 1 )
    {
        printf ("PAL\n");
        printf ("Play Freq: %f Hz\n", 1000000.0f / nsfHead.speedpal);
    }
    else if ( nsfHead.palntsc >> 1 )
    {
        printf ( "PAL & NTSC\n ");
        printf ( "\n ");
        printf ( "Play Freq PAL: %f Hz\n", nsf_playfreq );
        printf ( "Play Freq NTSC: %f Hz\n", 1000000.0f / nsfHead.speedntsc );
    }
    else
    {
        printf ("NTSC\n");
        printf ("Play Freq: %f Hz\n", nsf_playfreq);
    }

    if ( nsfHead.extsnd != 0 )
    {
        printf ("Tune uses extra sound chip(s):\n  ");
        if( ( nsfHead.extsnd >> 0 ) & 1 ) printf( "VRC6 "      );
        if( ( nsfHead.extsnd >> 1 ) & 1 ) printf( "VRC7 "      );
        if( ( nsfHead.extsnd >> 2 ) & 1 ) printf( "FDS "       );
        if( ( nsfHead.extsnd >> 3 ) & 1 ) printf( "MMC5 "      );
        if( ( nsfHead.extsnd >> 4 ) & 1 ) printf( "Namco_163 " );
        if( ( nsfHead.extsnd >> 5 ) & 1 ) printf( "Sunsoft_5B" );
        printf ("\n");
    }
}

void nsf_init( uint8_t s )
{
    song = s;

    memset( mem_ram, 0, sizeof( mem_ram ) );

    mos6502_rst( nsfHead.init, song );
    mos6502_exe();

    printf ("NSF init routine complete!\n");

}

void nsf_play()
{      
    clock_t t1, t2;
    uint16_t addr;
    play = 1;

    while( play )
    {
        t1 = clock(); 

        mos6502_rst( nsfHead.play, song );
        mos6502_exe();
       
       do {
            t2 = clock();
        } while( t2 - t1 < 16 );
    }

    for ( addr = 0x4000; addr < 0x4020; addr++ )
        mos6502_write( addr, 0 );
}

void nsf_pause()
{     
    play = 0;
}