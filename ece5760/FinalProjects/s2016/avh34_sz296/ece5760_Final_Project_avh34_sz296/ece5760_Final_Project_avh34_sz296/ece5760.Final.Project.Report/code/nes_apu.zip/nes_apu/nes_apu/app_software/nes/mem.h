

uint8_t mem_ram[0x0800];
uint8_t mem_ppu[0x0008];
uint8_t mem_apu[0x0020];
uint8_t mem_rrm[0x2000];
uint8_t mem_rom[0xF000];

uint16_t mem_load;