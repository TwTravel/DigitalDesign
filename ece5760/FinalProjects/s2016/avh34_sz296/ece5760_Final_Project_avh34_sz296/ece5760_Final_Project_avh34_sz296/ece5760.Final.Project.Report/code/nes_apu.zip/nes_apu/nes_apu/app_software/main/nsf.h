#ifndef __NSF_H_
#define __NSF_H_

struct nsfhead_s
{
    char     id[5];            // needs to be set as 'N','E','S','M',0x1A in the file
    uint8_t  version;          // currently 1
    uint8_t  songs;            // # of songs in nsf
    uint8_t  start;            // starting song, 1 based
    uint16_t load;             // load address of data
    uint16_t init;             // init address of song
    uint16_t play;             // play address of song
    char     name[32];         // name of song
    char     artist[32];       // name of artist
    char     copyright[32];    // copyright info
    uint16_t speedntsc;        // play speed 1/1000000th second ticks for ntsc
    uint8_t  bankswitch[8];    // bankswitch register data
    uint16_t speedpal;         // play speed 1/1000000th second ticks for pal
    uint8_t  palntsc;          // use pal, ntsc, or both
    uint8_t  extsnd;           // external sound chip support
    uint8_t  reserved[4];      // reserved for future use (right, like it's gonna be updated ever)
}__attribute__((packed));


void nsf_open( char *file_name );
void nsf_init(uint8_t s);
void nsf_play();
void nsf_pause();


volatile uint8_t play;
volatile uint8_t song;

#endif
