/*******************************************************************************
 *
 * @file:   nes_apu.c
 *
 * @author: Andre Heil <andre.v.heil@gmail.com>
 *
 * @date:   05/14/16
 *
 * @brief:  NES APU main file
 *
 ******************************************************************************/


/// Includes ///////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "buttons.h"
#include "sd.h"
#include "nsf.h"
#include "../BSP/system.h"


/// Functions //////////////////////////////////////////////////////////////////

int main()
{
    buttons_init();

    sd_mount();

    //nsf_open( "simn.nsf" );
    //nsf_info();
    //nsf_init(0);
    //nsf_play();

    play = 0;

    FILE* fp;
    char  msg[30];
    int   msg_len;
    char inString[20];
    int  inValue;

    fp = fopen( JTAG_NAME, "r+" );

    if ( fp )
    {
        printf("NSF Player\n");
    
        while ( 1 )
        {
            printf(">> ");
            fscanf(fp, "%s", inString);

            if ( !strcmp( inString, "ls" ) )
            {
                sd_list();
            }
            else if ( !strcmp( inString, "open" ) )
            {
                printf( "Please select a file to open\n" );
                fscanf( fp, "%s", inString );

                nsf_open( inString );
                nsf_init(0);
            }
            else if ( !strcmp( inString, "info" ) )
            {
                nsf_info();
            }
            else if ( !strcmp( inString, "start" ) )
            {
                start = 1;
                while ( start )
                {
                    if ( play )
                        nsf_play();
                }
            }
            else
            {
                printf( "Invalid command!\n" );
                //msg_len = sprintf( msg, "Invalid command!" );
                //fwrite( msg, strlen( msg ), 1, fp );
            }

            if ( ferror( fp ) ) 
            {
                clearerr( fp );
            }

            //fflush(fp);
        }

        fprintf(fp, "Closing the JTAG UART file handle.\n");
        
        fclose(fp);
    }

    return 0;
}
