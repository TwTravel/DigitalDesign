/*
 * system.h - SOPC Builder system and BSP software package information
 *
 * Machine generated for CPU 'CPU' in SOPC Builder design 'nios'
 * SOPC Builder design path: C:/nes_apu/nios/nios.sopcinfo
 *
 * Generated: Sun May 15 15:52:40 EDT 2016
 */

/*
 * DO NOT MODIFY THIS FILE
 *
 * Changing this file will have subtle consequences
 * which will almost certainly lead to a nonfunctioning
 * system. If you do modify this file, be aware that your
 * changes will be overwritten and lost when this file
 * is generated again.
 *
 * DO NOT MODIFY THIS FILE
 */

/*
 * License Agreement
 *
 * Copyright (c) 2008
 * Altera Corporation, San Jose, California, USA.
 * All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 * This agreement shall be governed in all respects by the laws of the State
 * of California and by the laws of the United States of America.
 */

#ifndef __SYSTEM_H_
#define __SYSTEM_H_

/* Include definitions from linker script generator */
#include "linker.h"


/*
 * APU_ADDR configuration
 *
 */

#define ALT_MODULE_CLASS_APU_ADDR altera_avalon_pio
#define APU_ADDR_BASE 0x2001080
#define APU_ADDR_BIT_CLEARING_EDGE_REGISTER 0
#define APU_ADDR_BIT_MODIFYING_OUTPUT_REGISTER 0
#define APU_ADDR_CAPTURE 0
#define APU_ADDR_DATA_WIDTH 8
#define APU_ADDR_DO_TEST_BENCH_WIRING 0
#define APU_ADDR_DRIVEN_SIM_VALUE 0
#define APU_ADDR_EDGE_TYPE "NONE"
#define APU_ADDR_FREQ 50000000
#define APU_ADDR_HAS_IN 0
#define APU_ADDR_HAS_OUT 1
#define APU_ADDR_HAS_TRI 0
#define APU_ADDR_IRQ -1
#define APU_ADDR_IRQ_INTERRUPT_CONTROLLER_ID -1
#define APU_ADDR_IRQ_TYPE "NONE"
#define APU_ADDR_NAME "/dev/APU_ADDR"
#define APU_ADDR_RESET_VALUE 0
#define APU_ADDR_SPAN 16
#define APU_ADDR_TYPE "altera_avalon_pio"


/*
 * APU_DATA configuration
 *
 */

#define ALT_MODULE_CLASS_APU_DATA altera_avalon_pio
#define APU_DATA_BASE 0x2001070
#define APU_DATA_BIT_CLEARING_EDGE_REGISTER 0
#define APU_DATA_BIT_MODIFYING_OUTPUT_REGISTER 0
#define APU_DATA_CAPTURE 0
#define APU_DATA_DATA_WIDTH 8
#define APU_DATA_DO_TEST_BENCH_WIRING 0
#define APU_DATA_DRIVEN_SIM_VALUE 0
#define APU_DATA_EDGE_TYPE "NONE"
#define APU_DATA_FREQ 50000000
#define APU_DATA_HAS_IN 0
#define APU_DATA_HAS_OUT 1
#define APU_DATA_HAS_TRI 0
#define APU_DATA_IRQ -1
#define APU_DATA_IRQ_INTERRUPT_CONTROLLER_ID -1
#define APU_DATA_IRQ_TYPE "NONE"
#define APU_DATA_NAME "/dev/APU_DATA"
#define APU_DATA_RESET_VALUE 0
#define APU_DATA_SPAN 16
#define APU_DATA_TYPE "altera_avalon_pio"


/*
 * APU_WREN configuration
 *
 */

#define ALT_MODULE_CLASS_APU_WREN altera_avalon_pio
#define APU_WREN_BASE 0x2001060
#define APU_WREN_BIT_CLEARING_EDGE_REGISTER 0
#define APU_WREN_BIT_MODIFYING_OUTPUT_REGISTER 0
#define APU_WREN_CAPTURE 0
#define APU_WREN_DATA_WIDTH 8
#define APU_WREN_DO_TEST_BENCH_WIRING 0
#define APU_WREN_DRIVEN_SIM_VALUE 0
#define APU_WREN_EDGE_TYPE "NONE"
#define APU_WREN_FREQ 50000000
#define APU_WREN_HAS_IN 0
#define APU_WREN_HAS_OUT 1
#define APU_WREN_HAS_TRI 0
#define APU_WREN_IRQ -1
#define APU_WREN_IRQ_INTERRUPT_CONTROLLER_ID -1
#define APU_WREN_IRQ_TYPE "NONE"
#define APU_WREN_NAME "/dev/APU_WREN"
#define APU_WREN_RESET_VALUE 0
#define APU_WREN_SPAN 16
#define APU_WREN_TYPE "altera_avalon_pio"


/*
 * CPU configuration
 *
 */

#define ALT_CPU_ARCHITECTURE "altera_nios2_qsys"
#define ALT_CPU_BIG_ENDIAN 0
#define ALT_CPU_BREAK_ADDR 0x2000820
#define ALT_CPU_CPU_FREQ 50000000u
#define ALT_CPU_CPU_ID_SIZE 1
#define ALT_CPU_CPU_ID_VALUE 0x00000000
#define ALT_CPU_CPU_IMPLEMENTATION "fast"
#define ALT_CPU_DATA_ADDR_WIDTH 0x1a
#define ALT_CPU_DCACHE_LINE_SIZE 0
#define ALT_CPU_DCACHE_LINE_SIZE_LOG2 0
#define ALT_CPU_DCACHE_SIZE 0
#define ALT_CPU_EXCEPTION_ADDR 0x1000020
#define ALT_CPU_FLUSHDA_SUPPORTED
#define ALT_CPU_FREQ 50000000
#define ALT_CPU_HARDWARE_DIVIDE_PRESENT 1
#define ALT_CPU_HARDWARE_MULTIPLY_PRESENT 1
#define ALT_CPU_HARDWARE_MULX_PRESENT 0
#define ALT_CPU_HAS_DEBUG_CORE 1
#define ALT_CPU_HAS_DEBUG_STUB
#define ALT_CPU_HAS_JMPI_INSTRUCTION
#define ALT_CPU_ICACHE_LINE_SIZE 32
#define ALT_CPU_ICACHE_LINE_SIZE_LOG2 5
#define ALT_CPU_ICACHE_SIZE 4096
#define ALT_CPU_INST_ADDR_WIDTH 0x1a
#define ALT_CPU_NAME "CPU"
#define ALT_CPU_NUM_OF_SHADOW_REG_SETS 0
#define ALT_CPU_RESET_ADDR 0x1000000


/*
 * CPU configuration (with legacy prefix - don't use these anymore)
 *
 */

#define NIOS2_BIG_ENDIAN 0
#define NIOS2_BREAK_ADDR 0x2000820
#define NIOS2_CPU_FREQ 50000000u
#define NIOS2_CPU_ID_SIZE 1
#define NIOS2_CPU_ID_VALUE 0x00000000
#define NIOS2_CPU_IMPLEMENTATION "fast"
#define NIOS2_DATA_ADDR_WIDTH 0x1a
#define NIOS2_DCACHE_LINE_SIZE 0
#define NIOS2_DCACHE_LINE_SIZE_LOG2 0
#define NIOS2_DCACHE_SIZE 0
#define NIOS2_EXCEPTION_ADDR 0x1000020
#define NIOS2_FLUSHDA_SUPPORTED
#define NIOS2_HARDWARE_DIVIDE_PRESENT 1
#define NIOS2_HARDWARE_MULTIPLY_PRESENT 1
#define NIOS2_HARDWARE_MULX_PRESENT 0
#define NIOS2_HAS_DEBUG_CORE 1
#define NIOS2_HAS_DEBUG_STUB
#define NIOS2_HAS_JMPI_INSTRUCTION
#define NIOS2_ICACHE_LINE_SIZE 32
#define NIOS2_ICACHE_LINE_SIZE_LOG2 5
#define NIOS2_ICACHE_SIZE 4096
#define NIOS2_INST_ADDR_WIDTH 0x1a
#define NIOS2_NUM_OF_SHADOW_REG_SETS 0
#define NIOS2_RESET_ADDR 0x1000000


/*
 * Define for each module class mastered by the CPU
 *
 */

#define __ALTERA_AVALON_JTAG_UART
#define __ALTERA_AVALON_NEW_SDRAM_CONTROLLER
#define __ALTERA_AVALON_PIO
#define __ALTERA_AVALON_SYSID_QSYS
#define __ALTERA_AVALON_TIMER
#define __ALTERA_NIOS2_QSYS


/*
 * JTAG configuration
 *
 */

#define ALT_MODULE_CLASS_JTAG altera_avalon_jtag_uart
#define JTAG_BASE 0x20010d0
#define JTAG_IRQ 1
#define JTAG_IRQ_INTERRUPT_CONTROLLER_ID 0
#define JTAG_NAME "/dev/JTAG"
#define JTAG_READ_DEPTH 64
#define JTAG_READ_THRESHOLD 8
#define JTAG_SPAN 8
#define JTAG_TYPE "altera_avalon_jtag_uart"
#define JTAG_WRITE_DEPTH 64
#define JTAG_WRITE_THRESHOLD 8


/*
 * KEY_0 configuration
 *
 */

#define ALT_MODULE_CLASS_KEY_0 altera_avalon_pio
#define KEY_0_BASE 0x2001050
#define KEY_0_BIT_CLEARING_EDGE_REGISTER 0
#define KEY_0_BIT_MODIFYING_OUTPUT_REGISTER 0
#define KEY_0_CAPTURE 1
#define KEY_0_DATA_WIDTH 1
#define KEY_0_DO_TEST_BENCH_WIRING 0
#define KEY_0_DRIVEN_SIM_VALUE 0
#define KEY_0_EDGE_TYPE "RISING"
#define KEY_0_FREQ 50000000
#define KEY_0_HAS_IN 1
#define KEY_0_HAS_OUT 0
#define KEY_0_HAS_TRI 0
#define KEY_0_IRQ 2
#define KEY_0_IRQ_INTERRUPT_CONTROLLER_ID 0
#define KEY_0_IRQ_TYPE "EDGE"
#define KEY_0_NAME "/dev/KEY_0"
#define KEY_0_RESET_VALUE 0
#define KEY_0_SPAN 16
#define KEY_0_TYPE "altera_avalon_pio"


/*
 * KEY_1 configuration
 *
 */

#define ALT_MODULE_CLASS_KEY_1 altera_avalon_pio
#define KEY_1_BASE 0x2001040
#define KEY_1_BIT_CLEARING_EDGE_REGISTER 0
#define KEY_1_BIT_MODIFYING_OUTPUT_REGISTER 0
#define KEY_1_CAPTURE 1
#define KEY_1_DATA_WIDTH 1
#define KEY_1_DO_TEST_BENCH_WIRING 0
#define KEY_1_DRIVEN_SIM_VALUE 0
#define KEY_1_EDGE_TYPE "RISING"
#define KEY_1_FREQ 50000000
#define KEY_1_HAS_IN 1
#define KEY_1_HAS_OUT 0
#define KEY_1_HAS_TRI 0
#define KEY_1_IRQ 3
#define KEY_1_IRQ_INTERRUPT_CONTROLLER_ID 0
#define KEY_1_IRQ_TYPE "EDGE"
#define KEY_1_NAME "/dev/KEY_1"
#define KEY_1_RESET_VALUE 0
#define KEY_1_SPAN 16
#define KEY_1_TYPE "altera_avalon_pio"


/*
 * KEY_2 configuration
 *
 */

#define ALT_MODULE_CLASS_KEY_2 altera_avalon_pio
#define KEY_2_BASE 0x2001030
#define KEY_2_BIT_CLEARING_EDGE_REGISTER 0
#define KEY_2_BIT_MODIFYING_OUTPUT_REGISTER 0
#define KEY_2_CAPTURE 1
#define KEY_2_DATA_WIDTH 1
#define KEY_2_DO_TEST_BENCH_WIRING 0
#define KEY_2_DRIVEN_SIM_VALUE 0
#define KEY_2_EDGE_TYPE "RISING"
#define KEY_2_FREQ 50000000
#define KEY_2_HAS_IN 1
#define KEY_2_HAS_OUT 0
#define KEY_2_HAS_TRI 0
#define KEY_2_IRQ 4
#define KEY_2_IRQ_INTERRUPT_CONTROLLER_ID 0
#define KEY_2_IRQ_TYPE "EDGE"
#define KEY_2_NAME "/dev/KEY_2"
#define KEY_2_RESET_VALUE 0
#define KEY_2_SPAN 16
#define KEY_2_TYPE "altera_avalon_pio"


/*
 * KEY_3 configuration
 *
 */

#define ALT_MODULE_CLASS_KEY_3 altera_avalon_pio
#define KEY_3_BASE 0x2001020
#define KEY_3_BIT_CLEARING_EDGE_REGISTER 0
#define KEY_3_BIT_MODIFYING_OUTPUT_REGISTER 0
#define KEY_3_CAPTURE 1
#define KEY_3_DATA_WIDTH 1
#define KEY_3_DO_TEST_BENCH_WIRING 0
#define KEY_3_DRIVEN_SIM_VALUE 0
#define KEY_3_EDGE_TYPE "RISING"
#define KEY_3_FREQ 50000000
#define KEY_3_HAS_IN 1
#define KEY_3_HAS_OUT 0
#define KEY_3_HAS_TRI 0
#define KEY_3_IRQ 5
#define KEY_3_IRQ_INTERRUPT_CONTROLLER_ID 0
#define KEY_3_IRQ_TYPE "EDGE"
#define KEY_3_NAME "/dev/KEY_3"
#define KEY_3_RESET_VALUE 0
#define KEY_3_SPAN 16
#define KEY_3_TYPE "altera_avalon_pio"


/*
 * SDRAM configuration
 *
 */

#define ALT_MODULE_CLASS_SDRAM altera_avalon_new_sdram_controller
#define SDRAM_BASE 0x1000000
#define SDRAM_CAS_LATENCY 3
#define SDRAM_CONTENTS_INFO
#define SDRAM_INIT_NOP_DELAY 0.0
#define SDRAM_INIT_REFRESH_COMMANDS 2
#define SDRAM_IRQ -1
#define SDRAM_IRQ_INTERRUPT_CONTROLLER_ID -1
#define SDRAM_IS_INITIALIZED 1
#define SDRAM_NAME "/dev/SDRAM"
#define SDRAM_POWERUP_DELAY 100.0
#define SDRAM_REFRESH_PERIOD 15.625
#define SDRAM_REGISTER_DATA_IN 1
#define SDRAM_SDRAM_ADDR_WIDTH 0x16
#define SDRAM_SDRAM_BANK_WIDTH 2
#define SDRAM_SDRAM_COL_WIDTH 8
#define SDRAM_SDRAM_DATA_WIDTH 32
#define SDRAM_SDRAM_NUM_BANKS 4
#define SDRAM_SDRAM_NUM_CHIPSELECTS 1
#define SDRAM_SDRAM_ROW_WIDTH 12
#define SDRAM_SHARED_DATA 0
#define SDRAM_SIM_MODEL_BASE 0
#define SDRAM_SPAN 16777216
#define SDRAM_STARVATION_INDICATOR 0
#define SDRAM_TRISTATE_BRIDGE_SLAVE ""
#define SDRAM_TYPE "altera_avalon_new_sdram_controller"
#define SDRAM_T_AC 5.5
#define SDRAM_T_MRD 3
#define SDRAM_T_RCD 20.0
#define SDRAM_T_RFC 70.0
#define SDRAM_T_RP 20.0
#define SDRAM_T_WR 14.0


/*
 * SD_CLK configuration
 *
 */

#define ALT_MODULE_CLASS_SD_CLK altera_avalon_pio
#define SD_CLK_BASE 0x20010c0
#define SD_CLK_BIT_CLEARING_EDGE_REGISTER 0
#define SD_CLK_BIT_MODIFYING_OUTPUT_REGISTER 0
#define SD_CLK_CAPTURE 0
#define SD_CLK_DATA_WIDTH 1
#define SD_CLK_DO_TEST_BENCH_WIRING 0
#define SD_CLK_DRIVEN_SIM_VALUE 0
#define SD_CLK_EDGE_TYPE "NONE"
#define SD_CLK_FREQ 50000000
#define SD_CLK_HAS_IN 0
#define SD_CLK_HAS_OUT 1
#define SD_CLK_HAS_TRI 0
#define SD_CLK_IRQ -1
#define SD_CLK_IRQ_INTERRUPT_CONTROLLER_ID -1
#define SD_CLK_IRQ_TYPE "NONE"
#define SD_CLK_NAME "/dev/SD_CLK"
#define SD_CLK_RESET_VALUE 0
#define SD_CLK_SPAN 16
#define SD_CLK_TYPE "altera_avalon_pio"


/*
 * SD_CMD configuration
 *
 */

#define ALT_MODULE_CLASS_SD_CMD altera_avalon_pio
#define SD_CMD_BASE 0x20010a0
#define SD_CMD_BIT_CLEARING_EDGE_REGISTER 0
#define SD_CMD_BIT_MODIFYING_OUTPUT_REGISTER 0
#define SD_CMD_CAPTURE 0
#define SD_CMD_DATA_WIDTH 1
#define SD_CMD_DO_TEST_BENCH_WIRING 0
#define SD_CMD_DRIVEN_SIM_VALUE 0
#define SD_CMD_EDGE_TYPE "NONE"
#define SD_CMD_FREQ 50000000
#define SD_CMD_HAS_IN 0
#define SD_CMD_HAS_OUT 0
#define SD_CMD_HAS_TRI 1
#define SD_CMD_IRQ -1
#define SD_CMD_IRQ_INTERRUPT_CONTROLLER_ID -1
#define SD_CMD_IRQ_TYPE "NONE"
#define SD_CMD_NAME "/dev/SD_CMD"
#define SD_CMD_RESET_VALUE 0
#define SD_CMD_SPAN 16
#define SD_CMD_TYPE "altera_avalon_pio"


/*
 * SD_DAT configuration
 *
 */

#define ALT_MODULE_CLASS_SD_DAT altera_avalon_pio
#define SD_DAT_BASE 0x20010b0
#define SD_DAT_BIT_CLEARING_EDGE_REGISTER 0
#define SD_DAT_BIT_MODIFYING_OUTPUT_REGISTER 0
#define SD_DAT_CAPTURE 0
#define SD_DAT_DATA_WIDTH 4
#define SD_DAT_DO_TEST_BENCH_WIRING 0
#define SD_DAT_DRIVEN_SIM_VALUE 0
#define SD_DAT_EDGE_TYPE "NONE"
#define SD_DAT_FREQ 50000000
#define SD_DAT_HAS_IN 0
#define SD_DAT_HAS_OUT 0
#define SD_DAT_HAS_TRI 1
#define SD_DAT_IRQ -1
#define SD_DAT_IRQ_INTERRUPT_CONTROLLER_ID -1
#define SD_DAT_IRQ_TYPE "NONE"
#define SD_DAT_NAME "/dev/SD_DAT"
#define SD_DAT_RESET_VALUE 0
#define SD_DAT_SPAN 16
#define SD_DAT_TYPE "altera_avalon_pio"


/*
 * SD_WP_N configuration
 *
 */

#define ALT_MODULE_CLASS_SD_WP_N altera_avalon_pio
#define SD_WP_N_BASE 0x2001090
#define SD_WP_N_BIT_CLEARING_EDGE_REGISTER 0
#define SD_WP_N_BIT_MODIFYING_OUTPUT_REGISTER 0
#define SD_WP_N_CAPTURE 0
#define SD_WP_N_DATA_WIDTH 1
#define SD_WP_N_DO_TEST_BENCH_WIRING 0
#define SD_WP_N_DRIVEN_SIM_VALUE 0
#define SD_WP_N_EDGE_TYPE "NONE"
#define SD_WP_N_FREQ 50000000
#define SD_WP_N_HAS_IN 1
#define SD_WP_N_HAS_OUT 0
#define SD_WP_N_HAS_TRI 0
#define SD_WP_N_IRQ -1
#define SD_WP_N_IRQ_INTERRUPT_CONTROLLER_ID -1
#define SD_WP_N_IRQ_TYPE "NONE"
#define SD_WP_N_NAME "/dev/SD_WP_N"
#define SD_WP_N_RESET_VALUE 0
#define SD_WP_N_SPAN 16
#define SD_WP_N_TYPE "altera_avalon_pio"


/*
 * System configuration
 *
 */

#define ALT_DEVICE_FAMILY "Cyclone IV E"
#define ALT_ENHANCED_INTERRUPT_API_PRESENT
#define ALT_IRQ_BASE NULL
#define ALT_LOG_PORT "/dev/null"
#define ALT_LOG_PORT_BASE 0x0
#define ALT_LOG_PORT_DEV null
#define ALT_LOG_PORT_TYPE ""
#define ALT_NUM_EXTERNAL_INTERRUPT_CONTROLLERS 0
#define ALT_NUM_INTERNAL_INTERRUPT_CONTROLLERS 1
#define ALT_NUM_INTERRUPT_CONTROLLERS 1
#define ALT_STDERR "/dev/JTAG"
#define ALT_STDERR_BASE 0x20010d0
#define ALT_STDERR_DEV JTAG
#define ALT_STDERR_IS_JTAG_UART
#define ALT_STDERR_PRESENT
#define ALT_STDERR_TYPE "altera_avalon_jtag_uart"
#define ALT_STDIN "/dev/JTAG"
#define ALT_STDIN_BASE 0x20010d0
#define ALT_STDIN_DEV JTAG
#define ALT_STDIN_IS_JTAG_UART
#define ALT_STDIN_PRESENT
#define ALT_STDIN_TYPE "altera_avalon_jtag_uart"
#define ALT_STDOUT "/dev/JTAG"
#define ALT_STDOUT_BASE 0x20010d0
#define ALT_STDOUT_DEV JTAG
#define ALT_STDOUT_IS_JTAG_UART
#define ALT_STDOUT_PRESENT
#define ALT_STDOUT_TYPE "altera_avalon_jtag_uart"
#define ALT_SYSTEM_NAME "nios"


/*
 * Timer configuration
 *
 */

#define ALT_MODULE_CLASS_Timer altera_avalon_timer
#define TIMER_ALWAYS_RUN 0
#define TIMER_BASE 0x2001000
#define TIMER_COUNTER_SIZE 32
#define TIMER_FIXED_PERIOD 0
#define TIMER_FREQ 50000000
#define TIMER_IRQ 0
#define TIMER_IRQ_INTERRUPT_CONTROLLER_ID 0
#define TIMER_LOAD_VALUE 49999
#define TIMER_MULT 0.0010
#define TIMER_NAME "/dev/Timer"
#define TIMER_PERIOD 1
#define TIMER_PERIOD_UNITS "ms"
#define TIMER_RESET_OUTPUT 0
#define TIMER_SNAPSHOT 1
#define TIMER_SPAN 32
#define TIMER_TICKS_PER_SEC 1000.0
#define TIMER_TIMEOUT_PULSE_OUTPUT 0
#define TIMER_TYPE "altera_avalon_timer"


/*
 * hal configuration
 *
 */

#define ALT_MAX_FD 32
#define ALT_SYS_CLK TIMER
#define ALT_TIMESTAMP_CLK none


/*
 * sysid configuration
 *
 */

#define ALT_MODULE_CLASS_sysid altera_avalon_sysid_qsys
#define SYSID_BASE 0x20010d8
#define SYSID_ID 0
#define SYSID_IRQ -1
#define SYSID_IRQ_INTERRUPT_CONTROLLER_ID -1
#define SYSID_NAME "/dev/sysid"
#define SYSID_SPAN 8
#define SYSID_TIMESTAMP 1463341542
#define SYSID_TYPE "altera_avalon_sysid_qsys"

#endif /* __SYSTEM_H_ */
