////////////////////////////////////////////////////////////////////////////////
//
// @file:   sd.h
//
// @author: Andre Heil <andre.v.heil@gmail.com>
//
// @date:   05/14/16
//
// @brief:  Perform functions on the .nsf file
//
////////////////////////////////////////////////////////////////////////////////

#ifndef __SD_H_
#define __SD_H_

void sd_mount();
void sd_list();
void sd_file_open( char * file_name );
int  sd_file_size();
void sd_file_read( void* buf, int size );

#endif
