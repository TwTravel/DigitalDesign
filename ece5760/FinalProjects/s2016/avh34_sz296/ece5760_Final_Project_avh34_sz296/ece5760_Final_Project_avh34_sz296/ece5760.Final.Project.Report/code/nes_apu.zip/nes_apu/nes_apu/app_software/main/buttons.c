////////////////////////////////////////////////////////////////////////////////
//
// @file:   buttons.c
//
// @author: Andre Heil <andre.v.heil@gmail.com>
//
// @date:   05/14/16
//
// @brief:  Perform functions on the .nsf file
//
////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdint.h>
#include "altera_avalon_pio_regs.h"
#include "sys/alt_irq.h"
#include "../BSP/system.h"
#include "buttons.h"
#include "nsf.h"


static volatile uint8_t * key_0 = (uint8_t *) KEY_0_BASE;
static volatile uint8_t * key_1 = (uint8_t *) KEY_1_BASE;
static volatile uint8_t * key_2 = (uint8_t *) KEY_2_BASE;
static volatile uint8_t * key_3 = (uint8_t *) KEY_3_BASE;


static void isr_key_0(void* context, alt_u32 id)
{
    printf("key_0\n");
    if( play )
    	nsf_pause();
    else
    	play = 1;

    IOWR_ALTERA_AVALON_PIO_EDGE_CAP(KEY_0_BASE, 0);
}

static void isr_key_1(void* context, alt_u32 id)
{
    printf("key_1\n");
    
    song++;
    nsf_init( song );

    IOWR_ALTERA_AVALON_PIO_EDGE_CAP(KEY_1_BASE, 0);
}

static void isr_key_2(void* context, alt_u32 id)
{
    printf("key_2\n");
	
	song--;
    nsf_init( song );

    IOWR_ALTERA_AVALON_PIO_EDGE_CAP(KEY_2_BASE, 0);
}

static void isr_key_3(void* context, alt_u32 id)
{
    printf("key_3\n");
	start = 0;
	nsf_pause();
	sd_file_close();

    IOWR_ALTERA_AVALON_PIO_EDGE_CAP(KEY_3_BASE, 0);
}

void buttons_init()
{
    IOWR_ALTERA_AVALON_PIO_IRQ_MASK(KEY_0_BASE, 0xf);
    IOWR_ALTERA_AVALON_PIO_EDGE_CAP(KEY_0_BASE, 0x0);
    alt_irq_register( KEY_0_IRQ, NULL, isr_key_0 );

    IOWR_ALTERA_AVALON_PIO_IRQ_MASK(KEY_1_BASE, 0xf);
    IOWR_ALTERA_AVALON_PIO_EDGE_CAP(KEY_1_BASE, 0x0);
    alt_irq_register( KEY_1_IRQ, NULL, isr_key_1 );

    IOWR_ALTERA_AVALON_PIO_IRQ_MASK(KEY_2_BASE, 0xf);
    IOWR_ALTERA_AVALON_PIO_EDGE_CAP(KEY_2_BASE, 0x0);
    alt_irq_register( KEY_2_IRQ, NULL, isr_key_2 );

    IOWR_ALTERA_AVALON_PIO_IRQ_MASK(KEY_3_BASE, 0xf);
    IOWR_ALTERA_AVALON_PIO_EDGE_CAP(KEY_3_BASE, 0x0);
    alt_irq_register( KEY_3_IRQ, NULL, isr_key_3 );
}