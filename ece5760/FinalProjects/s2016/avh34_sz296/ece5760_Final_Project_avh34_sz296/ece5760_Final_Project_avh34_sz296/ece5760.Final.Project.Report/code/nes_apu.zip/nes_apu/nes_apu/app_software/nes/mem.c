#include <stdint.h>
#include "mem.h"
#include "../BSP/system.h"

volatile uint8_t * apu_addr  = (uint8_t *) APU_ADDR_BASE;
volatile uint8_t * apu_data  = (uint8_t *) APU_DATA_BASE;
volatile uint8_t * apu_wren  = (uint8_t *) APU_WREN_BASE;

uint8_t mos6502_read( uint16_t addr ) {

    if ( addr >= 0x8000 ) return mem_rom[ addr - mem_load ];
    if ( addr <  0x2000 ) return mem_ram[ addr & 0x07FF ];
    if ( addr <  0x4000 ) return mem_ppu[ 0x2000 | ( addr & 0x0007 ) ];
    if ( addr <  0x4020 ) return mem_apu[ addr ]; 
    if ( addr <  0x8000 ) return mem_rrm[ addr & 0x1FFF ];

    return 0;
}

void    mos6502_write( uint16_t addr, uint8_t value) {

    if      ( addr < 0x2000 ) mem_ram[ addr & 0x07FF ]              = value;
    else if ( addr < 0x4000 ) mem_ppu[ 0x2000 | ( addr & 0x0007 ) ] = value;
    else if ( addr < 0x4020 ){
        *apu_addr = ( addr & 0x001F );
        *apu_data = value;
        *apu_wren = 1;
        *apu_wren = 0;

        mem_apu[ addr & 0x1F ] = value;
    }
    else if ( addr < 0x8000 ) mem_rrm[ addr & 0x1FFF ] = value;
    //else    printf( "BAD WRITE\n" );

}
