#include "sys/alt_stdio.h"
#include <stdio.h>
#include <stdlib.h>
#include "BSP/system.h"
#include "pt.h"
#include "project_winning.h"
#define X_GIRD_SIZE 16
#define Y_GRID_SIZE 16


char text_string[] = "\nECE5760 Final Project Setup\n> \0";
volatile int* JTAG_UART_ptr = (int*) JTAG_UART_BASE;	// JTAG UART address, 32 bits
volatile char* XY_SW_from_FPGA_ptr = (char*) XY_SW_FROM_FPGA_BASE;
volatile char* PIECE_TYPE_FROM_FPGA_ptr = (char*) PIECE_TYPE_FROM_FPGA_BASE;
volatile char* KEY1_PRESSED_ptr = (char*) KEY1_PRESSED_BASE;
volatile char* ACK_TO_NIOS_ptr = (char*) ACK_TO_NIOS_BASE;
volatile char* HUMAN_HUMAN_ptr = (char*) HUMAN_HUMAN_BASE;


char* BLACK_WIN_BIT_TO_FPGA_ptr = (char*) BLACK_WIN_BIT_TO_FPGA_BASE;
char* WHITE_WIN_BIT_TO_FPGA_ptr = (char*) WHITE_WIN_BIT_TO_FPGA_BASE;
char* NIOS_RESPONDED_ptr = (char*) NIOS_RESPONDED_BASE;
char* NIOS_MOVE_X_ptr = (char*) NIOS_MOVE_X_BASE;
char* NIOS_MOVE_Y_ptr = (char*) NIOS_MOVE_Y_BASE;

volatile char human_human;
char xy_place;
char x_place,y_place;
char piece_type;
char key1_pressed;
char grid_value[X_GIRD_SIZE][Y_GRID_SIZE];
char white_wins = 0;
char black_wins = 0;
int i,j;


void perform_random_move(void);

static struct pt pt1;
 
static int protothread1(struct pt *pt)
{

  PT_BEGIN(pt);

  /* We loop forever here. */
  while(1) {
    human_human = *(HUMAN_HUMAN_ptr);
    xy_place = *(XY_SW_from_FPGA_ptr);
    x_place = (xy_place & 0xf0) >> 4;
    y_place = xy_place & 0x0f;
    piece_type = *(PIECE_TYPE_FROM_FPGA_ptr) & 0x03;
    key1_pressed = *(KEY1_PRESSED_ptr);
    if (key1_pressed && grid_value[x_place][y_place] == EMPTY)
    {
      grid_value[x_place][y_place] = piece_type;
      printf("oppenent placed a piece at (%d,%d)\n", x_place,y_place);
      if (piece_type == WHITE) {
        alt_printf("It's a WHITE piece\n");
      } else if (piece_type == BLACK) {
        alt_printf("It's a BLACK piece\n");
      }
      judge();
      human_human = *(HUMAN_HUMAN_ptr);
      if (human_human)
      {
        continue;
      }
      perform_random_move();
      *(NIOS_RESPONDED_ptr) = 1;
      //wait until hearing acknowledgement back from FPGA
      while(*(ACK_TO_NIOS_ptr)==0);
      alt_printf("And I heard acknowledgement back from FPGA, I can go next cycle now\n");
      *(NIOS_RESPONDED_ptr) = 0;
    }
    judge();

  	PT_YIELD(pt);
    /* And we loop. */
  }

  /* All protothread functions must end with PT_END() which takes a
     pointer to a struct pt. */
  PT_END(pt);
}


int main(void)
{
	
	/* Initialize the protothread state variables with PT_INIT(). */
	PT_INIT(&pt1);
  srand(1);
	/* print a text string */
	alt_printf("%s",text_string);
  human_human = *(HUMAN_HUMAN_ptr);
	while(1)
	{	
	    protothread1(&pt1);
	}			
}

void perform_random_move(void){
  char rand16_x,rand16_y;
  do{
    rand16_x = (char) ((int) (16 * ((float) rand() / (float) RAND_MAX)));
    rand16_y = (char) ((int) (16 * ((float) rand() / (float) RAND_MAX)));
  } while(grid_value[rand16_x][rand16_y] != EMPTY);
  grid_value[rand16_x][rand16_y] = (piece_type == WHITE)? BLACK : WHITE;
  printf("I responded a piece at (%d,%d)\n", rand16_x, rand16_y);
  *(NIOS_MOVE_X_ptr) = rand16_x & 0x0f;
  *(NIOS_MOVE_Y_ptr) = rand16_y & 0x0f;
}


void judge(void){
  white_wins = 0;
  black_wins = 0;
  for (i = 0; i < X_GIRD_SIZE; i++)
  { for (j = 0; j < Y_GRID_SIZE; j++)
    {
      if(is_piece_row(i,j,WHITE) || is_piece_column(i,j,WHITE) || is_piece_diagonal(i,j,WHITE)){
        white_wins = 1;
        break;
      }
      else if(is_piece_row(i,j,BLACK) || is_piece_column(i,j,BLACK) || is_piece_diagonal(i,j,BLACK)){
        black_wins = 1;
        break;
      }
    }
  }
  if(white_wins){
    alt_printf("WHITE wins!");
    *(WHITE_WIN_BIT_TO_FPGA_ptr) = white_wins;
    while(1);
  } else if (black_wins)
  { alt_printf("BLACK wins!");
    *(BLACK_WIN_BIT_TO_FPGA_ptr) = black_wins;
    while(1);
  }
}

char is_piece_row(int i, int j, char piece_type){
    char win_val;
    if(i >= 2 && i<= 13){     
      win_val = (grid_value[i-2][j] == piece_type && grid_value[i-1][j] == piece_type 
        && grid_value[i][j] == piece_type && grid_value[i+1][j] == piece_type && grid_value[i+2][j] == piece_type);
    } else{
      win_val = 0;
    }
    return win_val;
}

char is_piece_column(int i, int j, char piece_type){
    char win_val;
    if(j >= 2 && j<= 13){     
      win_val = (grid_value[i][j-2] == piece_type && grid_value[i][j-1] == piece_type 
        && grid_value[i][j] == piece_type && grid_value[i][j+1] == piece_type && grid_value[i][j+2] == piece_type);
    } else{
      win_val = 0;
    }
    return win_val;
}

char is_piece_diagonal(int i, int j, char piece_type){
  char win_val;
  char win_val_temp0;
  char win_val_temp1;
  if((i >= 2 && i<= 13) && (j >= 2 && j<= 13)){     
    win_val_temp0 = (grid_value[i-2][j-2] == piece_type && grid_value[i-1][j-1] == piece_type 
      && grid_value[i][j] == piece_type && grid_value[i+1][j+1] == piece_type && grid_value[i+2][j+2] == piece_type);
    win_val_temp1 = (grid_value[i-2][j+2] == piece_type && grid_value[i-1][j+1] == piece_type 
      && grid_value[i][j] == piece_type && grid_value[i+1][j-1] == piece_type && grid_value[i+2][j-2] == piece_type);
    win_val = (win_val_temp0) || (win_val_temp1);
  } else{
    win_val = 0;
  }
  return win_val;
}
