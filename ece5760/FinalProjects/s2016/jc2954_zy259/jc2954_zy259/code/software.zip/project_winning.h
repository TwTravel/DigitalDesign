#define EMPTY 0
#define WHITE 2
#define BLACK 1

void judge(void);
char is_piece_row(int i, int j, char piece_type);
char is_piece_column(int i, int j, char piece_type);
char is_piece_diagonal(int i, int j, char piece_type);