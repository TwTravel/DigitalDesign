/******************************************************************************
* Copyright ? 2004 Altera Corporation, San Jose, California, USA.             *
* All rights reserved. All use of this software and documentation is          *
* subject to the License Agreement located at the end of this file below.     *
*******************************************************************************
* Author - PRR/JRK                                                            *
*                                                                             *
* This is an example webs erver using LWIP on the MicroC/OS-II RTOS.          *
* It is in no way a complete implementation of a webserver, it is enough to   *
* serve up our demo pages and that's it.                                      *
*                                                                             *
* LWIP has two API's, a callback interface and "standard" sockets this        *
* example uses the sockets interface. A good introduction to sockets          *
* programming is the book Unix Network Programming by Richard Stevens.        *
*                                                                             *
* Please refer to file readme.txt for notes on this software example.         *
******************************************************************************/
#include <stdio.h>
#include <errno.h>
#include <ctype.h>
#include "includes.h"
#include "alt_lwip_dev.h"
#include "lwip/sys.h"
#include "user.h"

// hychu
#include "dm9000.h"
#include "lcd.h"
ALTERA_AVALON_DM9K_INSTANCE(DM9000A, dm9k);

void user_task(void * pvoid)
{
	static u_long val=0;

	// simply doing sanity check	
	for(;;)
	{
		val ^= (1<<17);
		IOWR(LED_RED_BASE, 0, val);
		usleep(500000);
	} // of forever loop
}

#ifndef LWIP
  #error This Web Server requires the Lightweight IP Software Component.
#endif

#ifndef __ucosii__
  #error This Web Server requires the UCOS II IP Software Component.
#endif

#ifndef  RO_ZIPFS
  #error This Web Server requires the Altera Read only Zip filing system.
#endif

/*
 * A MicroC/OS-II message box will be used to communicate between telnet
 * and board LED control tasks.
 */
OS_EVENT *attained_ip_address_sem;

/*
 * tcpip_init_done()
 * 
 * This function is called once the LWIP stack is alive, as specified in our
 * lwip_stack_init() call in main(), below.
 *
 * We tell it about each of our network devices and start the application & 
 * timer threads as appropriate.
 */
static void tcpip_init_done(void *arg)
{
// hychu
	ALTERA_AVALON_DM9K_INIT(dm9k);

  /* 
   * At this point LWIP has been initialized, but the Ethernet interface has
   * not; the initialise_lwip_devices() call does so, adding in MicroC-OS/II
   * threads for low-level Ethernet MAC interface and TCP protocol timer.
   */
  if (!lwip_devices_init(ETHER_PRIO))
    die_with_error("[tcpip_init_done] Fatal: Can't add ethernet interface!");
    
    attained_ip_address_sem = OSSemCreate(1);
  
  /* 
   * If DHCP is enabled, activate a thread for the 120-second long time period
   * that is allowed to attempt IP address aquisistion via DHCP. The 
   * dchp_timeout_task() routine is in this example design's
   * "network_utilities.c" file.
   */
#if LWIP_DHCP == 1
//++ hychu
	if(!(IORD(SWITCH_PIO_BASE, 0) & (1<<17))) sys_thread_new(dhcp_timeout_task, NULL, DHCP_TMR_PRIO);
//-- hychu
  //if (!sys_thread_new(dhcp_timeout_task, NULL, DHCP_TMR_PRIO))    die_with_error("[tcpip_init_done] Fatal: Can't add DHCP timer task!");
#endif /* LWIP_DHCP */
  
  /* 
   * Add any application task(s) that rely on LWIP:
   *  
   * http_task() -- Creates HTTP listening sockets, manages incoming
   *                connection requests, and handles all web server duties.
   */
  if(!sys_thread_new(http_task, NULL, HTTP_PRIO))
    die_with_error("[tcpip_init_done] Fatal: Can't add HTTP task!");

}

int main ()
{
// hychu
	LCD_Init();

  //printf("\n\nWeb Server starting up\n\n");
  
  /* 
   * Our very first call in an LWIP example design is to start up the LWIP 
   * stack. We specify a MicroC/OS-II thread priority for the tcp_ip thread,
   * as well as a call-back routine, tcpip_init_done(), which is called once
   * the stack is alive and well.
   */
  lwip_stack_init(TCPIP_PRIO, tcpip_init_done, 0);
  
  /*
   * As with all MicroC/OS-II designs, once the initial thread(s) and 
   * associated RTOS resources are declared, we start the RTOS. That's it!
   */

// hychu
	sys_thread_new(user_task, NULL, SANITY_PRIO);

  OSStart();

  return 0;
}

/******************************************************************************
*                                                                             *
* License Agreement                                                           *
*                                                                             *
* Copyright (c) 2004 Altera Corporation, San Jose, California, USA.           *
* All rights reserved.                                                        *
*                                                                             *
* Permission is hereby granted, free of charge, to any person obtaining a     *
* copy of this software and associated documentation files (the "Software"),  *
* to deal in the Software without restriction, including without limitation   *
* the rights to use, copy, modify, merge, publish, distribute, sublicense,    *
* and/or sell copies of the Software, and to permit persons to whom the       *
* Software is furnished to do so, subject to the following conditions:        *
*                                                                             *
* The above copyright notice and this permission notice shall be included in  *
* all copies or substantial portions of the Software.                         *
*                                                                             *
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR  *
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,    *
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE *
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER      *
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING     *
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER         *
* DEALINGS IN THE SOFTWARE.                                                   *
*                                                                             *
* This agreement shall be governed in all respects by the laws of the State   *
* of California and by the laws of the United States of America.              *
* Altera does not recommend, suggest or require that this reference design    *
* file be used in conjunction or combination with any other product.          *
******************************************************************************/
