#ifndef __USER_H__
#define __USER_H__
/******************************************************************************
* Copyright � 2004 Altera Corporation, San Jose, California, USA.             *
* All rights reserved. All use of this software and documentation is          *
* subject to the License Agreement located at the end of this file below.     *
*******************************************************************************
* Author - PRR/JRK                                                            *
*                                                                             *
* File: user.h                                                                *
*                                                                             *
* Headers for our application. HTTP server-specific headers can be found in   *
* file http.c.                                                                *
*                                                                             *
* Please refer to file readme.txt for notes on this software example.         *
******************************************************************************/

#include "lwipopts.h"

/*
 * Prototypes:
 *    die_with_error() - Kills current task and delivers error message to 
 *                       STDERR.
 * 
 * dhcp_timeout_task() - Keeps track of whether an IP address has been 
 *                       aquired from a DHCP server, or times out and resorts
 *                       to a static IP address.
 * 
 *         http_task() - Manages HTTP connections and calls relevant 
 *                       subroutines to service HTTP requests.
 */
void http_task();
void die_with_error(char err_msg[]);
void dhcp_timeout_task();

/*
 * Time we wait for DHCP to assign an IP address before settling on a static
 * address (default is 120 seconds).
 */
#define DHCP_TIMEOUT ((120 * 1000)/100)

/* 
 * The IP, gateway, and subnet mask address below are used as a last resort if 
 * if no network settings can be found, and DHCP (if enabled) fails. You can
 * edit these as a quick-and-dirty way of changing network settings if desired.
 * 
 * Default fall-back address:
 *           IP: 10.0.0.51
 *      Gateway: 10.0.0.255
 *  Subnet Mask: 255.255.255.0
 */
#define IPADDR0   10
#define IPADDR1   0
#define IPADDR2   0
#define IPADDR3   51

#define GWADDR0   10
#define GWADDR1   0
#define GWADDR2   0
#define GWADDR3   255

#define MSKADDR0  255
#define MSKADDR1  255
#define MSKADDR2  255
#define MSKADDR3  0

/* 
 * Nios Development Boards are programmed on the production line with a unique
 * MAC address & network settings in the last sector of flash memory.
 * 
 * Stratix II based Nios Development Boards have 16 megabytes of flash memory, 
 * so the last flash sector is located starting at offset 0x00FF0000 from 
 * the flash base.  For Stratix II, the flash base address is 0x02000000, as
 * defined in system.h.  So the LAST_FLASH_SECTOR physical address is 0x02FF0000.
 * 
 * For Stratix and Cyclone based Nios Development Boards, which have 8 megabytes 
 * of flash memory, the last flash sector is located at offset address 0x7F0000 
 * from a flash memory base address of 0 as defined in system.h. So the 
 * LAST_FLASH_SECTOR address is 0x007F0000 for Stratix and Cyclone based Nios 
 * Development Boards.
 * 
 * LAST_FLASH_SECTOR is used in the get_mac_addr() function defined in 
 * network_utilities.c
 */
 
/* Stratix II based Nios and DSP Development Board */
#if defined(ALTERA_NIOS_DEV_BOARD_STRATIX_2S60_ES) ||\
    defined(ALTERA_DSP_DEV_BOARD_STRATIX_2S60_ES) ||\
    defined(ALTERA_NIOS_DEV_BOARD_STRATIX_2S60)   || \
    defined(ALTERA_NIOS_DEV_BOARD_CYCLONE_2C35)
#define LAST_SECTOR_OFFSET  0x00FF0000
#endif

/* Stratix and Cyclone based Nios Development Board */
#if defined(ALTERA_NIOS_DEV_BOARD_CYCLONE_1C20) ||\
    defined(ALTERA_NIOS_DEV_BOARD_STRATIX_1S10) ||\
    defined(ALTERA_NIOS_DEV_BOARD_STRATIX_1S10_ES) ||\
    defined(ALTERA_NIOS_DEV_BOARD_STRATIX_1S40)    
#define LAST_SECTOR_OFFSET  0x007F0000
#endif

/* All Nios Development Boards */
#define LAST_FLASH_SECTOR EXT_FLASH_BASE + LAST_SECTOR_OFFSET

/*
 * Task priorities
 *
 * MicroC/OS-II only allows one task (thread) per priority number. Our web
 * SERVER task is given a high priority (lower only than timers which must run 
 * when they need to) so that we can focus on pushing data *out* of the system.
 * An ethernet CLIENT application would have lower priotitization than the 
 * stack & ethernet tasks.
 */

enum {
	DHCP_TMR_PRIO = 1,
	SANITY_PRIO,
	ETHER_PRIO,
	HTTP_PRIO,
	TTCP_PRIO,
	TCPIP_PRIO,
	USER_PRIO,
	LAST_PRIO
};

// ++hychu
#if 0
// orignial setting
#define DHCP_TMR_PRIO 1
#define HTTP_PRIO     2 
#define TCPIP_PRIO    3
#define ETHER_PRIO    4 
#endif
// -- hychu
/* 
 * Buffer size for a routine to call if things fail
 */
#define DIE_WITH_ERROR_BUFFER 256

#endif /* __USER_H__ */

/******************************************************************************
*                                                                             *
* License Agreement                                                           *
*                                                                             *
* Copyright (c) 2004 Altera Corporation, San Jose, California, USA.           *
* All rights reserved.                                                        *
*                                                                             *
* Permission is hereby granted, free of charge, to any person obtaining a     *
* copy of this software and associated documentation files (the "Software"),  *
* to deal in the Software without restriction, including without limitation   *
* the rights to use, copy, modify, merge, publish, distribute, sublicense,    *
* and/or sell copies of the Software, and to permit persons to whom the       *
* Software is furnished to do so, subject to the following conditions:        *
*                                                                             *
* The above copyright notice and this permission notice shall be included in  *
* all copies or substantial portions of the Software.                         *
*                                                                             *
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR  *
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,    *
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE *
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER      *
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING     *
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER         *
* DEALINGS IN THE SOFTWARE.                                                   *
*                                                                             *
* This agreement shall be governed in all respects by the laws of the State   *
* of California and by the laws of the United States of America.              *
* Altera does not recommend, suggest or require that this reference design    *
* file be used in conjunction or combination with any other product.          *
******************************************************************************/
