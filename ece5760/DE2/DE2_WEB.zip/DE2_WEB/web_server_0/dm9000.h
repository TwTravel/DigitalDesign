/*
 * dm9000.h
 *
 * Davicom DM9000A driver for LWIP
 *
 * Author: HY Chu, March 2006
 */
 
#ifndef	__DM9000_INL__
#define	__DM9000_INL__

#ifdef LWIP
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

#include "system.h"

#include "alt_types.h"
#include "alt_lwip_dev.h"

#include "lwip/opt.h"
#include "lwip/def.h"
#include "lwip/mem.h"
#include "lwip/pbuf.h"
#include "lwip/sys.h"
#include "lwip/netif.h"
#include "lwip/stats.h"

#include "netif/etharp.h"
#include "arch/sys_arch.h"
#include "arch/perf.h"

#include "sys/alt_irq.h"
#include "sys/alt_warning.h"
#include "os/alt_syscall.h"

#include "io.h"

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

// LWIP specified variables
extern sys_mbox_t  rx_mbox;

// Altera specified function entry points
err_t alt_avalon_dm9k_init(struct netif *netif);
void  alt_avalon_dm9k_rx();

// dm9k private date structure
typedef struct 
{
	alt_lwip_dev_list   lwip_dev_list;
	int	base_addr;
	int	irq;
	u_char hwaddr[6];
	int	index_offset;
	int	data_offset;
	int	dm9k_tx_space;
	int dm9k_linked;
	sys_sem_t	arp_semaphore;
	sys_sem_t	tx_semaphore;
} alt_avalon_dm9k_if;

// dm9k specified routines
err_t dm9k_init(alt_avalon_dm9k_if * dev);
void  dm9k_isr(void * pvoid);
err_t dm9k_output(struct netif *netif, struct pbuf *p, struct ip_addr *ipaddr);
err_t dm9k_link_output(struct netif *netif, struct pbuf *p);
int   dm9k_input(struct netif *netif);
struct pbuf * dm9k_link_input(alt_avalon_dm9k_if * dev);

#define ALTERA_AVALON_DM9K_INSTANCE(name, dev) \
alt_avalon_dm9k_if dev = \
{\
  {\
    ALT_LLIST_ENTRY,\
    {\
      0,\
      name##_NAME,\
      alt_avalon_dm9k_init, \
      alt_avalon_dm9k_rx,\
    },\
  },\
  name##_BASE, \
  name##_IRQ,\
  { 0x00, 0x90, 0x00, 0xAE, 0x00, 0x01}, \
  0, 1, 2\
}


#define ALTERA_AVALON_DM9K_INIT(dev)	alt_lwip_dev_reg(dev)

#ifdef __cplusplus
}
#endif /* __cplusplus */

#else

#define ALTERA_AVALON_DM9K_INSTANCE(name, dev) extern int alt_no_storage
#define ALTERA_AVALON_DM9K_INIT(name, dev) while(0)     
#endif /* LWIP */

#define	NULL_STATEMENT do {} while (0)

#ifdef USE_ARP_SEMAPHORE
#define	WAIT_ARP_SEMAPHORE(pdev) sys_sem_wait(pdev->arp_semaphore)
#define	SIGNAL_ARP_SEMAPHORE(pdev) sys_sem_signal(pdev->arp_semaphore)
#else
#define	WAIT_ARP_SEMAPHORE(pdev) NULL_STATEMENT
#define	SIGNAL_ARP_SEMAPHORE(pdev) NULL_STATEMENT
#endif


#endif//	__DM9000_INL__


