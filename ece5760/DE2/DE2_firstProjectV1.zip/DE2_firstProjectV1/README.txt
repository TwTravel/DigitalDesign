DE2_Top
-------

This design is a bare-bones design containing all the pin assignments available on the DE2 board. It also contains a Verilog module with all the input/output ports corresponding to each pin. This can be used as a starting point for designs on the board.
