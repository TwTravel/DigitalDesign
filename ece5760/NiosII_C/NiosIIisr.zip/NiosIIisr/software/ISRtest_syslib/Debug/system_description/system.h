/* system.h
 *
 * Machine generated for a CPU named "cpu_0" as defined in:
 * C:\DE2\NiosIIisr\software\ISRtest_syslib\..\..\NiosII.ptf
 *
 * Generated: 2006-07-10 11:04:01.484
 *
 */

#ifndef __SYSTEM_H_
#define __SYSTEM_H_

/*

DO NOT MODIFY THIS FILE

   Changing this file will have subtle consequences
   which will almost certainly lead to a nonfunctioning
   system. If you do modify this file, be aware that your
   changes will be overwritten and lost when this file
   is generated again.

DO NOT MODIFY THIS FILE

*/

/******************************************************************************
*                                                                             *
* License Agreement                                                           *
*                                                                             *
* Copyright (c) 2003 Altera Corporation, San Jose, California, USA.           *
* All rights reserved.                                                        *
*                                                                             *
* Permission is hereby granted, free of charge, to any person obtaining a     *
* copy of this software and associated documentation files (the "Software"),  *
* to deal in the Software without restriction, including without limitation   *
* the rights to use, copy, modify, merge, publish, distribute, sublicense,    *
* and/or sell copies of the Software, and to permit persons to whom the       *
* Software is furnished to do so, subject to the following conditions:        *
*                                                                             *
* The above copyright notice and this permission notice shall be included in  *
* all copies or substantial portions of the Software.                         *
*                                                                             *
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR  *
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,    *
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE *
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER      *
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING     *
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER         *
* DEALINGS IN THE SOFTWARE.                                                   *
*                                                                             *
* This agreement shall be governed in all respects by the laws of the State   *
* of California and by the laws of the United States of America.              *
*                                                                             *
******************************************************************************/

/*
 * system configuration
 *
 */

#define ALT_SYSTEM_NAME "NiosII"
#define ALT_CPU_NAME "cpu_0"
#define ALT_CPU_ARCHITECTURE "altera_nios2"
#define ALT_DEVICE_FAMILY "CYCLONEII"
#define ALT_STDIN "/dev/null"
#define ALT_STDOUT "/dev/null"
#define ALT_STDERR "/dev/null"
#define ALT_CPU_FREQ 50000000
#define ALT_IRQ_BASE NULL

/*
 * processor configuration
 *
 */

#define NIOS2_CPU_IMPLEMENTATION "tiny"

#define NIOS2_ICACHE_SIZE 0
#define NIOS2_DCACHE_SIZE 0
#define NIOS2_ICACHE_LINE_SIZE 0
#define NIOS2_ICACHE_LINE_SIZE_LOG2 0
#define NIOS2_DCACHE_LINE_SIZE 0
#define NIOS2_DCACHE_LINE_SIZE_LOG2 0
#define NIOS2_FLUSHDA_SUPPORTED

#define NIOS2_EXCEPTION_ADDR 0x00000020
#define NIOS2_RESET_ADDR 0x00000000

#define NIOS2_HAS_DEBUG_STUB

#define NIOS2_CPU_ID_SIZE 1
#define NIOS2_CPU_ID_VALUE 0

/*
 * A define for each class of peripheral
 *
 */

#define __ALTERA_AVALON_ONCHIP_MEMORY2
#define __ALTERA_AVALON_PIO
#define __ALTERA_AVALON_TIMER

/*
 * mem_onchip configuration
 *
 */

#define MEM_ONCHIP_NAME "/dev/mem_onchip"
#define MEM_ONCHIP_TYPE "altera_avalon_onchip_memory2"
#define MEM_ONCHIP_BASE 0x00000000
#define MEM_ONCHIP_SPAN 4096
#define MEM_ONCHIP_ALLOW_MRAM_SIM_CONTENTS_ONLY_FILE 0
#define MEM_ONCHIP_RAM_BLOCK_TYPE "M4K"
#define MEM_ONCHIP_INIT_CONTENTS_FILE "mem_onchip"
#define MEM_ONCHIP_NON_DEFAULT_INIT_FILE_ENABLED 0
#define MEM_ONCHIP_GUI_RAM_BLOCK_TYPE "Automatic"
#define MEM_ONCHIP_WRITEABLE 1
#define MEM_ONCHIP_DUAL_PORT 0
#define MEM_ONCHIP_SIZE_VALUE 4
#define MEM_ONCHIP_SIZE_MULTIPLE 1024
#define MEM_ONCHIP_CONTENTS_INFO "QUARTUS_PROJECT_DIR/onchip_memory_0.hex 1151682810 QUARTUS_PROJECT_DIR/mem_onchip.hex 1151942586 QUARTUS_PROJECT_DIR/inst_mem.hex 1151691231"

/*
 * switches configuration
 *
 */

#define SWITCHES_NAME "/dev/switches"
#define SWITCHES_TYPE "altera_avalon_pio"
#define SWITCHES_BASE 0x00001820
#define SWITCHES_SPAN 16
#define SWITCHES_DO_TEST_BENCH_WIRING 0
#define SWITCHES_DRIVEN_SIM_VALUE 0x0000
#define SWITCHES_HAS_TRI 0
#define SWITCHES_HAS_OUT 0
#define SWITCHES_HAS_IN 1
#define SWITCHES_CAPTURE 0
#define SWITCHES_EDGE_TYPE "NONE"
#define SWITCHES_IRQ_TYPE "NONE"
#define SWITCHES_FREQ 50000000

/*
 * leds configuration
 *
 */

#define LEDS_NAME "/dev/leds"
#define LEDS_TYPE "altera_avalon_pio"
#define LEDS_BASE 0x00001830
#define LEDS_SPAN 16
#define LEDS_DO_TEST_BENCH_WIRING 0
#define LEDS_DRIVEN_SIM_VALUE 0x0000
#define LEDS_HAS_TRI 0
#define LEDS_HAS_OUT 1
#define LEDS_HAS_IN 0
#define LEDS_CAPTURE 0
#define LEDS_EDGE_TYPE "NONE"
#define LEDS_IRQ_TYPE "NONE"
#define LEDS_FREQ 50000000

/*
 * timer_0 configuration
 *
 */

#define TIMER_0_NAME "/dev/timer_0"
#define TIMER_0_TYPE "altera_avalon_timer"
#define TIMER_0_BASE 0x00001800
#define TIMER_0_SPAN 32
#define TIMER_0_IRQ 1
#define TIMER_0_ALWAYS_RUN 0
#define TIMER_0_FIXED_PERIOD 0
#define TIMER_0_SNAPSHOT 1
#define TIMER_0_PERIOD 1
#define TIMER_0_PERIOD_UNITS "ms"
#define TIMER_0_RESET_OUTPUT 0
#define TIMER_0_TIMEOUT_PULSE_OUTPUT 0
#define TIMER_0_MULT 0.001
#define TIMER_0_FREQ 50000000

/*
 * system library configuration
 *
 */

#define ALT_MAX_FD 32
#define ALT_SYS_CLK TIMER_0
#define ALT_TIMESTAMP_CLK none

/*
 * Devices associated with code sections.
 *
 */

#define ALT_TEXT_DEVICE       MEM_ONCHIP
#define ALT_RODATA_DEVICE     MEM_ONCHIP
#define ALT_RWDATA_DEVICE     MEM_ONCHIP
#define ALT_EXCEPTIONS_DEVICE MEM_ONCHIP
#define ALT_RESET_DEVICE      MEM_ONCHIP

/*
 * The text section is initialised so no bootloader will be required.
 * Set a variable to tell crt0.S to provide code at the reset address and
 * to initialise rwdata if appropriate.
 */

#define ALT_NO_BOOTLOADER


#endif /* __SYSTEM_H_ */
