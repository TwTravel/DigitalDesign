
//ISR test in C

//system.h has peripheral base addresses, IRQ definitions, and details
#include "C:\DE2\NiosIIisr\software\ISRtest_syslib\Debug\system_description\system.h"
#include "sys/alt_irq.h"
//#include "sys/alt_types.h"
#include "altera_avalon_timer_regs.h"
#include "altera_avalon_pio_regs.h"

#define begin {
#define end }  

int flag;

static void timer_isr(void* context, alt_u32 id)
begin
  IOWR_ALTERA_AVALON_TIMER_STATUS(TIMER_0_BASE, 0);
  flag = flag ^ 0xff;
end

int main(void)
begin
  volatile int context;
  int sw;
    
  flag = 0xff;
  //one second period, 50e6 counts = 0x2FAF080
  IOWR_ALTERA_AVALON_TIMER_PERIODL(TIMER_0_BASE, 0xf080);
  IOWR_ALTERA_AVALON_TIMER_PERIODH(TIMER_0_BASE, 0x2fa);
  //set RUN, set CONTuous, set ITO
  IOWR_ALTERA_AVALON_TIMER_CONTROL(TIMER_0_BASE, 7);
  alt_irq_register(TIMER_0_IRQ,(void*)&context, timer_isr);
  
  while(1)
  begin
    sw = IORD_ALTERA_AVALON_PIO_DATA(SWITCHES_BASE);
    IOWR_ALTERA_AVALON_PIO_DATA(LEDS_BASE, sw ^ flag);
  end
end
