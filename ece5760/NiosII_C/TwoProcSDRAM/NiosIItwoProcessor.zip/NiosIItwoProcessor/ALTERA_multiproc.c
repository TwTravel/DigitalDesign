

#include <stdio.h>
#include <string.h>
#include "sys/alt_alarm.h"
#include "system.h"
#include "nios2.h"
#include "altera_avalon_mutex.h"

#define MESSAGE_WAITING 1
#define NO_MESSAGE 0

#define LOCK_SUCCESS 0
#define LOCK_FAIL 1

#define MESSAGE_BUFFER_BASE MESSAGE_BUFFER_RAM_BASE

#define FIRST_LOCK 1 /* for testing only */
#define ERROR_OPENED_INVALID_MUTEX 1 /* for testing only */
#define ERROR_ALLOWED_ACCESS_WITHOUT_OWNING_MUTEX 2 /* for testing only */
#define ERROR_COULDNT_OPEN_MUTEX 3 /* for testing only */

#define MS_DELAY 1000

// Message buffer structure
typedef struct {
  char flag;
  char buf[100];
} message_buffer_struct;

int main()
{ 

  // Pointer to our mutex device
  alt_mutex_dev* mutex = NULL;

  // Local variables
  unsigned int id;
  unsigned int value;
  unsigned int count = 0;
  unsigned int ticks_at_last_message;
  
  char got_first_lock = 0; /* for testing only */
  unsigned int error_code = 0; /* for testing only */
  
  message_buffer_struct *message;

  // Get our processor ID (add 1 so it matches the cpu name in SOPC Builder)
  NIOS2_READ_CPUID(id);
  id += 1;
  
  // Value can be any non-zero value
  value = 1;

  // Initialize the message buffer location
  message = (message_buffer_struct*)MESSAGE_BUFFER_BASE;
  
  // We'll try to open the wrong mutex here and hope it's not successful.
  mutex = altera_avalon_mutex_open("/dev/wrong_device_name"); /* for testing only */
  if (mutex != NULL) /* for testing only */
  {
    // Whoops, opening the invalid mutex was successful.
    error_code = ERROR_OPENED_INVALID_MUTEX; /* for testing only */
    goto error; /* for testing only */
  }

  // Okay, now we'll open the real mutex
  // It's not actually a mutex to share the jtag_uart, but to share a message 
  // buffer which CPU1 is responsible for reading and printing to the jtag_uart.
  mutex = altera_avalon_mutex_open(MESSAGE_BUFFER_MUTEX_NAME);

  // We'll use the system clock to keep track of our delay time.
  // Here we initialize delay tracking variable.
  ticks_at_last_message = alt_nticks();
 
  if (mutex)
  {
	  // If the mutex has never been locked, clear the message flag.
	  // We are safe to use the non-blocking "trylock" function here
	  // because if we dont get the mutex on the first shot, it means
	  // someone else already has it and we clearly arent going to be 
	  // the first to release it anyway.
	  if(altera_avalon_mutex_trylock(mutex, value) == LOCK_SUCCESS) /* for testing only */
	  {
	    if (altera_avalon_mutex_first_lock(mutex) == FIRST_LOCK) /* for testing only */
	    {
	      message->flag = NO_MESSAGE; /* for testing only */
	      got_first_lock = 1; /* for testing only */
	    }
	    altera_avalon_mutex_unlock(mutex); /* for testing only */
	  }
  	
    while(1)
    {
      // See if it's time to send a message yet
      if (alt_nticks() >= (ticks_at_last_message + ((alt_ticks_per_second() * (MS_DELAY)) / 1000)))
      {
        ticks_at_last_message = alt_nticks();

        // Try and aquire the mutex (non-blocking).
        if(altera_avalon_mutex_trylock(mutex, value) == LOCK_SUCCESS)
        {
          // Just make sure we own the mutex
          if(altera_avalon_mutex_is_mine(mutex)) /* for testing only */
          {
            // Check if the message buffer is empty
            if(message->flag == NO_MESSAGE)
            {
              count++;
              // If we were the first to lock the mutex, say so in our first message.
              if (got_first_lock) /* for testing only */
              {
                sprintf(message->buf, "FIRST LOCK - Message from CPU %d.  Number sent: %d\n", id, count); /* for testing only */
                got_first_lock = 0; /* for testing only */
              }
              else
              {
                sprintf(message->buf, "Message from CPU %d.  Number sent: %d\n", id, count);
              }
              // Set the flag that a message has been put in the buffer.
              message->flag = MESSAGE_WAITING;
            }
          }
          else /* for testing only */
          {
            error_code = ERROR_ALLOWED_ACCESS_WITHOUT_OWNING_MUTEX; /* for testing only */
            goto error; /* for testing only */
          }
          // Release the mutex
          altera_avalon_mutex_unlock(mutex);
        }
      }
      
      // If we are CPU1, check the message buffer
      // and if there's a message, print it to stdout.
//      if(id == 1)
#ifdef JTAG_UART_NAME
      {
        if(message->flag == MESSAGE_WAITING)
        {
          // We dont really need to lock the mutex here since the if(id == 1) statement 
          // assures we are the only CPU grabbing messages out of the buffer, but
          // we'll do it anyway to test the blocking lock routine.
          altera_avalon_mutex_lock(mutex, value);  /* for testing only */

          // Just make sure we own the mutex
          if(altera_avalon_mutex_is_mine(mutex)) /* for testing only */
          {
            printf("%s", message->buf);
            message->flag = NO_MESSAGE;
          }
          else /* for testing only */
          {
            error_code = ERROR_ALLOWED_ACCESS_WITHOUT_OWNING_MUTEX; /* for testing only */
            goto error; /* for testing only */
          }
          // Release the Mutex
          altera_avalon_mutex_unlock(mutex); /* for testing only */
        }
      }
#endif /* JTAG_UART_NAME */      
    }
  }
  else /* for testing only */
  {
  	error_code = ERROR_COULDNT_OPEN_MUTEX; /* for testing only */
  	goto error; /* for testing only */
  }

  
error: /* for testing only */
  return(error_code); /* for testing only */
//	return(0);
}
